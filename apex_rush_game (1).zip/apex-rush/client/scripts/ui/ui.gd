class_name UI
extends RefCounted
## Tiny UI toolkit: neon/dark theme + helpers so every screen is built in code (no hand-made scenes).

const BG := Color("0a0c14")
const PANEL := Color("141826")
const PANEL2 := Color("1d2236")
const ACCENT := Color("00e5ff")
const ACCENT2 := Color("ff2d95")
const GOLD := Color("ffc933")
const TEXT := Color("e8ecff")
const DIM := Color("8a93b8")
const GOOD := Color("3ddc84")
const BAD := Color("ff5252")

static func make_theme() -> Theme:
	var t := Theme.new()
	t.default_font_size = 24 if OS.has_feature("mobile") else 20
	for st in ["normal", "hover", "pressed", "disabled", "focus"]:
		var b := StyleBoxFlat.new()
		b.set_corner_radius_all(10)
		b.content_margin_left = 16
		b.content_margin_right = 16
		b.content_margin_top = 10
		b.content_margin_bottom = 10
		match st:
			"normal": b.bg_color = PANEL2
			"hover": b.bg_color = PANEL2.lightened(0.12)
			"pressed": b.bg_color = ACCENT.darkened(0.4)
			"disabled": b.bg_color = PANEL.darkened(0.2)
			"focus":
				b.bg_color = Color(0, 0, 0, 0)
				b.set_border_width_all(2)
				b.border_color = ACCENT
		t.set_stylebox(st, "Button", b)
	t.set_color("font_color", "Button", TEXT)
	t.set_color("font_disabled_color", "Button", DIM)
	t.set_color("font_color", "Label", TEXT)
	var pc := StyleBoxFlat.new()
	pc.bg_color = PANEL
	pc.set_corner_radius_all(12)
	pc.set_content_margin_all(12)
	t.set_stylebox("panel", "PanelContainer", pc)
	var le := StyleBoxFlat.new()
	le.bg_color = BG
	le.set_corner_radius_all(8)
	le.set_border_width_all(1)
	le.border_color = PANEL2.lightened(0.2)
	le.set_content_margin_all(10)
	t.set_stylebox("normal", "LineEdit", le)
	t.set_stylebox("normal", "OptionButton", t.get_stylebox("normal", "Button"))
	return t

static func label(text: String, size: int = 0, color: Color = TEXT, wrap: bool = false) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_color_override("font_color", color)
	if size > 0:
		l.add_theme_font_size_override("font_size", size)
	if wrap:
		l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	return l

static func button(text: String, cb: Callable, color: Color = Color(0, 0, 0, 0), min_h: int = 52) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(0, min_h)
	if color.a > 0.0:
		for st in ["normal", "hover", "pressed"]:
			var s := StyleBoxFlat.new()
			s.bg_color = color if st == "normal" else (color.lightened(0.15) if st == "hover" else color.darkened(0.3))
			s.set_corner_radius_all(10)
			s.content_margin_left = 16
			s.content_margin_right = 16
			s.content_margin_top = 10
			s.content_margin_bottom = 10
			b.add_theme_stylebox_override(st, s)
		b.add_theme_color_override("font_color", Color.BLACK if color.get_luminance() > 0.5 else TEXT)
	b.pressed.connect(cb)
	return b

static func panel(child: Control = null) -> PanelContainer:
	var p := PanelContainer.new()
	if child:
		p.add_child(child)
	return p

static func vbox(sep: int = 8) -> VBoxContainer:
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", sep)
	return v

static func hbox(sep: int = 8) -> HBoxContainer:
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", sep)
	return h

static func scroll(child: Control) -> ScrollContainer:
	var s := ScrollContainer.new()
	s.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	s.size_flags_vertical = Control.SIZE_EXPAND_FILL
	s.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	child.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	s.add_child(child)
	return s

static func clear(node: Node) -> void:
	for c in node.get_children():
		c.queue_free()

static func line(ph: String, text: String = "", secret: bool = false) -> LineEdit:
	var e := LineEdit.new()
	e.placeholder_text = ph
	e.text = text
	e.secret = secret
	e.custom_minimum_size = Vector2(0, 52)
	return e

static func bar(value: float, maxv: float, color: Color = ACCENT) -> ProgressBar:
	var b := ProgressBar.new()
	b.max_value = maxv
	b.value = value
	b.show_percentage = false
	b.custom_minimum_size = Vector2(0, 14)
	b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var fg := StyleBoxFlat.new()
	fg.bg_color = color
	fg.set_corner_radius_all(6)
	b.add_theme_stylebox_override("fill", fg)
	var bg := StyleBoxFlat.new()
	bg.bg_color = BG
	bg.set_corner_radius_all(6)
	b.add_theme_stylebox_override("background", bg)
	return b

static func class_color(cls: String) -> Color:
	match cls:
		"D": return Color("9aa3b5")
		"C": return Color("5ec96a")
		"B": return Color("4aa3ff")
		"A": return Color("b061ff")
		"S": return Color("ffb020")
		"X": return Color("ff3b6b")
	return TEXT

static func toast(host: Node, text: String, good: bool = true) -> void:
	var l := PanelContainer.new()
	var lab := label(text, 22, GOOD if good else BAD)
	l.add_child(lab)
	l.z_index = 100
	host.add_child(l)
	l.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
	l.position.y = 24
	var tw := host.create_tween()
	tw.tween_interval(2.2)
	tw.tween_property(l, "modulate:a", 0.0, 0.4)
	tw.tween_callback(l.queue_free)

static func stat_row(name: String, val: String, ratio: float, color: Color = ACCENT) -> Control:
	var h := hbox(10)
	var n := label(name, 18, DIM)
	n.custom_minimum_size = Vector2(130, 0)
	h.add_child(n)
	h.add_child(bar(ratio * 100.0, 100.0, color))
	var v := label(val, 18)
	v.custom_minimum_size = Vector2(90, 0)
	v.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	h.add_child(v)
	return h
