extends VBoxContainer

func _ready() -> void:
	add_theme_constant_override("separation", 10)
	var u := Game.user
	var car := Game.selected_car()
	var head := UI.hbox(12)
	add_child(head)
	var left := UI.vbox(6)
	left.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	left.add_child(UI.label("Welcome back, %s" % u.get("username", ""), 30, UI.ACCENT))
	left.add_child(UI.label("Races %d   Wins %d   Podiums %d   Takedowns %d   %.1f km driven" % [u.get("races", 0), u.get("wins", 0), u.get("podiums", 0), u.get("takedowns", 0), u.get("distance_km", 0.0)], 18, UI.DIM))
	var xp := UI.bar(float(u.get("xp", 0)), float(max(1, u.get("next_level_xp", 120))), UI.ACCENT2)
	left.add_child(xp)
	left.add_child(UI.label("XP %d / %d" % [u.get("xp", 0), u.get("next_level_xp", 120)], 16, UI.DIM))
	head.add_child(UI.panel(left))
	if not car.is_empty():
		var c := UI.vbox(4)
		var cd: Dictionary = car["car"]
		c.add_child(UI.label("%s %s" % [cd["make"], cd["model"]], 26))
		c.add_child(UI.label("Class %s   PI %d" % [cd["cls"], car["stats"]["pi"]], 20, UI.class_color(cd["cls"])))
		c.add_child(UI.stat_row("Top speed", "%d km/h" % car["stats"]["top_kmh"], car["stats"]["top_kmh"] / 420.0))
		c.add_child(UI.stat_row("0-100", "%.1f s" % car["stats"]["accel_s"], clampf((12.0 - car["stats"]["accel_s"]) / 10.0, 0.0, 1.0), UI.ACCENT2))
		c.add_child(UI.stat_row("Handling", str(car["stats"]["handling"]), car["stats"]["handling"] / 100.0, UI.GOOD))
		var p := UI.panel(c)
		p.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		head.add_child(p)
	var row := UI.hbox(10)
	add_child(row)
	var daily := UI.button("CLAIM DAILY REWARD", _daily, UI.GOLD, 70)
	daily.disabled = not u.get("daily_ready", false)
	daily.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(daily)
	var quick := UI.button("QUICK MATCH", _quick, UI.ACCENT, 70)
	quick.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(quick)
	var free := UI.button("FREE DRIVE (offline)", _free_drive, UI.ACCENT2, 70)
	free.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(free)
	add_child(UI.label("Tip: upgrade your car in GARAGE, then race in LOBBY. Join a GUILD to earn guild XP from every race.", 18, UI.DIM, true))

func _daily() -> void:
	var r := await Net.api("POST", "/api/daily")
	if r.ok:
		Game.set_user(r.data["user"])
		UI.toast(get_tree().current_scene, "+%d coins (streak %d)" % [r.data["coins"], r.data["streak"]])
		get_tree().current_scene.show_panel("HOME")
	else:
		UI.toast(get_tree().current_scene, r.data.get("error", "Error"), false)

func _free_drive() -> void:
	Game.load_tracks()
	var t: Dictionary = Game.tracks[randi() % Game.tracks.size()]
	Game.race_ctx = {"offline": true, "track_id": t["id"], "laps": 2, "grid": {}, "checkpoints": [], "players": [{"uid": Game.user.get("id", 0), "name": Game.user.get("username", "You"), "car": Game.selected_car()}]}
	get_tree().change_scene_to_file("res://scenes/race.tscn")

func _quick() -> void:
	Net.send({"t": "matchmaking.quick"})
	get_tree().current_scene.show_panel("LOBBY")
