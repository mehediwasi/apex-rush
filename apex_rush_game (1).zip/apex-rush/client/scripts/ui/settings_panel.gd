extends VBoxContainer

func _ready() -> void:
	add_theme_constant_override("separation", 10)
	add_child(UI.label("SETTINGS", 30, UI.ACCENT))
	add_child(UI.label("Graphics quality", 18, UI.DIM))
	var q := OptionButton.new()
	for n in ["Low (old phones)", "Medium", "High", "Ultra (PC)"]:
		q.add_item(n)
	q.selected = Settings.quality
	q.item_selected.connect(func(i): Settings.quality = i; Settings.save_settings())
	add_child(q)
	var tilt := CheckButton.new()
	tilt.text = "Tilt steering (mobile)"
	tilt.button_pressed = Settings.tilt_steering
	tilt.toggled.connect(func(v): Settings.tilt_steering = v; Settings.save_settings())
	add_child(tilt)
	var fps := CheckButton.new()
	fps.text = "Show FPS"
	fps.button_pressed = Settings.show_fps
	fps.toggled.connect(func(v): Settings.show_fps = v; Settings.save_settings())
	add_child(fps)
	add_child(UI.label("Volume", 18, UI.DIM))
	var vol := HSlider.new()
	vol.min_value = 0.0
	vol.max_value = 1.0
	vol.step = 0.05
	vol.value = Settings.master_volume
	vol.value_changed.connect(func(v): Settings.master_volume = v; Settings.save_settings())
	add_child(vol)
	add_child(UI.label("PC controls: W/S throttle-brake, A/D steer, Space handbrake/drift, Shift nitro, R reset, C camera. Gamepad supported.", 16, UI.DIM, true))
	add_child(UI.button("LOG OUT", func():
		Game.logout()
		get_tree().change_scene_to_file("res://scenes/login.tscn"), UI.BAD))
