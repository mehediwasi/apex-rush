extends HBoxContainer

var list := UI.vbox(6)
var detail := UI.vbox(8)
var sel_id := -1

func _ready() -> void:
	add_theme_constant_override("separation", 10)
	var l := UI.scroll(list)
	l.custom_minimum_size = Vector2(330, 0)
	l.size_flags_horizontal = Control.SIZE_FILL
	add_child(l)
	var d := UI.scroll(detail)
	add_child(d)
	await Game.refresh_garage()
	sel_id = Game.user.get("selected_garage_id", -1)
	_build()

func _build() -> void:
	if not is_inside_tree():
		return
	UI.clear(list)
	for g in Game.garage:
		var c: Dictionary = g["car"]
		var txt := "%s %s  [%s]%s" % [c["make"], c["model"], c["cls"], "  (listed)" if g["listed"] else ""]
		var b := UI.button(txt, func(): sel_id = g["id"]; _build())
		b.add_theme_color_override("font_color", UI.class_color(c["cls"]))
		b.disabled = (g["id"] == sel_id)
		list.add_child(b)
	_detail()

func _find(id: int) -> Dictionary:
	for g in Game.garage:
		if g["id"] == id:
			return g
	return {}

func _detail() -> void:
	UI.clear(detail)
	var g := _find(sel_id)
	if g.is_empty():
		return
	var c: Dictionary = g["car"]
	var st: Dictionary = g["stats"]
	detail.add_child(UI.label("%s %s (%d)" % [c["make"], c["model"], c["year"]], 30))
	detail.add_child(UI.label("%s - %s - %s   Class %s   PI %d   %.0f km" % [c["body"].capitalize(), c["drive"], c["rarity"], c["cls"], st["pi"], g["odometer_km"]], 18, UI.class_color(c["cls"])))
	detail.add_child(UI.stat_row("Power", "%d hp" % st["power_hp"], st["power_hp"] / 1200.0, UI.ACCENT2))
	detail.add_child(UI.stat_row("Top speed", "%d km/h" % st["top_kmh"], st["top_kmh"] / 420.0))
	detail.add_child(UI.stat_row("0-100 km/h", "%.1f s" % st["accel_s"], clampf((12.0 - st["accel_s"]) / 10.0, 0.0, 1.0), UI.ACCENT2))
	detail.add_child(UI.stat_row("Handling", str(st["handling"]), st["handling"] / 100.0, UI.GOOD))
	detail.add_child(UI.stat_row("Grip", str(st["grip"]), st["grip"] / 100.0, UI.GOOD))
	detail.add_child(UI.stat_row("Braking", str(st["braking"]), st["braking"] / 100.0, UI.GOLD))
	detail.add_child(UI.stat_row("Weight", "%d kg" % st["mass_kg"], clampf(st["mass_kg"] / 3000.0, 0, 1), UI.DIM))
	var row := UI.hbox(8)
	var selbtn := UI.button("USE THIS CAR", func(): _select(g["id"]), UI.ACCENT)
	selbtn.disabled = g["listed"] or g["id"] == Game.user.get("selected_garage_id", -1)
	row.add_child(selbtn)
	row.add_child(UI.button("SELL (%s)" % Game.fmt_coins(g["sell_value"]), func(): _sell(g["id"]), UI.BAD))
	detail.add_child(row)
	detail.add_child(UI.label("UPGRADES", 22, UI.ACCENT))
	_upgrades(g)
	detail.add_child(UI.label("CUSTOMIZE", 22, UI.ACCENT))
	var cp := ColorPickerButton.new()
	cp.color = Color(g["color"])
	cp.custom_minimum_size = Vector2(0, 52)
	cp.edit_alpha = false
	detail.add_child(UI.label("Paint (500 coins)", 16, UI.DIM))
	detail.add_child(cp)
	var wheel := SpinBox.new()
	wheel.min_value = 0
	wheel.max_value = 11
	wheel.value = g["wheel_style"]
	detail.add_child(UI.label("Wheel style 0-11 (1,500 coins)", 16, UI.DIM))
	detail.add_child(wheel)
	var neon := ColorPickerButton.new()
	neon.color = Color(g["neon"]) if g["neon"] != "" else Color.BLACK
	neon.custom_minimum_size = Vector2(0, 52)
	detail.add_child(UI.label("Underglow neon (2,500 coins)", 16, UI.DIM))
	detail.add_child(neon)
	detail.add_child(UI.button("APPLY CUSTOMIZATION", func(): _customize(g, cp.color, int(wheel.value), neon.color), UI.ACCENT2))

func _upgrades(g: Dictionary) -> void:
	var r := await Net.api("GET", "/api/garage/%d/upgrade-costs" % g["id"])
	if not is_inside_tree() or not r.ok:
		return
	var costs: Dictionary = r.data["costs"]
	for part in costs:
		var lvl: int = int(g["upgrades"].get(part, 0))
		var h := UI.hbox(8)
		var lab := UI.label("%s  Lv %d/5" % [part.capitalize(), lvl], 20)
		lab.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		h.add_child(lab)
		var cost = costs[part]
		var b := UI.button("MAX" if cost == null else "UPGRADE  %s" % Game.fmt_coins(cost), func(): _upgrade(g["id"], part), UI.GOLD, 46)
		b.disabled = cost == null
		h.add_child(b)
		detail.add_child(h)

func _upgrade(id: int, part: String) -> void:
	var r := await Net.api("POST", "/api/garage/upgrade", {"garage_id": id, "part": part})
	await _after(r, "Upgraded %s" % part)

func _customize(g: Dictionary, color: Color, wheel: int, neon: Color) -> void:
	var body := {"garage_id": g["id"], "color": "#" + color.to_html(false), "wheel_style": wheel}
	if neon != Color.BLACK:
		body["neon"] = "#" + neon.to_html(false)
	var r := await Net.api("POST", "/api/garage/customize", body)
	await _after(r, "Saved (cost %s)" % Game.fmt_coins(r.data.get("cost", 0)))

func _select(id: int) -> void:
	var r := await Net.api("POST", "/api/garage/select", {"garage_id": id})
	await _after(r, "Car selected")
	if Net.authed and Game.lobby.has("id"):
		Net.send({"t": "lobby.car"})

func _sell(id: int) -> void:
	var r := await Net.api("POST", "/api/garage/sell", {"garage_id": id})
	if r.ok:
		Game.set_user(r.data["user"])
		sel_id = Game.user.get("selected_garage_id", -1)
	await _after(r, "Sold")

func _after(r: Dictionary, ok_text: String) -> void:
	if r.ok:
		UI.toast(get_tree().current_scene, ok_text)
	else:
		UI.toast(get_tree().current_scene, r.data.get("error", "Error"), false)
	await Game.refresh_garage()
	await Game.refresh_user()
	_build()
