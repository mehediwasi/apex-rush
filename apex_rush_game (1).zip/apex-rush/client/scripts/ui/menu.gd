extends Control
## Main hub: top bar + nav + swappable panels (home, garage, market, lobby, guild, profile, settings).

const PANELS := {
	"HOME": "res://scripts/ui/home_panel.gd",
	"GARAGE": "res://scripts/ui/garage_panel.gd",
	"MARKET": "res://scripts/ui/market_panel.gd",
	"LOBBY": "res://scripts/ui/lobby_panel.gd",
	"GUILD": "res://scripts/ui/guild_panel.gd",
	"PROFILE": "res://scripts/ui/profile_panel.gd",
	"SETTINGS": "res://scripts/ui/settings_panel.gd",
}
var content: Control
var top_label: Label
var coin_label: Label
var net_label: Label
var nav_buttons := {}
var current := ""

func _ready() -> void:
	theme = UI.make_theme()
	var bg := ColorRect.new()
	bg.color = UI.BG
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(bg)
	var root := UI.vbox(8)
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.offset_left = 12
	root.offset_top = 12
	root.offset_right = -12
	root.offset_bottom = -12
	add_child(root)
	# top bar
	var top := UI.hbox(16)
	top_label = UI.label("", 24, UI.ACCENT)
	top_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	coin_label = UI.label("", 24, UI.GOLD)
	net_label = UI.label("offline", 16, UI.DIM)
	top.add_child(top_label)
	top.add_child(coin_label)
	top.add_child(net_label)
	root.add_child(UI.panel(top))
	# body
	var body := UI.hbox(10)
	body.size_flags_vertical = Control.SIZE_EXPAND_FILL
	root.add_child(body)
	var nav := UI.vbox(6)
	nav.custom_minimum_size = Vector2(190, 0)
	for n in PANELS:
		var b := UI.button(n, func(): show_panel(n))
		nav_buttons[n] = b
		nav.add_child(b)
	body.add_child(nav)
	content = Control.new()
	content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	content.size_flags_vertical = Control.SIZE_EXPAND_FILL
	content.clip_contents = true
	body.add_child(content)
	Game.user_changed.connect(_update_top)
	Net.ws_message.connect(_on_ws)
	Net.ws_connected.connect(func(): net_label.text = "connecting...")
	Net.ws_closed.connect(func(): net_label.text = "offline")
	Net.connect_ws()
	_update_top()
	await Game.refresh_garage()
	Game.load_tracks()
	show_panel("LOBBY" if Game.lobby.has("id") else "HOME")

func _update_top() -> void:
	var u := Game.user
	var g: Dictionary = u.get("guild", {}) if u.get("guild") != null else {}
	var tag: String = ("[%s] " % g["tag"]) if g.has("tag") else ""
	top_label.text = "%s%s   LV %d" % [tag, u.get("username", ""), u.get("level", 1)]
	coin_label.text = "%s coins   %d gems" % [Game.fmt_coins(u.get("coins", 0)), u.get("gems", 0)]

func show_panel(name: String) -> void:
	current = name
	UI.clear(content)
	for n in nav_buttons:
		nav_buttons[n].disabled = (n == name)
	var p: Control = load(PANELS[name]).new()
	p.set_anchors_preset(Control.PRESET_FULL_RECT)
	content.add_child(p)

func _on_ws(m: Dictionary) -> void:
	match m.get("t", ""):
		"auth.ok":
			net_label.text = "online %d" % int(m.get("online", 1))
		"presence":
			net_label.text = "online %d" % int(m.get("online", 1))
		"kicked":
			UI.toast(self, str(m.get("reason", "Disconnected")), false)
		"race.start":
			Game.race_ctx = m
			Game.race_ctx["offline"] = false
			get_tree().change_scene_to_file("res://scenes/race.tscn")
		"error":
			UI.toast(self, str(m.get("msg", "error")), false)
