extends VBoxContainer

var body := UI.vbox(8)
var chat_box := UI.vbox(2)
var chat_in: LineEdit
var guild: Dictionary = {}

func _ready() -> void:
	add_theme_constant_override("separation", 8)
	add_child(UI.scroll(body))
	Net.ws_message.connect(_on_ws)
	await _load()

func _load() -> void:
	var r := await Net.api("GET", "/api/guilds/mine")
	if not is_inside_tree() or not r.ok:
		return
	UI.clear(body)
	if r.data["guild"] == null:
		guild = {}
		_no_guild()
	else:
		guild = r.data["guild"]
		_guild_view()

# ---------- not in a guild ----------
func _no_guild() -> void:
	body.add_child(UI.label("GUILDS", 30, UI.ACCENT))
	var s := UI.hbox(8)
	var q := UI.line("Search guild name or tag")
	q.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	s.add_child(q)
	var results := UI.vbox(6)
	s.add_child(UI.button("SEARCH", func(): _search(q.text, results)))
	body.add_child(s)
	body.add_child(results)
	_search("", results)
	body.add_child(UI.label("CREATE A GUILD (25,000 coins)", 22, UI.ACCENT2))
	var name_in := UI.line("Guild name (3-20)")
	var tag_in := UI.line("TAG (2-4)")
	var req := CheckButton.new()
	req.text = "Join by request only"
	body.add_child(name_in)
	body.add_child(tag_in)
	body.add_child(req)
	body.add_child(UI.button("CREATE", func(): _create(name_in.text, tag_in.text, req.button_pressed), UI.ACCENT2))

func _search(q: String, results: Control) -> void:
	var r := await Net.api("GET", "/api/guilds?q=" + q.uri_encode())
	if not is_inside_tree() or not r.ok:
		return
	UI.clear(results)
	for g in r.data["guilds"]:
		var h := UI.hbox(8)
		var lab := UI.label("[%s] %s  LV %d  %d/%d  %s" % [g["tag"], g["name"], g["level"], g["members"], g["max_members"], "(request)" if g["join_mode"] == "request" else ""], 20)
		lab.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		h.add_child(lab)
		h.add_child(UI.button("JOIN", func(): _join(g["id"]), UI.ACCENT, 46))
		results.add_child(UI.panel(h))

func _join(id: int) -> void:
	var r := await Net.api("POST", "/api/guilds/%d/join" % id)
	_toast(r, "Done: " + str(r.data.get("status", "")))
	await Game.refresh_user()
	_load()

func _create(n: String, t: String, req: bool) -> void:
	var r := await Net.api("POST", "/api/guilds", {"name": n, "tag": t, "join_mode": "request" if req else "open"})
	_toast(r, "Guild created")
	await Game.refresh_user()
	_load()

func _toast(r: Dictionary, ok_text: String) -> void:
	UI.toast(get_tree().current_scene, ok_text if r.ok else r.data.get("error", "Error"), r.ok)

# ---------- guild view ----------
func _guild_view() -> void:
	var g := guild
	var role: String = g["my_role"]
	body.add_child(UI.label("[%s] %s" % [g["tag"], g["name"]], 34, UI.ACCENT))
	body.add_child(UI.label("Level %d   XP %d   Members %d/%d   Bank %s coins" % [g["level"], g["xp"], g["members"], g["max_members"], Game.fmt_coins(g["bank_coins"])], 20, UI.GOLD))
	if g["description"] != "":
		body.add_child(UI.label(g["description"], 18, UI.DIM, true))
	var row := UI.hbox(8)
	var amt := SpinBox.new()
	amt.min_value = 100
	amt.max_value = 10000000
	amt.step = 100
	amt.value = 1000
	row.add_child(amt)
	row.add_child(UI.button("DONATE", func(): _donate(int(amt.value)), UI.GOLD, 48))
	row.add_child(UI.button("LEAVE GUILD", _leave, UI.BAD, 48))
	body.add_child(row)
	if g.has("requests") and g["requests"].size() > 0:
		body.add_child(UI.label("JOIN REQUESTS", 22, UI.ACCENT2))
		for rq in g["requests"]:
			var h := UI.hbox(8)
			var lab := UI.label("%s  LV %d" % [rq["username"], rq["level"]], 20)
			lab.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			h.add_child(lab)
			h.add_child(UI.button("ACCEPT", func(): _req(rq["id"], "accept"), UI.GOOD, 44))
			h.add_child(UI.button("REJECT", func(): _req(rq["id"], "reject"), UI.BAD, 44))
			body.add_child(UI.panel(h))
	body.add_child(UI.label("MEMBERS", 22, UI.ACCENT))
	for m in g["member_list"]:
		var h := UI.hbox(8)
		var lab := UI.label("%s  [%s]  LV %d   contributed %s" % [m["username"], m["role"], m["level"], Game.fmt_coins(m["contributed"])], 18)
		lab.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		h.add_child(lab)
		if m["id"] != Game.user.get("id") and role != "member" and m["role"] != "leader":
			h.add_child(UI.button("KICK", func(): _act("/api/guilds/%d/kick/%d" % [g["id"], m["id"]]), UI.BAD, 40))
			if role == "leader":
				var nr := "officer" if m["role"] == "member" else "member"
				h.add_child(UI.button("-> " + nr, func(): _act("/api/guilds/%d/role/%d" % [g["id"], m["id"]], {"role": nr}), UI.ACCENT, 40))
		body.add_child(UI.panel(h))
	body.add_child(UI.label("GUILD CHAT", 22, UI.ACCENT))
	body.add_child(UI.panel(chat_box))
	var cr := UI.hbox(8)
	chat_in = UI.line("Message your guild")
	chat_in.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	chat_in.text_submitted.connect(func(_t): _send_chat())
	cr.add_child(chat_in)
	cr.add_child(UI.button("SEND", _send_chat, UI.ACCENT))
	body.add_child(cr)
	_history()

func _history() -> void:
	var r := await Net.api("GET", "/api/guilds/%d/messages" % guild["id"])
	if not is_inside_tree() or not r.ok:
		return
	UI.clear(chat_box)
	for m in r.data["messages"]:
		chat_box.add_child(UI.label("%s: %s" % [m["username"], m["text"]], 18))

func _send_chat() -> void:
	if chat_in.text.strip_edges() == "":
		return
	if Net.ws_state == WebSocketPeer.STATE_OPEN and Net.authed:
		Net.send({"t": "chat", "scope": "guild", "msg": chat_in.text})
	else:
		await Net.api("POST", "/api/guilds/%d/messages" % guild["id"], {"text": chat_in.text})
		_history()
	chat_in.text = ""

func _on_ws(m: Dictionary) -> void:
	if m.get("t", "") == "chat" and m.get("scope", "") == "guild" and is_instance_valid(chat_box):
		chat_box.add_child(UI.label("%s: %s" % [m["from"], m["msg"]], 18))

func _donate(a: int) -> void:
	var r := await Net.api("POST", "/api/guilds/%d/donate" % guild["id"], {"amount": a})
	_toast(r, "Donated %d" % a)
	await Game.refresh_user()
	_load()

func _leave() -> void:
	var r := await Net.api("POST", "/api/guilds/leave")
	_toast(r, "Left guild")
	await Game.refresh_user()
	_load()

func _req(uid: int, action: String) -> void:
	_act("/api/guilds/%d/requests/%d/%s" % [guild["id"], uid, action])

func _act(path: String, b: Dictionary = {}) -> void:
	var r := await Net.api("POST", path, b)
	_toast(r, "Done")
	_load()
