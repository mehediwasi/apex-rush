extends VBoxContainer

var list := UI.vbox(6)
var tab := "dealer"
var cls_filter := ""
var sort_key := "pi"

func _ready() -> void:
	add_theme_constant_override("separation", 8)
	var row := UI.hbox(8)
	row.add_child(UI.button("DEALER", func(): tab = "dealer"; _load()))
	row.add_child(UI.button("PLAYER MARKET", func(): tab = "players"; _load()))
	row.add_child(UI.button("SELL MY CAR", func(): tab = "sell"; _load()))
	add_child(row)
	var f := UI.hbox(8)
	var cb := OptionButton.new()
	for n in ["All classes", "D", "C", "B", "A", "S", "X"]:
		cb.add_item(n)
	cb.item_selected.connect(func(i): cls_filter = "" if i == 0 else cb.get_item_text(i); _load())
	f.add_child(cb)
	var sb := OptionButton.new()
	for n in ["pi", "price", "top_kmh", "power_hp", "accel_s", "year"]:
		sb.add_item(n)
	sb.item_selected.connect(func(i): sort_key = sb.get_item_text(i); _load())
	f.add_child(sb)
	add_child(f)
	add_child(UI.scroll(list))
	_load()

func _load() -> void:
	UI.clear(list)
	match tab:
		"dealer":
			var q := "/api/cars?sort=%s" % sort_key
			if cls_filter != "":
				q += "&cls=" + cls_filter
			var r := await Net.api("GET", q)
			if not is_inside_tree() or not r.ok:
				return
			for c in r.data["cars"]:
				list.add_child(_car_row(c))
		"players":
			var r := await Net.api("GET", "/api/market/listings")
			if not is_inside_tree() or not r.ok:
				return
			if r.data["listings"].is_empty():
				list.add_child(UI.label("No cars listed right now.", 20, UI.DIM))
			for l in r.data["listings"]:
				var c: Dictionary = l["car"]["car"]
				var h := UI.hbox(8)
				var lab := UI.label("%s %s [%s] PI %d  by %s  %s km  upg %d" % [c["make"], c["model"], c["cls"], l["car"]["stats"]["pi"], l["seller"], l["car"]["odometer_km"], _upg_sum(l["car"]["upgrades"])], 18, UI.class_color(c["cls"]))
				lab.size_flags_horizontal = Control.SIZE_EXPAND_FILL
				h.add_child(lab)
				if l["mine"]:
					h.add_child(UI.button("CANCEL", func(): _post("/api/market/listings/%d/cancel" % l["listing_id"]), UI.BAD, 46))
				else:
					h.add_child(UI.button("BUY %s" % Game.fmt_coins(l["price"]), func(): _post("/api/market/listings/%d/buy" % l["listing_id"]), UI.GOLD, 46))
				list.add_child(UI.panel(h))
		"sell":
			await Game.refresh_garage()
			for g in Game.garage:
				if g["listed"]:
					continue
				var c: Dictionary = g["car"]
				var h := UI.hbox(8)
				var lab := UI.label("%s %s [%s]" % [c["make"], c["model"], c["cls"]], 20)
				lab.size_flags_horizontal = Control.SIZE_EXPAND_FILL
				h.add_child(lab)
				var price := SpinBox.new()
				price.min_value = 500
				price.max_value = 50000000
				price.step = 500
				price.value = c["price"] * 0.8
				h.add_child(price)
				h.add_child(UI.button("LIST (5% fee)", func(): _list(g["id"], int(price.value)), UI.ACCENT, 46))
				list.add_child(UI.panel(h))

func _upg_sum(u: Dictionary) -> int:
	var s := 0
	for k in u:
		s += int(u[k])
	return s

func _car_row(c: Dictionary) -> Control:
	var h := UI.hbox(8)
	var v := UI.vbox(2)
	v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	v.add_child(UI.label("%s %s (%d)  [%s]" % [c["make"], c["model"], c["year"], c["cls"]], 22, UI.class_color(c["cls"])))
	v.add_child(UI.label("%s %s | %d hp | %d km/h | 0-100 %.1fs | PI %d" % [c["body"], c["drive"], c["power_hp"], c["top_kmh"], c["accel_s"], c["pi"]], 16, UI.DIM))
	h.add_child(v)
	var price: int = c["deal_price"] if c["deal_price"] != null else c["price"]
	var txt := ("DEAL %s" if c["deal_price"] != null else "BUY %s") % Game.fmt_coins(price)
	var b := UI.button(txt, func(): _post("/api/market/buy", {"car_id": c["id"]}), UI.GOLD if c["deal_price"] == null else UI.ACCENT2, 52)
	h.add_child(b)
	return UI.panel(h)

func _post(path: String, body: Dictionary = {}) -> void:
	var r := await Net.api("POST", path, body)
	if r.ok:
		UI.toast(get_tree().current_scene, "Done")
		if r.data.has("user"):
			Game.set_user(r.data["user"])
		else:
			Game.refresh_user()
		Game.refresh_garage()
	else:
		UI.toast(get_tree().current_scene, r.data.get("error", "Error"), false)
	if is_inside_tree():
		_load()

func _list(gid: int, price: int) -> void:
	await _post("/api/market/list", {"garage_id": gid, "price": price})
