extends Control

var user_in: LineEdit
var pass_in: LineEdit
var url_in: LineEdit
var msg: Label
var busy := false

func _ready() -> void:
	theme = UI.make_theme()
	var bg := ColorRect.new()
	bg.color = UI.BG
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(bg)
	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(center)
	var box := UI.vbox(12)
	box.custom_minimum_size = Vector2(460, 0)
	center.add_child(UI.panel(box))
	box.add_child(UI.label("APEX RUSH", 56, UI.ACCENT))
	box.add_child(UI.label("Online street racing", 20, UI.DIM))
	user_in = UI.line("Username", Settings.username)
	pass_in = UI.line("Password", "", true)
	url_in = UI.line("Server URL", Settings.api_url)
	box.add_child(user_in)
	box.add_child(pass_in)
	box.add_child(UI.button("LOGIN", func(): _go(false), UI.ACCENT))
	box.add_child(UI.button("CREATE ACCOUNT", func(): _go(true), UI.ACCENT2))
	box.add_child(UI.label("Server (change if hosting yourself):", 16, UI.DIM))
	box.add_child(url_in)
	msg = UI.label("", 18, UI.BAD)
	box.add_child(msg)

func _go(register: bool) -> void:
	if busy:
		return
	busy = true
	Settings.api_url = url_in.text.strip_edges().trim_suffix("/")
	# derive ws url from api url: http(s)://host:8000 -> ws(s)://host:8765
	var host := Settings.api_url.replace("https://", "").replace("http://", "").get_slice(":", 0).get_slice("/", 0)
	Settings.ws_url = ("wss://" if Settings.api_url.begins_with("https") else "ws://") + host + ":8765"
	msg.text = "Connecting..."
	msg.add_theme_color_override("font_color", UI.DIM)
	var err := await Game.login(user_in.text.strip_edges(), pass_in.text, register)
	busy = false
	if err != "":
		msg.text = err
		msg.add_theme_color_override("font_color", UI.BAD)
		return
	Settings.save_settings()
	get_tree().change_scene_to_file("res://scenes/menu.tscn")
