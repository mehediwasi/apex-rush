extends VBoxContainer

var list := UI.vbox(4)

func _ready() -> void:
	add_theme_constant_override("separation", 8)
	var row := UI.hbox(8)
	for k in ["level", "wins", "guilds"]:
		row.add_child(UI.button("TOP " + k.to_upper(), func(): _load(k)))
	add_child(row)
	add_child(UI.scroll(list))
	_load("level")

func _load(kind: String) -> void:
	var r := await Net.api("GET", "/api/leaderboard/" + kind)
	if not is_inside_tree():
		return
	UI.clear(list)
	if not r.ok:
		return
	var i := 1
	for row in r.data["rows"]:
		var txt := "#%d  " % i
		if kind == "guilds":
			txt += "[%s] %s   LV %d   %d members   %d xp" % [row["tag"], row["name"], row["level"], row["members"], row["xp"]]
		elif kind == "wins":
			txt += "%s   %d wins / %d races" % [row["username"], row["wins"], row["races"]]
		else:
			txt += "%s   LV %d   %d xp" % [row["username"], row["level"], row["xp"]]
		list.add_child(UI.panel(UI.label(txt, 20)))
		i += 1
