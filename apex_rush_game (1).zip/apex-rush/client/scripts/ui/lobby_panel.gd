extends VBoxContainer
## Lobby browser + room (FF-style: players list, ready, host start, chat).

var list := UI.vbox(6)
var room := UI.vbox(8)
var chat_box := UI.vbox(2)
var chat_in: LineEdit
var track_opt: OptionButton
var laps_spin: SpinBox

func _ready() -> void:
	add_theme_constant_override("separation", 8)
	Game.load_tracks()
	Net.ws_message.connect(_on_ws)
	add_child(UI.scroll(list))
	add_child(UI.scroll(room))
	_refresh()
	if not Game.lobby.is_empty():
		_show_room()
	else:
		_show_browser()

func _refresh() -> void:
	if not Net.authed:
		await get_tree().create_timer(0.8).timeout
	if is_inside_tree():
		Net.send({"t": "lobby.list"})

func _show_browser() -> void:
	room.get_parent().visible = false
	list.get_parent().visible = true
	UI.clear(list)
	list.add_child(UI.label("LOBBIES", 30, UI.ACCENT))
	var top := UI.hbox(8)
	top.add_child(UI.button("QUICK MATCH", func(): Net.send({"t": "matchmaking.quick"}), UI.ACCENT, 56))
	top.add_child(UI.button("REFRESH", func(): Net.send({"t": "lobby.list"}), Color(0, 0, 0, 0), 56))
	list.add_child(top)
	list.add_child(UI.label("CREATE LOBBY", 22, UI.ACCENT2))
	var cr := UI.hbox(8)
	track_opt = OptionButton.new()
	for t in Game.tracks:
		track_opt.add_item("%s (%.1f km, %s)" % [t["name"], t["length_m"] / 1000.0, t["theme"]])
	track_opt.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	cr.add_child(track_opt)
	laps_spin = SpinBox.new()
	laps_spin.min_value = 1
	laps_spin.max_value = 10
	laps_spin.value = 2
	laps_spin.prefix = "Laps "
	cr.add_child(laps_spin)
	list.add_child(cr)
	var pw := UI.line("Optional password")
	list.add_child(pw)
	list.add_child(UI.button("CREATE", func(): Net.send({"t": "lobby.create", "track_id": Game.tracks[track_opt.selected]["id"], "laps": int(laps_spin.value), "password": pw.text}), UI.ACCENT2))
	list.add_child(UI.label("OPEN LOBBIES", 22, UI.ACCENT))

func _show_room() -> void:
	list.get_parent().visible = false
	room.get_parent().visible = true
	var m := Game.lobby
	UI.clear(room)
	var is_host: bool = m.get("host", -1) == Game.user.get("id", -2)
	room.add_child(UI.label("%s   -   %s   %.1f km x %d laps" % [m["name"], m["track_name"], m["length_m"] / 1000.0, m["laps"]], 26, UI.ACCENT))
	for p in m["players"]:
		var h := UI.hbox(8)
		var tag: String = ("[%s] " % p["tag"]) if p["tag"] != "" else ""
		var c: Dictionary = p["car"]
		var lab := UI.label("%s%s  LV %d   %s %s [%s] PI %d" % [tag, p["name"], p["level"], c["make"], c["model"], c["cls"], c["pi"]], 20, UI.class_color(c["cls"]))
		lab.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		h.add_child(lab)
		var host_mark := "HOST" if p["uid"] == m["host"] else ("READY" if p["ready"] else "...")
		h.add_child(UI.label(host_mark, 18, UI.GOOD if p["ready"] else UI.DIM))
		if is_host and p["uid"] != m["host"]:
			h.add_child(UI.button("KICK", func(): Net.send({"t": "lobby.kick", "uid": p["uid"]}), UI.BAD, 38))
		room.add_child(UI.panel(h))
	var row := UI.hbox(8)
	row.add_child(UI.button("MY CAR", func(): Net.send({"t": "lobby.car"}), Color(0, 0, 0, 0), 56))
	if is_host:
		row.add_child(UI.button("START RACE", func(): Net.send({"t": "lobby.start"}), UI.GOOD, 56))
	else:
		var me_ready := false
		for p in m["players"]:
			if p["uid"] == Game.user.get("id"):
				me_ready = p["ready"]
		row.add_child(UI.button("READY" if not me_ready else "UNREADY", func(): Net.send({"t": "lobby.ready", "ready": not me_ready}), UI.GOOD, 56))
	row.add_child(UI.button("LEAVE", func(): Net.send({"t": "lobby.leave"}), UI.BAD, 56))
	room.add_child(row)
	if is_host:
		var sr := UI.hbox(8)
		var to := OptionButton.new()
		var sel := 0
		for i in Game.tracks.size():
			var t = Game.tracks[i]
			to.add_item("%s (%.1f km)" % [t["name"], t["length_m"] / 1000.0])
			if t["id"] == m["track_id"]:
				sel = i
		to.selected = sel
		to.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		to.item_selected.connect(func(i): Net.send({"t": "lobby.settings", "track_id": Game.tracks[i]["id"]}))
		sr.add_child(to)
		var lp := SpinBox.new()
		lp.min_value = 1
		lp.max_value = 10
		lp.value = m["laps"]
		lp.value_changed.connect(func(v): Net.send({"t": "lobby.settings", "laps": int(v)}))
		sr.add_child(lp)
		room.add_child(sr)
	room.add_child(UI.label("LOBBY CHAT", 20, UI.ACCENT))
	room.add_child(UI.panel(chat_box))
	var cr := UI.hbox(8)
	chat_in = UI.line("Say something")
	chat_in.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	chat_in.text_submitted.connect(func(_t): _chat())
	cr.add_child(chat_in)
	cr.add_child(UI.button("SEND", _chat, UI.ACCENT))
	room.add_child(cr)

func _chat() -> void:
	if chat_in.text.strip_edges() != "":
		Net.send({"t": "chat", "scope": "lobby", "msg": chat_in.text})
		chat_in.text = ""

func _on_ws(m: Dictionary) -> void:
	match m.get("t", ""):
		"lobby.list":
			if not list.get_parent().visible:
				return
			# remove previously rendered lobby rows (everything after the header block)
			for c in list.get_children():
				if c.has_meta("lobby_row"):
					c.queue_free()
			for l in m["lobbies"]:
				var h := UI.hbox(8)
				var lab := UI.label("%s  -  %s  %d/%d  %s%s" % [l["name"], str(l["track_id"]).replace("map_", "").replace("_", " "), l["players"], l["max"], l["state"], "  LOCKED" if l["locked"] else ""], 18)
				lab.size_flags_horizontal = Control.SIZE_EXPAND_FILL
				h.add_child(lab)
				h.add_child(UI.button("JOIN", func(): Net.send({"t": "lobby.join", "id": l["id"]}), UI.ACCENT, 44))
				var p := UI.panel(h)
				p.set_meta("lobby_row", true)
				list.add_child(p)
		"lobby.state":
			_show_room()
		"lobby.left":
			_show_browser()
			Net.send({"t": "lobby.list"})
		"chat":
			if m.get("scope", "") == "lobby" and is_instance_valid(chat_box):
				chat_box.add_child(UI.label("%s: %s" % [m["from"], m["msg"]], 18))
