extends Control

func _ready() -> void:
	await get_tree().process_frame
	if Settings.token != "" and await Game.restore_session():
		get_tree().change_scene_to_file("res://scenes/menu.tscn")
	else:
		get_tree().change_scene_to_file("res://scenes/login.tscn")
