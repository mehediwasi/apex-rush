class_name TouchControls
extends Control
## On-screen controls for phones. Buttons simply press/release the same InputMap actions as the keyboard.

func _ready() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_btn("<", "steer_left", Vector2(0.02, 0.62), Vector2(0.13, 0.30))
	_btn(">", "steer_right", Vector2(0.16, 0.62), Vector2(0.13, 0.30))
	_btn("GAS", "accelerate", Vector2(0.84, 0.60), Vector2(0.14, 0.34))
	_btn("BRAKE", "brake", Vector2(0.70, 0.72), Vector2(0.13, 0.22))
	_btn("NITRO", "nitro", Vector2(0.84, 0.36), Vector2(0.14, 0.20))
	_btn("DRIFT", "handbrake", Vector2(0.70, 0.46), Vector2(0.13, 0.22))

func _btn(text: String, action: String, anchor_pos: Vector2, anchor_size: Vector2) -> void:
	var b := Button.new()
	b.text = text
	b.focus_mode = Control.FOCUS_NONE
	b.action_mode = BaseButton.ACTION_MODE_BUTTON_PRESS
	b.anchor_left = anchor_pos.x
	b.anchor_top = anchor_pos.y
	b.anchor_right = anchor_pos.x + anchor_size.x
	b.anchor_bottom = anchor_pos.y + anchor_size.y
	b.modulate = Color(1, 1, 1, 0.55)
	b.add_theme_font_size_override("font_size", 28)
	b.button_down.connect(func(): Input.action_press(action))
	b.button_up.connect(func(): Input.action_release(action))
	add_child(b)
