class_name RaceHUD
extends Control

var speed_l: Label
var gear_l: Label
var lap_l: Label
var pos_l: Label
var time_l: Label
var big_l: Label
var banner_l: Label
var rpm_bar: ProgressBar
var nitro_bar: ProgressBar
var info_l: Label
var mini: Control
var pts: Array = []
var dots: Dictionary = {}      # uid -> Vector3
var me := Vector3.ZERO
var _banner_t := 0.0
var kmh_l: Label

func _ready() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	theme = UI.make_theme()
	speed_l = UI.label("0", 72, UI.TEXT)
	add_child(speed_l)
	var kmh := UI.label("km/h", 22, UI.DIM)
	kmh.position = Vector2(30, -105)
	add_child(kmh)
	gear_l = UI.label("1", 48, UI.ACCENT)
	add_child(gear_l)
	rpm_bar = UI.bar(0, 7000, UI.ACCENT2)
	rpm_bar.custom_minimum_size = Vector2(260, 14)
	add_child(rpm_bar)
	nitro_bar = UI.bar(0, 100, UI.ACCENT)
	nitro_bar.custom_minimum_size = Vector2(260, 14)
	add_child(nitro_bar)
	lap_l = UI.label("", 34)
	add_child(lap_l)
	pos_l = UI.label("", 56, UI.GOLD)
	add_child(pos_l)
	time_l = UI.label("", 30)
	add_child(time_l)
	big_l = UI.label("", 140, UI.ACCENT)
	add_child(big_l)
	banner_l = UI.label("", 44, UI.ACCENT2)
	add_child(banner_l)
	info_l = UI.label("", 16, UI.DIM)
	add_child(info_l)
	mini = Control.new()
	mini.custom_minimum_size = Vector2(200, 200)
	mini.size = Vector2(200, 200)
	mini.draw.connect(_draw_mini)
	add_child(mini)
	kmh_l = kmh
	resized.connect(_layout)
	_layout()

func set_track(cl: Array) -> void:
	pts = cl

func banner(text: String, secs := 2.0) -> void:
	banner_l.text = text
	_banner_t = secs

func _process(delta: float) -> void:
	if _banner_t > 0.0:
		_banner_t -= delta
		if _banner_t <= 0.0:
			banner_l.text = ""
	mini.queue_redraw()

func _draw_mini() -> void:
	if pts.size() < 2:
		return
	var mnx := 1e9
	var mxx := -1e9
	var mnz := 1e9
	var mxz := -1e9
	for p in pts:
		mnx = minf(mnx, p[0])
		mxx = maxf(mxx, p[0])
		mnz = minf(mnz, p[2])
		mxz = maxf(mxz, p[2])
	var s := 180.0 / maxf(mxx - mnx, mxz - mnz)
	var f := func(x: float, z: float) -> Vector2: return Vector2((x - mnx) * s + 10, (z - mnz) * s + 10)
	mini.draw_rect(Rect2(0, 0, 200, 200), Color(0, 0, 0, 0.35))
	var line := PackedVector2Array()
	for p in pts:
		line.append(f.call(p[0], p[2]))
	line.append(line[0])
	mini.draw_polyline(line, Color(1, 1, 1, 0.7), 3.0)
	for uid in dots:
		mini.draw_circle(f.call(dots[uid].x, dots[uid].z), 4.0, UI.ACCENT2)
	mini.draw_circle(f.call(me.x, me.z), 6.0, UI.ACCENT)

func _layout() -> void:
	var w := size.x
	var h := size.y
	lap_l.position = Vector2(24, 20)
	pos_l.position = Vector2(24, 60)
	speed_l.position = Vector2(30, h - 200)
	kmh_l.position = Vector2(30, h - 112)
	gear_l.position = Vector2(230, h - 180)
	rpm_bar.position = Vector2(30, h - 80)
	rpm_bar.size = Vector2(260, 14)
	nitro_bar.position = Vector2(30, h - 56)
	nitro_bar.size = Vector2(260, 14)
	time_l.position = Vector2(w * 0.5 - 70, 16)
	big_l.position = Vector2(w * 0.5 - 70, h * 0.5 - 190)
	banner_l.position = Vector2(w * 0.5 - 220, 110)
	info_l.position = Vector2(w - 210, 14)
	mini.position = Vector2(w - 220, 50)
