extends Node3D
## Race scene: builds track + environment, drives the local car, syncs with the server.
## Online: server is authoritative for start time, checkpoints, results, rewards.
## Offline (free drive): same logic locally, no rewards.

var ctx: Dictionary
var offline := true
var data: Dictionary
var track: Dictionary
var car: CarController
var hud: RaceHUD
var cam: Camera3D
var sun: DirectionalLight3D
var audio: EngineAudio
var remotes := {}
var cps: Array = []
var laps := 2
var cp_count := 0
var next_cp := 1
var start_at := 0.0
var finished := false
var my_uid := 0
var night := false
var takedowns := 0
var last_reset: Transform3D
var _send_t := 0.0
var _cam_mode := 0
var _flip_t := 0.0
var _wrong_t := 0.0
var _nearest := 0
var _go_t := 0.0
var _overlay: CanvasLayer
var _pause_ui: Control
var _res_shown := false
var _local_finish_ms := 0.0

func _ready() -> void:
	ctx = Game.race_ctx
	offline = ctx.get("offline", true)
	data = Game.load_track_data(ctx.get("track_id", ""))
	if data.is_empty():
		get_tree().change_scene_to_file("res://scenes/menu.tscn")
		return
	laps = int(ctx.get("laps", 2))
	my_uid = int(Game.user.get("id", 0))
	_apply_quality()
	track = TrackBuilder.build(data)
	add_child(track["node"])
	night = track["theme"]["sky"] == "night"
	_build_environment(String(track["theme"]["sky"]))
	cps = ctx.get("checkpoints", [])
	if cps.is_empty():
		cps = _make_cps(data["centerline"])
	var cl: Array = data["centerline"]
	var dirv := Vector2(cl[1][0] - cl[0][0], cl[1][2] - cl[0][2]).normalized()
	if ctx.has("dir"):
		dirv = Vector2(ctx["dir"][0], ctx["dir"][1])
	var grid: Dictionary = ctx.get("grid", {})
	var my_info := {}
	for p in ctx.get("players", []):
		if int(p["uid"]) == my_uid:
			my_info = p
	var spawn := Vector3(cl[0][0] - dirv.x * 8.0 + (-dirv.y) * 3.2, cl[0][1] + 1.0, cl[0][2] - dirv.y * 8.0 + dirv.x * 3.2)
	if grid.has(str(my_uid)):
		var g: Array = grid[str(my_uid)]
		spawn = Vector3(g[0], g[1], g[2])
	var grid_basis := Basis.looking_at(Vector3(dirv.x, 0, dirv.y), Vector3.UP)
	# local car
	car = CarController.new()
	add_child(car)
	car.setup(_norm_car(my_info.get("car", Game.selected_car())), true, night)
	car.global_transform = Transform3D(grid_basis, spawn + Vector3(0, 0.6, 0))
	last_reset = car.global_transform
	car.drift_charged.connect(func(_a): pass)
	# remote cars
	if not offline:
		for p in ctx.get("players", []):
			var uid := int(p["uid"])
			if uid == my_uid:
				continue
			var rc := RemoteCar.new()
			add_child(rc)
			var info := {"uid": uid, "name": p["name"], "tag": p.get("tag", ""), "car": _norm_car(p["car"])}
			rc.setup(info)
			var g: Array = grid.get(str(uid), [spawn.x, spawn.y, spawn.z])
			rc.global_transform = Transform3D(grid_basis, Vector3(g[0], g[1] + 0.4, g[2]))
			rc.hit.connect(_on_remote_hit)
			remotes[uid] = rc
	# camera / HUD / controls / audio
	cam = Camera3D.new()
	cam.far = 1800.0
	cam.fov = 66.0
	add_child(cam)
	cam.current = true
	cam.global_position = car.global_position + Vector3(0, 3, 7)
	_overlay = CanvasLayer.new()
	add_child(_overlay)
	hud = RaceHUD.new()
	_overlay.add_child(hud)
	hud.set_track(data["centerline"])
	if DisplayServer.is_touchscreen_available() or OS.has_feature("mobile"):
		_overlay.add_child(TouchControls.new())
	var pb := UI.button("II", _toggle_pause, Color(0, 0, 0, 0.0), 56)
	pb.set_anchors_preset(Control.PRESET_TOP_LEFT)
	pb.position = Vector2(300, 12)
	pb.theme = UI.make_theme()
	_overlay.add_child(pb)
	audio = EngineAudio.new()
	audio.cylinders = 8 if car.stats.get("power_hp", 200) > 450 else (6 if car.stats.get("power_hp", 200) > 250 else 4)
	add_child(audio)
	start_at = float(ctx.get("start_at", 0.0)) if not offline else Time.get_unix_time_from_system() * 1000.0 + 4000.0
	if not offline:
		Net.ws_message.connect(_on_ws)

func _exit_tree() -> void:
	Engine.physics_ticks_per_second = 120
	for a in ["accelerate", "brake", "steer_left", "steer_right", "handbrake", "nitro"]:
		Input.action_release(a)
	if Net.ws_message.is_connected(_on_ws):
		Net.ws_message.disconnect(_on_ws)

# ------------------------------------------------------------------ setup helpers
func _norm_car(c: Dictionary) -> Dictionary:
	if c.has("body") and c.has("stats"):
		return c
	if c.has("car") and c.has("stats"):          # garage entry from REST API
		return {"body": c["car"]["body"], "color": c["color"], "stats": c["stats"], "wheel_style": c.get("wheel_style", 0), "neon": c.get("neon", "")}
	return {"body": "sedan", "color": "#d01818", "wheel_style": 0, "neon": "",
		"stats": {"power_hp": 180, "mass_kg": 1300, "top_kmh": 200, "accel_s": 7.5, "handling": 60, "grip": 70, "braking": 60, "nitro_tank": 100, "drive": "RWD"}}

func _make_cps(cl: Array) -> Array:
	var out := [cl[0]]
	var acc := 0.0
	var last: Array = cl[0]
	for i in range(1, cl.size()):
		acc += Vector2(cl[i][0] - last[0], cl[i][2] - last[2]).length()
		last = cl[i]
		if acc >= 110.0:
			out.append(cl[i])
			acc = 0.0
	return out

func _apply_quality() -> void:
	var q := Settings.quality
	var vp := get_viewport()
	vp.msaa_3d = [Viewport.MSAA_DISABLED, Viewport.MSAA_2X, Viewport.MSAA_4X, Viewport.MSAA_4X][q]
	vp.scaling_3d_scale = [0.67, 0.85, 1.0, 1.0][q]
	Engine.physics_ticks_per_second = 60 if q == 0 else 120

func _build_environment(sky_kind: String) -> void:
	var q := Settings.quality
	var env := Environment.new()
	var sky := Sky.new()
	var sm := ProceduralSkyMaterial.new()
	var sun_rot := Vector3(-48, -30, 0)
	var sun_col := Color(1, 0.97, 0.9)
	var sun_e := 1.3
	match sky_kind:
		"sunset":
			sm.sky_top_color = Color(0.18, 0.2, 0.45)
			sm.sky_horizon_color = Color(1.0, 0.55, 0.3)
			sm.ground_horizon_color = Color(0.9, 0.5, 0.3)
			sun_rot = Vector3(-9, -60, 0)
			sun_col = Color(1.0, 0.6, 0.35)
			sun_e = 1.2
		"night":
			sm.sky_top_color = Color(0.01, 0.02, 0.07)
			sm.sky_horizon_color = Color(0.06, 0.07, 0.18)
			sm.ground_horizon_color = Color(0.05, 0.06, 0.12)
			sun_rot = Vector3(-35, -30, 0)
			sun_col = Color(0.45, 0.55, 1.0)
			sun_e = 0.22
		_:
			sm.sky_top_color = Color(0.25, 0.45, 0.85)
			sm.sky_horizon_color = Color(0.68, 0.78, 0.92)
			sm.ground_horizon_color = Color(0.62, 0.66, 0.7)
	sky.sky_material = sm
	env.background_mode = Environment.BG_SKY
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.reflected_light_source = Environment.REFLECTION_SOURCE_SKY
	env.tonemap_mode = Environment.TONE_MAPPER_ACES
	env.tonemap_exposure = 1.0
	env.glow_enabled = q >= 1
	env.glow_intensity = 0.9
	env.glow_bloom = 0.08
	env.ssao_enabled = q >= 2
	env.ssr_enabled = q >= 3
	env.ssil_enabled = q >= 3
	env.fog_enabled = true
	env.fog_light_color = sm.sky_horizon_color
	env.fog_density = 0.0006
	if q >= 3 and not OS.has_feature("mobile"):
		env.volumetric_fog_enabled = true
		env.volumetric_fog_density = 0.006 if sky_kind == "day" else 0.012
	env.adjustment_enabled = true
	env.adjustment_saturation = 1.15
	env.adjustment_contrast = 1.07
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)
	sun = DirectionalLight3D.new()
	sun.rotation_degrees = sun_rot
	sun.light_color = sun_col
	sun.light_energy = sun_e
	sun.shadow_enabled = q >= 1
	sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_4_SPLITS if q >= 2 else DirectionalLight3D.SHADOW_PARALLEL_2_SPLITS
	sun.directional_shadow_max_distance = [80.0, 150.0, 260.0, 420.0][q]
	add_child(sun)

# ------------------------------------------------------------------ loop
func _now_ms() -> float:
	return Time.get_unix_time_from_system() * 1000.0 if offline else Net.server_now_ms()

func _physics_process(delta: float) -> void:
	if car == null:
		return
	var now := _now_ms()
	var to_go := start_at - now
	if to_go > 0.0:
		car.locked = true
		hud.big_l.text = str(int(ceil(to_go / 1000.0))) if to_go <= 4000.0 else ""
	elif car.locked:
		car.locked = false
		hud.big_l.text = "GO!"
		_go_t = 0.9
	if _go_t > 0.0:
		_go_t -= delta
		if _go_t <= 0.0:
			hud.big_l.text = ""
	_check_checkpoints()
	_track_progress()
	_recovery(delta)
	if not offline:
		_send_t -= delta
		if _send_t <= 0.0 and to_go < 300.0:
			_send_t = 0.05
			var p := car.global_position
			var q := car.global_transform.basis.get_rotation_quaternion()
			Net.send({"t": "race.state", "p": [snappedf(p.x, 0.01), snappedf(p.y, 0.01), snappedf(p.z, 0.01)],
				"r": [snappedf(q.x, 0.001), snappedf(q.y, 0.001), snappedf(q.z, 0.001), snappedf(q.w, 0.001)], "v": snappedf(car.speed_ms, 0.1)})
	if Input.is_action_just_pressed("reset_car"):
		_reset_car()
	if Input.is_action_just_pressed("pause"):
		_toggle_pause()
	_update_hud(now)
	audio.rpm = car.rpm
	audio.load_amt = Input.get_action_strength("accelerate")

func _check_checkpoints() -> void:
	if finished or car.locked or cps.is_empty():
		return
	var cp: Array = cps[next_cp]
	var p := car.global_position
	if Vector2(p.x - cp[0], p.z - cp[2]).length() < 32.0 and absf(p.y - cp[1]) < 25.0:
		cp_count += 1
		if not offline:
			Net.send({"t": "race.cp", "i": next_cp})
		var nxt: Array = cps[(next_cp + 1) % cps.size()]
		var d := Vector3(nxt[0] - cp[0], 0, nxt[2] - cp[2]).normalized()
		last_reset = Transform3D(Basis.looking_at(d, Vector3.UP), Vector3(cp[0], cp[1] + 1.2, cp[2]))
		next_cp = (next_cp + 1) % cps.size()
		if cp_count >= laps * cps.size():
			_finish()
		elif next_cp == 1:
			hud.banner("LAP %d / %d" % [cp_count / cps.size() + 1, laps], 1.8)

func _finish() -> void:
	finished = true
	_local_finish_ms = _now_ms() - start_at
	hud.banner("FINISHED  %s" % Game.fmt_time(_local_finish_ms), 4.0)
	if offline:
		await get_tree().create_timer(2.5).timeout
		_show_results({"rows": [{"pos": 1, "name": Game.user.get("username", "You"), "time_ms": _local_finish_ms, "dnf": false, "coins": 0, "xp": 0, "takedowns": 0}], "offline": true})

func _track_progress() -> void:
	var pts: Array[Vector3] = track["pts"]
	var p := car.global_position
	var best := 1e12
	var n := pts.size()
	for k in range(-30, 31):
		var i := (_nearest + k + n) % n
		var d := p.distance_squared_to(pts[i])
		if d < best:
			best = d
			_nearest = i
	var t := (pts[(_nearest + 2) % n] - pts[_nearest]).normalized()
	var f := -car.global_transform.basis.z
	if car.speed_ms > 6.0 and f.dot(t) < -0.35 and car.fwd_speed > 0.0:
		_wrong_t += get_physics_process_delta_time()
		if _wrong_t > 1.2:
			hud.banner("WRONG WAY", 0.3)
	else:
		_wrong_t = 0.0

func _recovery(delta: float) -> void:
	if car.global_position.y < track["ground_y"] - 4.0:
		_reset_car()
	if car.global_transform.basis.y.y < 0.15 and car.speed_ms < 4.0:
		_flip_t += delta
		if _flip_t > 2.5:
			_reset_car()
	else:
		_flip_t = 0.0

func _reset_car() -> void:
	car.reset_to(last_reset)
	_flip_t = 0.0

func _progress(count: int, pos: Vector3) -> float:
	var cp: Array = cps[(count + 1) % cps.size()]
	var d := Vector2(pos.x - cp[0], pos.z - cp[2]).length()
	return float(count) + 1.0 - clampf(d / 110.0, 0.0, 1.0)

func _update_hud(now: float) -> void:
	hud.speed_l.text = str(int(car.speed_ms * 3.6))
	hud.gear_l.text = "R" if car.fwd_speed < -1.0 else str(car.gear)
	hud.rpm_bar.value = car.rpm
	hud.nitro_bar.value = car.nitro / car.nitro_max * 100.0
	hud.lap_l.text = "LAP %d / %d" % [mini(cp_count / maxi(cps.size(), 1) + 1, laps), laps]
	var mine := _progress(cp_count, car.global_position)
	var rank := 1
	for uid in remotes:
		var r: RemoteCar = remotes[uid]
		if _progress(r.cp_count, r.global_position) > mine:
			rank += 1
		hud.dots[uid] = r.global_position
	hud.me = car.global_position
	hud.pos_l.text = "%d/%d" % [rank, remotes.size() + 1] if not offline else ""
	var t_ms := (_local_finish_ms if finished else maxf(0.0, now - start_at))
	hud.time_l.text = Game.fmt_time(t_ms)
	hud.info_l.text = ("%d FPS  %d ms" % [Engine.get_frames_per_second(), int(Net.rtt_ms)]) if Settings.show_fps else ""

func _process(delta: float) -> void:
	if car == null or cam == null:
		return
	if Input.is_action_just_pressed("camera"):
		_cam_mode = (_cam_mode + 1) % 3
	var vel := car.linear_velocity
	var f := -car.global_transform.basis.z
	f.y = 0.0
	f = f.normalized()
	var spd := car.speed_ms
	var dir := f
	if spd > 8.0:
		var vflat := Vector3(vel.x, 0, vel.z).normalized()
		dir = f.slerp(vflat, 0.35).normalized()
	var target: Vector3
	var look: Vector3
	match _cam_mode:
		1:
			target = car.global_position + car.global_transform.basis * Vector3(0, 1.05, -0.5)
			cam.global_position = target
			cam.global_transform.basis = car.global_transform.basis
			cam.fov = lerpf(cam.fov, 74.0 + clampf(spd * 0.2, 0.0, 20.0), 4.0 * delta)
			return
		2:
			target = car.global_position - dir * (10.0 + spd * 0.03) + Vector3.UP * 4.2
		_:
			target = car.global_position - dir * (6.0 + spd * 0.02) + Vector3.UP * (2.1 + spd * 0.004)
	cam.global_position = cam.global_position.lerp(target, 1.0 - exp(-9.0 * delta))
	look = car.global_position + Vector3.UP * 1.1 + dir * 3.0
	cam.look_at(look, Vector3.UP)
	var fov_t := 62.0 + clampf(spd * 0.32, 0.0, 26.0) + (9.0 if car.nitro_active else 0.0)
	cam.fov = lerpf(cam.fov, fov_t, 3.0 * delta)
	if car.nitro_active:
		cam.h_offset = randf_range(-0.03, 0.03)
		cam.v_offset = randf_range(-0.03, 0.03)
	else:
		cam.h_offset = 0.0
		cam.v_offset = 0.0

# ------------------------------------------------------------------ network
func _on_ws(m: Dictionary) -> void:
	match m.get("t", ""):
		"race.snap":
			var ts := float(m["ts"])
			for key in m["p"]:
				var uid := int(key)
				if uid == my_uid or not remotes.has(uid):
					continue
				var e: Array = m["p"][key]
				(remotes[uid] as RemoteCar).push_snapshot(ts, e[0], e[1], float(e[2]), int(e[3]))
		"race.takedown":
			var a := int(m["attacker"])
			var v := int(m["victim"])
			if a == my_uid:
				takedowns += 1
				car.add_nitro(40.0)
				hud.banner("TAKEDOWN!  +BOOST", 2.0)
			elif v == my_uid:
				car.wreck(2.2)
				hud.banner("WRECKED by %s" % m.get("attacker_name", "?"), 2.0)
			else:
				hud.banner("%s took down %s" % [m.get("attacker_name", "?"), m.get("victim_name", "?")], 1.6)
		"race.finished":
			if int(m["uid"]) == my_uid:
				hud.banner("FINISHED  %s" % Game.fmt_time(float(m["time_ms"])), 4.0)
			else:
				hud.banner("%s finished" % m["name"], 1.8)
		"race.results":
			_show_results(m)
		"error":
			hud.banner(str(m.get("msg", "")), 2.5)

func _on_remote_hit(uid: int, rel_speed: float) -> void:
	if offline or car.locked or rel_speed < 11.0:
		return
	Net.send({"t": "race.takedown", "target": uid})

# ------------------------------------------------------------------ UI overlays
func _show_results(m: Dictionary) -> void:
	if _res_shown:
		return
	_res_shown = true
	var root := Control.new()
	root.theme = UI.make_theme()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.75)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.add_child(dim)
	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.add_child(center)
	var box := UI.vbox(8)
	box.custom_minimum_size = Vector2(640, 0)
	center.add_child(UI.panel(box))
	box.add_child(UI.label("RESULTS", 44, UI.ACCENT))
	for r in m["rows"]:
		var t := "DNF" if r["dnf"] else Game.fmt_time(float(r["time_ms"]))
		var line := "#%d  %s   %s" % [r["pos"], r["name"], t]
		if not m.get("offline", false):
			line += "   +%s coins  +%d xp" % [Game.fmt_coins(r["coins"]), r["xp"]]
			if r["takedowns"] > 0:
				line += "   %d TD" % r["takedowns"]
		var me := int(r.get("uid", -1)) == my_uid or m.get("offline", false)
		box.add_child(UI.label(line, 22, UI.GOLD if me else UI.TEXT))
	box.add_child(UI.button("CONTINUE", _exit_to_menu, UI.ACCENT, 60))
	_overlay.add_child(root)

func _toggle_pause() -> void:
	if _pause_ui and is_instance_valid(_pause_ui):
		_pause_ui.queue_free()
		_pause_ui = null
		return
	var root := Control.new()
	root.theme = UI.make_theme()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.add_child(center)
	var box := UI.vbox(10)
	box.custom_minimum_size = Vector2(420, 0)
	center.add_child(UI.panel(box))
	box.add_child(UI.label("PAUSED", 40, UI.ACCENT))
	if not offline:
		box.add_child(UI.label("Online race keeps running while paused.", 16, UI.DIM))
	box.add_child(UI.button("RESUME", _toggle_pause, UI.ACCENT))
	box.add_child(UI.button("RESET CAR", func(): _reset_car(); _toggle_pause()))
	box.add_child(UI.button("QUIT RACE", _quit, UI.BAD))
	_overlay.add_child(root)
	_pause_ui = root

func _quit() -> void:
	if not offline:
		Net.send({"t": "lobby.leave"})
		Game.lobby = {}
	_exit_to_menu()

func _exit_to_menu() -> void:
	Game.refresh_user()
	get_tree().change_scene_to_file("res://scenes/menu.tscn")
