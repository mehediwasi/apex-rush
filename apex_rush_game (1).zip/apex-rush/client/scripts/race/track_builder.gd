class_name TrackBuilder
extends RefCounted
## Builds a drivable 3D track (road, curbs, walls, embankments, scenery) at runtime from a
## centerline JSON ([x,y,z] points, width_m). Collision groups: "road" (drivable), "wall", "ground".

const THEMES := {
	"forest":     {"ground": "1a5a1a", "road": "26262a", "scenery": "0d400d", "kind": "tree", "sky": "day"},
	"desert":     {"ground": "d9b873", "road": "38332f", "scenery": "8c5933", "kind": "rock", "sky": "day"},
	"snow":       {"ground": "eef2ff", "road": "33383f", "scenery": "26593a", "kind": "tree", "sky": "day"},
	"city":       {"ground": "404045", "road": "1a1a1c", "scenery": "737380", "kind": "building", "sky": "night"},
	"coastal":    {"ground": "ccc08c", "road": "2e2e33", "scenery": "4d804d", "kind": "tree", "sky": "sunset"},
	"mountain":   {"ground": "667359", "road": "2b2b2e", "scenery": "808080", "kind": "rock", "sky": "day"},
	"neon":       {"ground": "08051a", "road": "14141f", "scenery": "e61acc", "kind": "building", "sky": "night"},
	"canyon":     {"ground": "a65933", "road": "332e2b", "scenery": "b34d26", "kind": "rock", "sky": "sunset"},
	"farmland":   {"ground": "73a640", "road": "333333", "scenery": "997333", "kind": "tree", "sky": "day"},
	"industrial": {"ground": "595954", "road": "1f1f21", "scenery": "806659", "kind": "building", "sky": "day"},
}

static func _mat(color: Color, rough := 0.9, metal := 0.0) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = rough
	m.metallic = metal
	m.cull_mode = BaseMaterial3D.CULL_DISABLED
	return m

static func _body(mesh: Mesh, group: String, mat: Material, trimesh := true) -> StaticBody3D:
	var b := StaticBody3D.new()
	b.add_to_group(group)
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = mat
	b.add_child(mi)
	if trimesh:
		var cs := CollisionShape3D.new()
		var sh := mesh.create_trimesh_shape()
		sh.backface_collision = true
		cs.shape = sh
		b.add_child(cs)
	var pm := PhysicsMaterial.new()
	pm.friction = 1.0
	b.physics_material_override = pm
	return b

static func _quad(st: SurfaceTool, a: Vector3, b: Vector3, c: Vector3, d: Vector3, n: Vector3, v0 := 0.0, v1 := 1.0) -> void:
	# a,b on one edge (u=0,1) at v0 ; d,c on next edge at v1
	for t in [[a, 0.0, v0], [b, 1.0, v0], [c, 1.0, v1], [a, 0.0, v0], [c, 1.0, v1], [d, 0.0, v1]]:
		st.set_normal(n)
		st.set_uv(Vector2(t[1], t[2]))
		st.add_vertex(t[0])

static func build(data: Dictionary) -> Dictionary:
	var theme_name: String = data.get("theme", "forest")
	var th: Dictionary = THEMES.get(theme_name, THEMES["forest"])
	var cl: Array = data["centerline"]
	var n := cl.size()
	var width: float = data.get("width_m", 12.0)
	var hw := width / 2.0
	var root := Node3D.new()
	root.name = "Track"
	var pts: Array[Vector3] = []
	var nor: Array[Vector3] = []
	var miny := 1e9
	for p in cl:
		pts.append(Vector3(p[0], p[1], p[2]))
		miny = minf(miny, p[1])
	for i in n:
		var a := pts[(i - 1 + n) % n]
		var b := pts[(i + 1) % n]
		var t := Vector3(b.x - a.x, 0, b.z - a.z).normalized()
		nor.append(Vector3(-t.z, 0, t.x))
	var ground_y := miny - 2.0
	var road := SurfaceTool.new()
	var mark := SurfaceTool.new()
	var curb_r := SurfaceTool.new()
	var curb_w := SurfaceTool.new()
	var wall := SurfaceTool.new()
	var emb := SurfaceTool.new()
	for s in [road, mark, curb_r, curb_w, wall, emb]:
		s.begin(Mesh.PRIMITIVE_TRIANGLES)
	var cw := 1.2
	var wo := hw + cw + 0.8
	var dist := 0.0
	for i in n:
		var j := (i + 1) % n
		var seg := pts[i].distance_to(pts[j])
		var v0 := dist / 10.0
		var v1 := (dist + seg) / 10.0
		dist += seg
		var up := Vector3.UP
		var l0 := pts[i] + nor[i] * hw
		var r0 := pts[i] - nor[i] * hw
		var l1 := pts[j] + nor[j] * hw
		var r1 := pts[j] - nor[j] * hw
		_quad(road, l0, r0, r1, l1, up, v0, v1)
		if (i / 3) % 2 == 0:
			var c := nor[i] * 0.12
			var c1 := nor[j] * 0.12
			_quad(mark, pts[i] + c + up * 0.02, pts[i] - c + up * 0.02, pts[j] - c1 + up * 0.02, pts[j] + c1 + up * 0.02, up)
		for side in [1.0, -1.0]:
			var e0: Vector3 = pts[i] + nor[i] * hw * side
			var e1: Vector3 = pts[j] + nor[j] * hw * side
			var o0: Vector3 = pts[i] + nor[i] * (hw + cw) * side
			var o1: Vector3 = pts[j] + nor[j] * (hw + cw) * side
			var lift := up * 0.03
			_quad(curb_r if (i / 3) % 2 == 0 else curb_w, e0 + lift, o0 + lift, o1 + lift, e1 + lift, up)
			# wall (vertical) + embankment sloping down to ground
			var w0: Vector3 = pts[i] + nor[i] * wo * side
			var w1: Vector3 = pts[j] + nor[j] * wo * side
			_quad(wall, w0, w1, w1 + up * 1.2, w0 + up * 1.2, nor[i] * side)
			var f0: Vector3 = pts[i] + nor[i] * (wo + 45.0) * side
			var f1: Vector3 = pts[j] + nor[j] * (wo + 45.0) * side
			f0.y = ground_y
			f1.y = ground_y
			_quad(emb, w0, f0, f1, w1, up)
			# shoulder between curb and wall
			_quad(emb, o0, w0, w1, o1, up)
	var road_tex := StandardMaterial3D.new()
	road_tex.albedo_color = Color(th["road"])
	road_tex.roughness = 0.82
	road_tex.cull_mode = BaseMaterial3D.CULL_DISABLED
	root.add_child(_body(road.commit(), "road", road_tex))
	root.add_child(_body(mark.commit(), "road", _mat(Color(0.95, 0.95, 0.9), 0.7), false))
	root.add_child(_body(curb_r.commit(), "road", _mat(Color(0.85, 0.08, 0.08), 0.6)))
	root.add_child(_body(curb_w.commit(), "road", _mat(Color(0.95, 0.95, 0.95), 0.6)))
	var wm := _mat(Color(0.72, 0.74, 0.78), 0.5, 0.2)
	root.add_child(_body(wall.commit(), "wall", wm))
	root.add_child(_body(emb.commit(), "ground", _mat(Color(th["ground"]), 1.0)))
	# giant ground plane (collision safety net + horizon)
	var gb := StaticBody3D.new()
	gb.add_to_group("ground")
	var gm := MeshInstance3D.new()
	var pl := PlaneMesh.new()
	pl.size = Vector2(6000, 6000)
	gm.mesh = pl
	gm.material_override = _mat(Color(th["ground"]), 1.0)
	gb.add_child(gm)
	var gc := CollisionShape3D.new()
	var bs := BoxShape3D.new()
	bs.size = Vector3(6000, 2, 6000)
	gc.shape = bs
	gc.position.y = -1.0
	gb.add_child(gc)
	gb.position = Vector3(0, ground_y, 0)
	root.add_child(gb)
	# start / finish line
	var sl := SurfaceTool.new()
	sl.begin(Mesh.PRIMITIVE_TRIANGLES)
	var tdir := (pts[1] - pts[0]).normalized()
	for k in range(10):
		var u0 := -hw + width * float(k) / 10.0
		var u1 := -hw + width * float(k + 1) / 10.0
		for row in range(2):
			var shade := (k + row) % 2 == 0
			if shade:
				var a := pts[0] + nor[0] * u0 + tdir * (row * 1.5) + Vector3.UP * 0.04
				var b := pts[0] + nor[0] * u1 + tdir * (row * 1.5) + Vector3.UP * 0.04
				_quad(sl, a, b, b + tdir * 1.5, a + tdir * 1.5, Vector3.UP)
	root.add_child(_body(sl.commit(), "road", _mat(Color.WHITE, 0.5), false))
	_scenery(root, pts, th, ground_y, wo, str(data.get("name", "x")).hash())
	return {"node": root, "theme": th, "ground_y": ground_y, "pts": pts, "normals": nor}

static func _scenery(root: Node3D, pts: Array[Vector3], th: Dictionary, ground_y: float, wo: float, seed_v: int) -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = seed_v
	var mn := Vector3(1e9, 0, 1e9)
	var mx := Vector3(-1e9, 0, -1e9)
	for p in pts:
		mn.x = minf(mn.x, p.x)
		mn.z = minf(mn.z, p.z)
		mx.x = maxf(mx.x, p.x)
		mx.z = maxf(mx.z, p.z)
	var sub: Array[Vector3] = []
	for i in range(0, pts.size(), 3):
		sub.append(pts[i])
	var kind: String = th["kind"]
	var mesh: PrimitiveMesh
	match kind:
		"tree":
			var c := CylinderMesh.new()
			c.top_radius = 0.0
			c.bottom_radius = 2.4
			c.height = 11.0
			c.radial_segments = 7
			mesh = c
		"rock":
			var s := SphereMesh.new()
			s.radius = 3.0
			s.height = 4.2
			s.radial_segments = 8
			s.rings = 4
			mesh = s
		_:
			var b := BoxMesh.new()
			b.size = Vector3(14, 40, 14)
			mesh = b
	mesh.material = _mat(Color(th["scenery"]), 0.8)
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.mesh = mesh
	var list: Array[Transform3D] = []
	var tries := 0
	while list.size() < 260 and tries < 2500:
		tries += 1
		var p := Vector3(rng.randf_range(mn.x - 150, mx.x + 150), 0, rng.randf_range(mn.z - 150, mx.z + 150))
		var best := 1e9
		var by := ground_y
		for q in sub:
			var d := Vector2(p.x - q.x, p.z - q.z).length()
			if d < best:
				best = d
				by = q.y
		if best < wo + 8.0 or best > 420.0:
			continue
		var s := rng.randf_range(0.7, 1.6)
		var y := ground_y if best > wo + 45.0 else lerpf(by, ground_y, clampf((best - wo) / 45.0, 0.0, 1.0))
		var sc := Vector3(s, s * (rng.randf_range(0.8, 2.0) if kind == "building" else 1.0), s)
		var h := 5.5 if kind == "tree" else (1.5 if kind == "rock" else 20.0)
		var t := Transform3D(Basis().scaled(sc).rotated(Vector3.UP, rng.randf() * TAU), Vector3(p.x, y + h * sc.y, p.z))
		list.append(t)
	mm.instance_count = list.size()
	for i in list.size():
		mm.set_instance_transform(i, list[i])
	var mmi := MultiMeshInstance3D.new()
	mmi.multimesh = mm
	root.add_child(mmi)
