class_name RemoteCar
extends AnimatableBody3D
## Another player's car: snapshot-interpolated kinematic body (so you can still crash into it).

signal hit(uid: int, rel_speed: float)

var uid := 0
var uname := ""
var buf: Array = []           # [ts_ms, Vector3 pos, Quaternion rot]
var speed := 0.0
var cp_count := 0
var _wheels: Array[Node3D] = []
var _wr := 0.33
var _area: Area3D
var tag: Label3D

func setup(info: Dictionary) -> void:
	uid = int(info["uid"])
	uname = info["name"]
	sync_to_physics = true
	var car: Dictionary = info["car"]
	var td: Dictionary = Game.car_types.get(car.get("body", "sedan"), {})
	add_child(CarController.make_body(car.get("body", "sedan"), Color(car.get("color", "#888888"))))
	_wr = td.get("wheel_radius", 0.33)
	for zi in [td.get("front_z", -1.4), td.get("rear_z", 1.4)]:
		for sx in [-1.0, 1.0]:
			var w := CarController.make_wheel_mesh(_wr, td.get("wheel_width", 0.26), int(car.get("wheel_style", 0)))
			w.position = Vector3(sx * td.get("half_track", 0.8), _wr, zi)
			add_child(w)
			_wheels.append(w)
	var col := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = Vector3(td.get("width", 1.8) * 0.96, td.get("height", 1.3) - 0.3, td.get("length", 4.5) * 0.96)
	col.shape = box
	col.position.y = 0.3 + box.size.y / 2.0
	add_child(col)
	_area = Area3D.new()
	var ac := CollisionShape3D.new()
	var ab := BoxShape3D.new()
	ab.size = box.size + Vector3(0.6, 0.4, 0.6)
	ac.shape = ab
	ac.position = col.position
	_area.add_child(ac)
	_area.body_entered.connect(_on_body)
	add_child(_area)
	tag = Label3D.new()
	tag.text = ("[%s] " % info["tag"] if info.get("tag", "") != "" else "") + uname
	tag.position = Vector3(0, td.get("height", 1.3) + 0.8, 0)
	tag.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	tag.no_depth_test = true
	tag.pixel_size = 0.006
	tag.font_size = 48
	tag.outline_size = 12
	add_child(tag)

func push_snapshot(ts: float, pos: Array, q: Array, spd: float, cps: int) -> void:
	buf.append([ts, Vector3(pos[0], pos[1], pos[2]), Quaternion(q[0], q[1], q[2], q[3]).normalized()])
	if buf.size() > 30:
		buf.pop_front()
	speed = spd
	cp_count = cps

func _physics_process(delta: float) -> void:
	var t := Net.server_now_ms() - 120.0
	if buf.size() >= 2:
		var a = buf[0]
		var b = buf[buf.size() - 1]
		for i in range(buf.size() - 1):
			if buf[i][0] <= t and buf[i + 1][0] >= t:
				a = buf[i]
				b = buf[i + 1]
				break
		var span: float = maxf(1.0, b[0] - a[0])
		var k := clampf((t - a[0]) / span, 0.0, 1.0)
		global_position = (a[1] as Vector3).lerp(b[1], k)
		global_basis = Basis((a[2] as Quaternion).slerp(b[2], k))
	for w in _wheels:
		w.rotate_x(-speed / _wr * delta)

func _on_body(b: Node) -> void:
	if b is CarController:
		hit.emit(uid, (b as CarController).speed_ms)
