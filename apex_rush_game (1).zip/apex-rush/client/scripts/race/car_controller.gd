class_name CarController
extends VehicleBody3D
## Arcade-sim vehicle: power curve (P/v), drag tuned so top speed == stat, traction limit,
## drift (handbrake lowers rear grip), nitro, downforce, off-road grip loss, gearbox/RPM model.
## Godot vehicle forward is -Z. Visual body models are authored facing +Z, so they are rotated 180 deg.

signal drift_charged(amount: float)

var stats: Dictionary = {}
var td: Dictionary = {}                 # car type definition (data/car_types.json)
var locked := true                      # true until GO
var wrecked_until := 0.0                # takedown victim: engine cut
var nitro := 100.0
var nitro_max := 100.0
var gear := 1
var rpm := 1000.0
var speed_ms := 0.0
var fwd_speed := 0.0
var drifting := false
var nitro_active := false
var _wheels: Array[VehicleWheel3D] = []
var _rear: Array[VehicleWheel3D] = []
var _steer := 0.0
var _vmax := 50.0
var _k_drag := 0.3
var _power_w := 100000.0
var _max_force := 8000.0
var _base_slip := 10.0
var _n_drive := 2
var _shift_t := 0.0
var _last_gear := 1
var _smoke: GPUParticles3D
var _hl: Array[SpotLight3D] = []
var _ground_mu := 1.0

static func make_body(body_type: String, color: Color) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var path := "res://assets/cars/%s.obj" % body_type
	var mesh: Mesh = load(path) if ResourceLoader.exists(path) else null
	if mesh == null:
		var box := BoxMesh.new()
		box.size = Vector3(1.8, 1.0, 4.4)
		mesh = box
		mi.position.y = 0.7
	mi.mesh = mesh
	if mesh is ArrayMesh or mesh is BoxMesh:
		for i in mesh.get_surface_count():
			var nm := ""
			if mesh is ArrayMesh:
				nm = (mesh as ArrayMesh).surface_get_name(i)
			var src := mesh.surface_get_material(i)
			if nm == "" and src:
				nm = src.resource_name
			var m := StandardMaterial3D.new()
			match nm:
				"glass":
					m.albedo_color = Color(0.05, 0.09, 0.14, 0.72)
					m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
					m.metallic = 0.9
					m.roughness = 0.04
				"tire":
					m.albedo_color = Color(0.02, 0.02, 0.02)
					m.roughness = 0.9
				"headlight":
					m.albedo_color = Color(1, 1, 0.85)
					m.emission_enabled = true
					m.emission = Color(1, 0.95, 0.75)
					m.emission_energy_multiplier = 2.0
				"taillight":
					m.albedo_color = Color(0.8, 0.02, 0.02)
					m.emission_enabled = true
					m.emission = Color(1, 0.05, 0.05)
					m.emission_energy_multiplier = 1.6
				"trim", "rim":
					m.albedo_color = Color(0.07, 0.07, 0.08)
					m.metallic = 0.4
					m.roughness = 0.5
				_:
					m.albedo_color = color
					m.metallic = 0.85
					m.roughness = 0.22
					m.clearcoat_enabled = true
					m.clearcoat = 1.0
					m.clearcoat_roughness = 0.04
			mi.set_surface_override_material(i, m)
	mi.rotation.y = PI          # models face +Z, vehicle forward is -Z
	return mi

static func make_wheel_mesh(radius: float, width: float, style: int) -> Node3D:
	var root := Node3D.new()
	var tire := MeshInstance3D.new()
	var cyl := CylinderMesh.new()
	cyl.top_radius = radius
	cyl.bottom_radius = radius
	cyl.height = width
	cyl.radial_segments = 24
	tire.mesh = cyl
	tire.rotation.z = PI / 2.0
	var tm := StandardMaterial3D.new()
	tm.albedo_color = Color(0.03, 0.03, 0.03)
	tm.roughness = 0.9
	tire.material_override = tm
	root.add_child(tire)
	var rim := MeshInstance3D.new()
	var rc := CylinderMesh.new()
	rc.top_radius = radius * (0.58 + 0.02 * (style % 6))
	rc.bottom_radius = rc.top_radius
	rc.height = width * 1.04
	rc.radial_segments = 5 + (style % 7)       # style changes spoke count look
	rim.mesh = rc
	rim.rotation.z = PI / 2.0
	var rm := StandardMaterial3D.new()
	rm.albedo_color = [Color(0.8, 0.8, 0.85), Color(0.15, 0.15, 0.17), Color(0.9, 0.7, 0.2), Color(0.9, 0.2, 0.2)][style % 4]
	rm.metallic = 1.0
	rm.roughness = 0.2
	rim.material_override = rm
	root.add_child(rim)
	return root

func setup(car: Dictionary, local: bool, night: bool = false) -> void:
	stats = car["stats"]
	td = Game.car_types.get(car.get("body", "sedan"), Game.car_types.get("sedan", {}))
	mass = float(stats["mass_kg"])
	nitro_max = float(stats.get("nitro_tank", 100))
	nitro = nitro_max * 0.5
	_vmax = float(stats["top_kmh"]) / 3.6
	_power_w = float(stats["power_hp"]) * 745.7
	_k_drag = _power_w * 0.85 / pow(_vmax, 3.0)
	var drive: String = stats.get("drive", "RWD")
	_n_drive = 4 if drive == "AWD" else 2
	var share := 1.0 if drive == "AWD" else 0.55
	var mu := 0.85 + float(stats["grip"]) / 100.0 * 0.9
	_max_force = mu * mass * 9.81 * share * 1.1
	_base_slip = 7.0 + float(stats["grip"]) / 100.0 * 7.0
	center_of_mass_mode = RigidBody3D.CENTER_OF_MASS_MODE_CUSTOM
	center_of_mass = Vector3(0, 0.38, 0)
	linear_damp = 0.0
	angular_damp = 0.8
	var col := CollisionShape3D.new()
	var box := BoxShape3D.new()
	var h: float = td.get("height", 1.3)
	var gc: float = td.get("ground_clearance", 0.2)
	box.size = Vector3(td.get("width", 1.8) * 0.96, h - gc - 0.1, td.get("length", 4.5) * 0.96)
	col.shape = box
	col.position.y = gc + 0.1 + box.size.y / 2.0
	add_child(col)
	add_child(make_body(car.get("body", "sedan"), Color(car.get("color", "#d01818"))))
	var wr: float = td.get("wheel_radius", 0.33)
	var ww: float = td.get("wheel_width", 0.26)
	var ht: float = td.get("half_track", 0.8)
	for zi in [td.get("front_z", -1.4), td.get("rear_z", 1.4)]:
		for sx in [-1.0, 1.0]:
			var w := VehicleWheel3D.new()
			w.position = Vector3(sx * ht, wr + 0.12, zi)
			w.wheel_radius = wr
			w.wheel_rest_length = 0.12
			w.suspension_travel = 0.28
			w.suspension_stiffness = clampf(mass / 22.0, 38.0, 160.0)
			w.suspension_max_force = mass * 14.0
			w.damping_compression = 0.9 + mass / 3000.0
			w.damping_relaxation = 1.1 + mass / 2500.0
			w.wheel_roll_influence = 0.25
			w.wheel_friction_slip = _base_slip
			w.use_as_steering = zi == td.get("front_z", -1.4)
			w.use_as_traction = (drive == "AWD") or (drive == "FWD" and w.use_as_steering) or (drive == "RWD" and not w.use_as_steering)
			w.add_child(make_wheel_mesh(wr, ww, int(car.get("wheel_style", 0))))
			add_child(w)
			_wheels.append(w)
			if not w.use_as_steering:
				_rear.append(w)
	_n_drive = 0
	for w in _wheels:
		if w.use_as_traction:
			_n_drive += 1
	_make_smoke()
	if str(car.get("neon", "")) != "":
		var l := OmniLight3D.new()
		l.light_color = Color(car["neon"])
		l.omni_range = 5.0
		l.light_energy = 2.5
		l.position = Vector3(0, 0.15, 0)
		add_child(l)
	if night or local:
		for sx in [-0.55, 0.55]:
			var s := SpotLight3D.new()
			s.position = Vector3(sx, 0.7, td.get("front_z", -1.4) - 0.6)
			s.rotation.x = -0.06
			s.spot_range = 60.0
			s.spot_angle = 32.0
			s.light_energy = 3.0 if night else 0.0
			s.shadow_enabled = false
			add_child(s)
			_hl.append(s)

func _make_smoke() -> void:
	_smoke = GPUParticles3D.new()
	_smoke.amount = 40
	_smoke.lifetime = 1.2
	_smoke.emitting = false
	var pm := ParticleProcessMaterial.new()
	pm.direction = Vector3(0, 1, 0)
	pm.spread = 35.0
	pm.initial_velocity_min = 0.5
	pm.initial_velocity_max = 1.6
	pm.gravity = Vector3(0, 0.5, 0)
	pm.scale_min = 0.6
	pm.scale_max = 1.8
	pm.color = Color(0.85, 0.85, 0.85, 0.35)
	_smoke.process_material = pm
	var sp := SphereMesh.new()
	sp.radius = 0.3
	sp.height = 0.6
	sp.radial_segments = 8
	sp.rings = 4
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.albedo_color = Color(0.9, 0.9, 0.9, 0.28)
	m.vertex_color_use_as_albedo = true
	sp.material = m
	_smoke.draw_pass_1 = sp
	_smoke.position = Vector3(0, 0.2, td.get("rear_z", 1.4))
	add_child(_smoke)

func set_night(on: bool) -> void:
	for s in _hl:
		s.light_energy = 3.0 if on else 0.0

func add_nitro(a: float) -> void:
	nitro = minf(nitro_max, nitro + a)

func wreck(seconds: float) -> void:
	wrecked_until = Time.get_ticks_msec() / 1000.0 + seconds
	apply_torque_impulse(Vector3(0, mass * 4.0, 0))
	apply_central_impulse(Vector3(0, mass * 2.5, 0))

func _physics_process(delta: float) -> void:
	var vel := linear_velocity
	var fwd := -global_transform.basis.z
	var right := global_transform.basis.x
	fwd_speed = vel.dot(fwd)
	speed_ms = vel.length()
	var lateral := vel.dot(right)
	var v := absf(fwd_speed)
	var now := Time.get_ticks_msec() / 1000.0
	var dead := locked or now < wrecked_until

	var thr := 0.0 if dead else Input.get_action_strength("accelerate")
	var brk := Input.get_action_strength("brake")
	var hb := Input.is_action_pressed("handbrake")
	var steer_in := Input.get_axis("steer_right", "steer_left")
	if Settings.tilt_steering:
		var tilt := clampf(-Input.get_accelerometer().y / 5.0, -1.0, 1.0)
		if absf(tilt) > 0.06:
			steer_in = tilt
	nitro_active = Input.is_action_pressed("nitro") and nitro > 0.5 and thr > 0.1 and not dead

	# --- surface grip (road vs grass)
	var off := 0
	for w in _wheels:
		var b := w.get_contact_body()
		if b != null and not b.is_in_group("road"):
			off += 1
	_ground_mu = lerpf(_ground_mu, 1.0 - 0.45 * float(off) / 4.0, 5.0 * delta)

	# --- steering (speed sensitive + counter-steer assist)
	var max_steer := lerpf(0.62, 0.09, clampf(v / (_vmax * 0.55), 0.0, 1.0)) * (0.8 + float(stats["handling"]) / 250.0)
	var rate := 4.5 if absf(steer_in) > 0.01 else 7.0
	_steer = move_toward(_steer, steer_in, rate * delta)
	var assist := 0.0
	if v > 8.0:
		assist = -clampf(lateral * 0.028, -0.3, 0.3) * (1.0 if hb or absf(lateral) > 3.0 else 0.4)
	steering = clampf(_steer * max_steer + assist, -0.7, 0.7)

	# --- engine: force = P / v limited by traction; reverse when braking from standstill
	var force := 0.0
	var reversing := brk > 0.1 and fwd_speed < 1.5 and not dead
	if thr > 0.0:
		force = minf(_power_w * 0.85 / maxf(v, 3.5), _max_force) * thr
		if nitro_active:
			force *= 1.55
			nitro = maxf(0.0, nitro - 22.0 * delta)
		if v > _vmax * (1.18 if nitro_active else 1.03):
			force = 0.0
	elif reversing:
		force = -minf(_power_w * 0.25 / maxf(v, 3.0), _max_force * 0.45) * brk
	_update_gearbox(v, thr, delta)
	if _shift_t > 0.0:
		_shift_t -= delta
		force *= 0.55
	engine_force = force * _ground_mu / float(maxi(_n_drive, 1))

	# --- brakes
	var bf := mass / 1000.0 * 28.0 * (0.55 + float(stats["braking"]) / 100.0 * 0.9)
	var braking := brk > 0.05 and not reversing and fwd_speed > 1.0
	brake = bf * brk * 0.5 if braking else 0.0
	if locked:
		brake = bf
	for w in _rear:
		w.brake = (bf * 0.7 if hb else (brake if braking else 0.0)) if not locked else bf

	# --- grip: handbrake => rear slide (drift)
	for w in _wheels:
		var target := _base_slip * _ground_mu
		if w in _rear and hb and v > 6.0:
			target = _base_slip * 0.32
		w.wheel_friction_slip = lerpf(w.wheel_friction_slip, target, 9.0 * delta)

	# --- drag, rolling resistance, downforce
	if speed_ms > 0.2:
		var dir := vel / speed_ms
		apply_central_force(-dir * (_k_drag * speed_ms * speed_ms + 0.015 * mass * 9.81))
	var df := mass * 9.81 * 0.35 * (v * v) / (_vmax * _vmax) * (0.6 + float(stats["handling"]) / 120.0)
	apply_central_force(-global_transform.basis.y * df)

	# --- drift detection (builds nitro) & smoke
	var slip := absf(atan2(lateral, maxf(v, 0.1)))
	drifting = slip > 0.22 and v > 10.0
	if drifting:
		add_nitro(8.0 * delta)
		drift_charged.emit(8.0 * delta)
	elif not nitro_active:
		add_nitro(0.0)
	if _smoke:
		_smoke.emitting = drifting or (thr > 0.8 and v < 6.0 and not locked)

func _update_gearbox(v: float, thr: float, delta: float) -> void:
	var per_gear := _vmax / 6.2
	gear = clampi(1 + int(v / per_gear), 1, 6)
	if gear != _last_gear:
		if gear > _last_gear and thr > 0.2:
			_shift_t = 0.12
		_last_gear = gear
	var lo := float(gear - 1) * per_gear
	var target := 1600.0 + clampf((v - lo) / per_gear, 0.0, 1.0) * 5400.0
	if thr < 0.05:
		target = maxf(1100.0, target * 0.8)
	if locked and Input.get_action_strength("accelerate") > 0.5:
		target = 5200.0                     # rev on the grid
	rpm = lerpf(rpm, target, 10.0 * delta)

func reset_to(t: Transform3D) -> void:
	linear_velocity = Vector3.ZERO
	angular_velocity = Vector3.ZERO
	global_transform = t
