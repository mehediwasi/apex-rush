class_name EngineAudio
extends Node
## Procedural engine sound (no audio files needed). Replace with real samples later if desired.

var player := AudioStreamPlayer.new()
var gen := AudioStreamGenerator.new()
var pb: AudioStreamGeneratorPlayback
var phase := 0.0
var rpm := 1000.0
var load_amt := 0.0
var cylinders := 4

func _ready() -> void:
	gen.mix_rate = 22050.0
	gen.buffer_length = 0.12
	player.stream = gen
	player.volume_db = -8.0
	add_child(player)
	player.play()
	pb = player.get_stream_playback()

func _process(_d: float) -> void:
	if pb == null:
		return
	var n := mini(pb.get_frames_available(), 1500)
	var f := rpm / 60.0 * float(cylinders) / 2.0
	var vol := 0.18 + 0.22 * load_amt
	for i in n:
		phase += f / gen.mix_rate
		if phase > 1.0:
			phase -= 1.0
		var s := sin(TAU * phase) * 0.55 + sin(TAU * phase * 2.0) * 0.28 + (phase * 2.0 - 1.0) * 0.18
		s = clampf(s * (1.0 + load_amt * 1.5), -1.0, 1.0) * vol
		pb.push_frame(Vector2(s, s))
