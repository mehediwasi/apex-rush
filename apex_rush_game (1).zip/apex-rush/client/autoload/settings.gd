extends Node
## Persistent local settings (server address, token, graphics, controls).

const PATH := "user://settings.cfg"
var api_url := "http://127.0.0.1:8000"   # CHANGE to your server, e.g. https://api.example.com
var ws_url := "ws://127.0.0.1:8765"
var token := ""
var username := ""
var quality := 2            # 0 low, 1 medium, 2 high, 3 ultra
var tilt_steering := false
var master_volume := 0.8
var show_fps := false

func _ready() -> void:
	load_settings()
	if OS.has_feature("mobile") and not FileAccess.file_exists(PATH):
		quality = 1
	_register_inputs()

func load_settings() -> void:
	var cfg := ConfigFile.new()
	if cfg.load(PATH) != OK:
		return
	api_url = cfg.get_value("net", "api_url", api_url)
	ws_url = cfg.get_value("net", "ws_url", ws_url)
	token = cfg.get_value("net", "token", "")
	username = cfg.get_value("net", "username", "")
	quality = cfg.get_value("gfx", "quality", quality)
	tilt_steering = cfg.get_value("ctl", "tilt", false)
	master_volume = cfg.get_value("audio", "master", 0.8)
	show_fps = cfg.get_value("gfx", "fps", false)

func save_settings() -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("net", "api_url", api_url)
	cfg.set_value("net", "ws_url", ws_url)
	cfg.set_value("net", "token", token)
	cfg.set_value("net", "username", username)
	cfg.set_value("gfx", "quality", quality)
	cfg.set_value("ctl", "tilt", tilt_steering)
	cfg.set_value("audio", "master", master_volume)
	cfg.set_value("gfx", "fps", show_fps)
	cfg.save(PATH)
	AudioServer.set_bus_volume_db(0, linear_to_db(master_volume))

func _key(action: String, keys: Array, pads: Array = []) -> void:
	if not InputMap.has_action(action):
		InputMap.add_action(action)
	for k in keys:
		var e := InputEventKey.new()
		e.physical_keycode = k
		InputMap.action_add_event(action, e)
	for b in pads:
		var j := InputEventJoypadButton.new()
		j.button_index = b
		InputMap.action_add_event(action, j)

func _register_inputs() -> void:
	_key("accelerate", [KEY_W, KEY_UP], [JOY_BUTTON_A])
	_key("brake", [KEY_S, KEY_DOWN], [JOY_BUTTON_X])
	_key("steer_left", [KEY_A, KEY_LEFT], [JOY_BUTTON_DPAD_LEFT])
	_key("steer_right", [KEY_D, KEY_RIGHT], [JOY_BUTTON_DPAD_RIGHT])
	_key("handbrake", [KEY_SPACE], [JOY_BUTTON_B])
	_key("nitro", [KEY_SHIFT], [JOY_BUTTON_Y])
	_key("reset_car", [KEY_R], [JOY_BUTTON_BACK])
	_key("camera", [KEY_C], [JOY_BUTTON_RIGHT_STICK])
	_key("pause", [KEY_ESCAPE], [JOY_BUTTON_START])
