extends Node
## Global game state: logged-in user, garage, catalog cache, tracks, race context.

signal user_changed

var user: Dictionary = {}
var garage: Array = []
var tracks: Array = []
var car_types: Dictionary = {}
var race_ctx: Dictionary = {}       # filled by lobby when a race starts (or offline free-drive)
var lobby: Dictionary = {}          # latest lobby.state
var last_results: Dictionary = {}

func _ready() -> void:
	var f := FileAccess.open("res://data/car_types.json", FileAccess.READ)
	if f:
		car_types = JSON.parse_string(f.get_as_text())
	Net.ws_message.connect(_on_ws)

func _on_ws(m: Dictionary) -> void:
	match m.get("t", ""):
		"lobby.state":
			lobby = m
		"lobby.left":
			lobby = {}
		"race.results":
			last_results = m

func login(username: String, password: String, register: bool) -> String:
	var r := await Net.api("POST", "/api/auth/register" if register else "/api/auth/login", {"username": username, "password": password})
	if not r.ok:
		return r.data.get("error", "Login failed")
	Settings.token = r.data["token"]
	Settings.username = username
	Settings.save_settings()
	set_user(r.data["user"])
	return ""

func restore_session() -> bool:
	var r := await Net.api("GET", "/api/me")
	if r.ok:
		set_user(r.data)
		return true
	return false

func logout() -> void:
	Net.disconnect_ws()
	Settings.token = ""
	Settings.save_settings()
	user = {}

func set_user(u: Dictionary) -> void:
	user = u
	user_changed.emit()

func refresh_user() -> void:
	var r := await Net.api("GET", "/api/me")
	if r.ok:
		set_user(r.data)

func refresh_garage() -> void:
	var r := await Net.api("GET", "/api/garage")
	if r.ok:
		garage = r.data["garage"]

func selected_car() -> Dictionary:
	for g in garage:
		if g["id"] == user.get("selected_garage_id", -1):
			return g
	return garage[0] if garage.size() > 0 else {}

func load_tracks() -> void:
	if tracks.size() > 0:
		return
	var f := FileAccess.open("res://tracks/index.json", FileAccess.READ)
	if f:
		for t in JSON.parse_string(f.get_as_text()):
			t["id"] = str(t["file"]).trim_suffix(".obj")
			tracks.append(t)

func load_track_data(track_id: String) -> Dictionary:
	var f := FileAccess.open("res://tracks/%s.json" % track_id, FileAccess.READ)
	if f == null:
		return {}
	return JSON.parse_string(f.get_as_text())

func fmt_time(ms: float) -> String:
	var s := ms / 1000.0
	return "%d:%06.3f" % [int(s) / 60, fmt_mod(s, 60.0)]

func fmt_mod(a: float, b: float) -> float:
	return a - floor(a / b) * b

func fmt_coins(n) -> String:
	var s := str(int(n))
	var out := ""
	for i in s.length():
		if i > 0 and (s.length() - i) % 3 == 0:
			out += ","
		out += s[i]
	return out
