extends Node
## HTTP API wrapper + realtime WebSocket client.
## Usage:  var r = await Net.api("POST", "/api/market/buy", {"car_id": "car010"})
##         r = {ok: bool, status: int, data: Dictionary}

signal ws_message(msg: Dictionary)
signal ws_connected
signal ws_closed

var ws := WebSocketPeer.new()
var ws_state := WebSocketPeer.STATE_CLOSED
var authed := false
var server_offset_ms := 0.0     # server_time - local_time
var rtt_ms := 0.0
var _ping_timer := 0.0
var _want_ws := false
var _reconnect_in := 0.0

func api(method: String, path: String, body: Dictionary = {}) -> Dictionary:
	var req := HTTPRequest.new()
	req.timeout = 15.0
	add_child(req)
	var headers := PackedStringArray(["Content-Type: application/json"])
	if Settings.token != "":
		headers.append("Authorization: Bearer " + Settings.token)
	var m := HTTPClient.METHOD_GET
	if method == "POST":
		m = HTTPClient.METHOD_POST
	var err := req.request(Settings.api_url + path, headers, m, JSON.stringify(body) if method == "POST" else "")
	if err != OK:
		req.queue_free()
		return {"ok": false, "status": 0, "data": {"error": "Cannot reach server"}}
	var res = await req.request_completed
	req.queue_free()
	var code: int = res[1]
	var data = JSON.parse_string((res[3] as PackedByteArray).get_string_from_utf8())
	if typeof(data) != TYPE_DICTIONARY:
		data = {}
	if res[0] != HTTPRequest.RESULT_SUCCESS:
		data = {"error": "Network error (%d)" % res[0]}
	return {"ok": code >= 200 and code < 300, "status": code, "data": data}

# ---------------- websocket ----------------
func connect_ws() -> void:
	_want_ws = true
	if ws_state != WebSocketPeer.STATE_CLOSED:
		return
	ws = WebSocketPeer.new()
	ws.inbound_buffer_size = 262144
	if ws.connect_to_url(Settings.ws_url) != OK:
		_reconnect_in = 3.0

func disconnect_ws() -> void:
	_want_ws = false
	authed = false
	if ws_state != WebSocketPeer.STATE_CLOSED:
		ws.close()

func send(msg: Dictionary) -> void:
	if ws_state == WebSocketPeer.STATE_OPEN:
		ws.send_text(JSON.stringify(msg))

func server_now_ms() -> float:
	return Time.get_unix_time_from_system() * 1000.0 + server_offset_ms

func _process(delta: float) -> void:
	ws.poll()
	var st := ws.get_ready_state()
	if st != ws_state:
		var prev := ws_state
		ws_state = st
		if st == WebSocketPeer.STATE_OPEN:
			send({"t": "auth", "token": Settings.token})
			ws_connected.emit()
		elif st == WebSocketPeer.STATE_CLOSED:
			authed = false
			ws_closed.emit()
			if _want_ws:
				_reconnect_in = 2.5
	if st == WebSocketPeer.STATE_OPEN:
		while ws.get_available_packet_count() > 0:
			var d = JSON.parse_string(ws.get_packet().get_string_from_utf8())
			if typeof(d) == TYPE_DICTIONARY:
				_on_msg(d)
		_ping_timer -= delta
		if _ping_timer <= 0.0:
			_ping_timer = 4.0
			send({"t": "ping", "ts": Time.get_ticks_msec()})
	elif st == WebSocketPeer.STATE_CLOSED and _want_ws:
		_reconnect_in -= delta
		if _reconnect_in <= 0.0:
			connect_ws()

func _on_msg(d: Dictionary) -> void:
	match d.get("t", ""):
		"auth.ok":
			authed = true
			server_offset_ms = float(d["server_time"]) - Time.get_unix_time_from_system() * 1000.0
		"pong":
			rtt_ms = Time.get_ticks_msec() - float(d.get("ts", 0))
			server_offset_ms = float(d["server_time"]) + rtt_ms * 0.5 - Time.get_unix_time_from_system() * 1000.0
	ws_message.emit(d)
