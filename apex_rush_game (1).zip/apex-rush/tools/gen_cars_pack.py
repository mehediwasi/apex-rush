import math, os, json, random, zipfile
random.seed(7)
OUT="/home/claude/gen/cars_pack"
os.makedirs(OUT,exist_ok=True)

class Mesh:
    def __init__(s): s.v=[]; s.groups=[]  # (mat, [faces])
    def add(s,mat,verts,quads):
        base=len(s.v); s.v+=verts
        c=[sum(p[i] for p in verts)/len(verts) for i in range(3)]
        faces=[]
        for q in quads:
            pts=[verts[i] for i in q]
            a=[pts[1][i]-pts[0][i] for i in range(3)]; b=[pts[2][i]-pts[0][i] for i in range(3)]
            n=[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]
            m=[sum(pts[k][i] for k in range(len(pts)))/len(pts)-c[i] for i in range(3)]
            if sum(n[i]*m[i] for i in range(3))<0: q=q[::-1]
            faces.append([base+i+1 for i in q])
        s.groups.append((mat,faces))
    def frustum(s,mat,y0,y1,xb,zb0,zb1,xt,zt0,zt1,cx=0):
        V=[(cx-xb,y0,zb0),(cx+xb,y0,zb0),(cx+xb,y0,zb1),(cx-xb,y0,zb1),
           (cx-xt,y1,zt0),(cx+xt,y1,zt0),(cx+xt,y1,zt1),(cx-xt,y1,zt1)]
        s.add(mat,V,[[0,1,2,3],[4,5,6,7],[0,1,5,4],[1,2,6,5],[2,3,7,6],[3,0,4,7]])
    def box(s,mat,x0,x1,y0,y1,z0,z1):
        s.frustum(mat,y0,y1,(x1-x0)/2,z0,z1,(x1-x0)/2,z0,z1,cx=(x0+x1)/2)
    def wheel(s,xc,yc,zc,r,w,n=14):
        for mat,rr,ww in (("tire",r,w),("rim",r*0.62,w*1.04)):
            V=[];Q=[]
            for i in range(n):
                a=2*math.pi*i/n; y=yc+rr*math.cos(a); z=zc+rr*math.sin(a)
                V+=[(xc-ww/2,y,z),(xc+ww/2,y,z)]
            for i in range(n):
                j=(i+1)%n; Q.append([2*i,2*i+1,2*j+1,2*j])
            Q.append([2*i for i in range(n)]); Q.append([2*i+1 for i in range(n)])
            s.add(mat,V,Q)
    def save(s,path,name,mats):
        with open(path+".mtl","w") as f:
            for k,(r,g,b) in mats.items():
                f.write(f"newmtl {k}\nKd {r:.3f} {g:.3f} {b:.3f}\nKa 0 0 0\nKs 0.3 0.3 0.3\nNs 40\n\n")
        with open(path+".obj","w") as f:
            f.write(f"mtllib {os.path.basename(path)}.mtl\no {name}\n")
            for v in s.v: f.write("v %.4f %.4f %.4f\n"%v)
            for mat,faces in s.groups:
                f.write(f"usemtl {mat}\n")
                for q in faces: f.write("f "+" ".join(map(str,q))+"\n")
    def tris(s): return sum(len(q)-2 for _,F in s.groups for q in F)

# type: length, width, body h, cabin h, cabin z-range frac, wheel r, ground clearance
TYPES={
 "sedan":    dict(L=4.6,W=1.8,bh=0.55,ch=0.50,c0=-0.30,c1=0.30,ct=0.20,wr=0.33,gc=0.18),
 "hatchback":dict(L=3.9,W=1.7,bh=0.55,ch=0.55,c0=-0.42,c1=0.25,ct=0.10,wr=0.31,gc=0.18),
 "suv":      dict(L=4.5,W=1.9,bh=0.75,ch=0.60,c0=-0.42,c1=0.30,ct=0.10,wr=0.38,gc=0.28),
 "sports":   dict(L=4.4,W=1.95,bh=0.42,ch=0.38,c0=-0.15,c1=0.25,ct=0.28,wr=0.34,gc=0.10),
 "coupe":    dict(L=4.5,W=1.85,bh=0.50,ch=0.42,c0=-0.20,c1=0.30,ct=0.25,wr=0.34,gc=0.13),
 "pickup":   dict(L=5.2,W=1.95,bh=0.80,ch=0.60,c0=0.00,c1=0.40,ct=0.08,wr=0.40,gc=0.30),
 "van":      dict(L=4.8,W=1.9,bh=0.70,ch=0.85,c0=-0.48,c1=0.46,ct=0.05,wr=0.34,gc=0.20),
 "truck":    dict(L=7.0,W=2.4,bh=1.30,ch=0.90,c0=0.25,c1=0.50,ct=0.05,wr=0.50,gc=0.40),
}
COLORS={"red":(.8,.05,.05),"blue":(.05,.2,.8),"black":(.03,.03,.03),"white":(.95,.95,.95),"silver":(.7,.72,.75),
 "yellow":(.95,.8,.05),"green":(.05,.5,.15),"orange":(.95,.45,.05),"purple":(.4,.1,.6),"gray":(.35,.35,.37),
 "teal":(.05,.55,.55),"maroon":(.4,.05,.1),"navy":(.02,.05,.3),"gold":(.8,.65,.2),"pink":(.9,.4,.6)}

def build(t,col,var):
    p=TYPES[t]; L,W=p["L"],p["W"]; hl=W/2
    # variation jitter
    L*=1+var*0.06; W*=1+var*0.03; hl=W/2
    z0,z1=-L/2,L/2; gc=p["gc"]; y0=gc; y1=gc+p["bh"]; wr=p["wr"]*(1+var*0.05)
    m=Mesh()
    # lower body: slightly tapered nose/tail
    m.frustum("body",y0,y1,hl,z0,z1,hl*0.93,z0+L*0.03,z1-L*0.03)
    # hood/trunk slopes for car-like types
    cz0=L*p["c0"]; cz1=L*p["c1"]; ct=L*p["ct"]
    ch=p["ch"]
    if t in("truck",):
        m.box("body",-hl*0.92,hl*0.92,y1,y1+ch,cz0,z1-0.0)   # cab at front? front = +z
        m.box("glass",-hl*0.93,hl*0.93,y1+ch*0.45,y1+ch*0.85,z1-0.02,z1+0.01)
        m.box("trim",-hl*0.9,hl*0.9,y1,y1+0.5,z0+0.2,cz0-0.1)  # cargo box
    elif t=="pickup":
        m.frustum("body",y1,y1+ch,hl*0.92,cz0-0.1,cz1,hl*0.84,cz0+0.2,cz1-ct)
        m.frustum("glass",y1+ch*0.1,y1+ch*0.92,hl*0.935,cz0+0.25,cz1-0.05,hl*0.85,cz0+0.28,cz1-ct-0.05)
        m.box("trim",-hl*0.9,hl*0.9,y1,y1+0.18,z0+0.05,cz0-0.15)   # bed
    else:
        m.frustum("body",y1,y1+ch,hl*0.94,cz0,cz1,hl*0.80,cz0+ct,cz1-ct*0.9)
        # windows (slightly proud of cabin sides)
        m.frustum("glass",y1+ch*0.12,y1+ch*0.92,hl*0.945,cz0+0.15,cz1-0.12,hl*0.81,cz0+ct+0.12,cz1-ct*0.9-0.1)
    if t=="sports":
        m.box("trim",-hl*0.8,hl*0.8,y1+ch*0.9,y1+ch*0.9+0.05,z0-0.02,z0+0.25) # spoiler
        m.box("trim",-hl*0.7,-hl*0.6,y1+ch*0.45,y1+ch*0.9,z0+0.05,z0+0.2)
        m.box("trim",hl*0.6,hl*0.7,y1+ch*0.45,y1+ch*0.9,z0+0.05,z0+0.2)
    if t=="suv": m.box("trim",-hl*0.7,hl*0.7,y1+ch*0.97,y1+ch*1.03+0.05,cz0+0.3,cz1-0.4)  # roof rack
    # lights
    lh=y0+p["bh"]*0.5
    for sx in(-1,1):
        m.box("headlight",sx*hl*0.62-0.18,sx*hl*0.62+0.18,lh,lh+0.12,z1-0.04,z1+0.02)
        m.box("taillight",sx*hl*0.62-0.18,sx*hl*0.62+0.18,lh,lh+0.1,z0-0.02,z0+0.04)
    m.box("trim",-hl*0.98,hl*0.98,y0,y0+0.12,z0-0.03,z0+0.12)  # rear bumper
    m.box("trim",-hl*0.98,hl*0.98,y0,y0+0.12,z1-0.12,z1+0.03)  # front bumper
    # wheels
    ww=0.26 if t!="truck" else 0.4
    axes=[L*0.32,-L*0.30] if t!="truck" else [L*0.33,-L*0.12,-L*0.32]
    if t=="pickup": axes=[L*0.32,-L*0.32]
    for z in axes:
        for sx in(-1,1): m.wheel(sx*(hl-ww/2+0.02),wr,z,wr,ww)
    mats={"body":COLORS[col],"glass":(.1,.2,.3),"tire":(.02,.02,.02),"rim":(.75,.75,.78),
          "headlight":(1,1,.8),"taillight":(.9,.05,.05),"trim":(.08,.08,.09)}
    return m,mats

names=list(TYPES); cols=list(COLORS); index=[]; n=0
for t in names:
    for k in range(15):
        n+=1; col=cols[k]; var=(k%3)-1
        m,mats=build(t,col,var)
        base=f"car_{n:03d}_{t}_{col}"
        m.save(os.path.join(OUT,base),base,mats)
        index.append(dict(file=base+".obj",type=t,color=col,triangles=m.tris(),vertices=len(m.v)))
json.dump(index,open(os.path.join(OUT,"index.json"),"w"),indent=1)
open(os.path.join(OUT,"README.txt"),"w").write("""3D CAR PACK - 120 low-poly cars (OBJ + MTL)
Types: sedan, hatchback, suv, sports, coupe, pickup, van, truck (15 colors each)
Axes: Y up, car front = +Z, 1 unit = 1 meter. Origin = center of car at ground level.
Each car: separate material slots: body, glass, tire, rim, headlight, taillight, trim.
Import: Unity/Godot/Blender/Three.js (OBJLoader+MTLLoader) directly. 
Tip: in Unity set Scale Factor 1; recolor by editing 'body' material.
Procedurally generated - free to use, no license restrictions.
""")
z=zipfile.ZipFile("/home/claude/gen/3d_cars_pack_120.zip","w",zipfile.ZIP_DEFLATED)
for f in sorted(os.listdir(OUT)): z.write(os.path.join(OUT,f),"cars_pack/"+f)
z.close()
print(n,"cars; tris range",min(i["triangles"] for i in index),max(i["triangles"] for i in index))
