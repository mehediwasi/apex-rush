import math, os, json, random, zipfile
random.seed(2026)
OUT="/home/claude/maps/race_maps_pack"; os.makedirs(OUT,exist_ok=True)

THEMES={ # ground, road, scenery color, scenery kind, elev amp, sky
 "forest": ((.10,.35,.10),(.15,.15,.16),(.05,.25,.05),"tree",25,"day"),
 "desert": ((.85,.72,.45),(.22,.20,.19),(.55,.35,.2),"rock",18,"day"),
 "snow":   ((.93,.95,1.0),(.20,.22,.25),(.15,.35,.2),"tree",30,"day"),
 "city":   ((.25,.25,.27),(.10,.10,.11),(.45,.45,.5),"building",6,"night"),
 "coastal":((.80,.75,.55),(.18,.18,.2),(.3,.5,.3),"palm",14,"sunset"),
 "mountain":((.40,.45,.35),(.17,.17,.18),(.5,.5,.5),"rock",60,"day"),
 "neon":   ((.03,.02,.08),(.08,.08,.12),(.9,.1,.8),"building",8,"night"),
 "canyon": ((.65,.35,.2),(.2,.18,.17),(.7,.3,.15),"rock",40,"sunset"),
 "farmland":((.45,.65,.25),(.2,.2,.2),(.6,.45,.2),"barn",10,"day"),
 "industrial":((.35,.35,.33),(.12,.12,.13),(.5,.4,.35),"building",5,"day"),
}
A=["Silver","Red","Thunder","Golden","Iron","Crimson","Blue","Phantom","Savage","Royal","Storm","Rapid","Emerald","Black","Dragon","Eagle","Falcon","Wild","Lunar","Solar","Frozen","Burning","Hidden","Grand","Midnight"]
B=["Ridge","Valley","Bay","Heights","Speedway","Circuit","Pass","Run","Loop","Canyon","Harbor","Peak","Dunes","Park","Raceway","Rush","Gate","Point","Hills","Strip"]

def crspline(P,seg):
    n=len(P); out=[]
    for i in range(n):
        p0,p1,p2,p3=P[(i-1)%n],P[i],P[(i+1)%n],P[(i+2)%n]
        for s in range(seg):
            t=s/seg;t2=t*t;t3=t2*t
            out.append(tuple(0.5*((2*p1[k])+(-p0[k]+p2[k])*t+(2*p0[k]-5*p1[k]+4*p2[k]-p3[k])*t2+(-p0[k]+3*p1[k]-3*p2[k]+p3[k])*t3) for k in range(2)))
    return out

def make_track(kind,width,tgt_len):
    for _ in range(300):
        n=random.randint(7,16)
        pts=[]
        for i in range(n):
            a=2*math.pi*i/n+random.uniform(-.15,.15)
            r=random.uniform(.45,1.0) if kind!="fast" else random.uniform(.7,1.0)
            if kind=="technical" and i%2: r*=.55
            pts.append((math.cos(a)*r*(1.3 if kind=="fast" else 1),math.sin(a)*r))
        c=crspline(pts,14)
        L=sum(math.dist(c[i],c[(i+1)%len(c)]) for i in range(len(c)))
        sc=tgt_len/L; c=[(x*sc,y*sc) for x,y in c]
        # self-proximity check
        m=len(c); ok=True; mind=width*1.8
        for i in range(0,m,2):
            for j in range(i+25,m,2):
                if min(j-i,m-(j-i))<25: continue
                if math.dist(c[i],c[j])<mind: ok=False;break
            if not ok:break
        if ok: return c
    return None

def build(c,th,width,amp):
    m=len(c)
    ph=[random.uniform(0,6.28) for _ in range(3)]; fr=[1,2,3]
    ey=[amp*(0.6*math.sin(fr[0]*2*math.pi*i/m+ph[0])+0.3*math.sin(fr[1]*2*math.pi*i/m+ph[1])+0.1*math.sin(fr[2]*2*math.pi*i/m+ph[2])) for i in range(m)]
    ey=[e-min(ey)+1 for e in ey]
    nor=[]
    for i in range(m):
        a,b=c[i-1],c[(i+1)%m]; tx,tz=b[0]-a[0],b[1]-a[1]; l=math.hypot(tx,tz) or 1
        nor.append((-tz/l,tx/l))
    V=[];G={}  # mat->faces
    def addq(mat,pts,up=None,two=False):
        b=len(V)+1; V.extend(pts)
        q=[b,b+1,b+2,b+3]
        if up is not None:
            P=pts; u=[P[1][k]-P[0][k] for k in range(3)]; v=[P[2][k]-P[0][k] for k in range(3)]
            ny=u[2]*v[0]-u[0]*v[2]
            if (ny<0)==(up>0): q=q[::-1]
        G.setdefault(mat,[]).append(q)
        if two: G[mat].append(q[::-1])
    hw=width/2; cw=1.2; wall=hw+cw+0.8
    for i in range(m):
        j=(i+1)%m
        def pt(k,off): return (c[k][0]+nor[k][0]*off,ey[k],c[k][1]+nor[k][1]*off)
        addq("road",[pt(i,hw),pt(i,-hw),pt(j,-hw),pt(j,hw)],up=1)
        for s in(1,-1):
            addq("curb_red" if (i//3)%2 else "curb_white",[pt(i,s*hw),pt(i,s*(hw+cw)),pt(j,s*(hw+cw)),pt(j,s*hw)],up=1)
            def w(k,off,h): p=pt(k,off); return (p[0],p[1]+h,p[2])
            addq("barrier",[w(i,s*wall,0),w(i,s*wall,1.1),w(j,s*wall,1.1),w(j,s*wall,0)],two=True)
        if i%2==0:
            addq("ground",[(pt(i,hw+cw)[0],ey[i]-.05,pt(i,hw+cw)[2]),(pt(i,hw+cw+25)[0],ey[i]-.05,pt(i,hw+cw+25)[2]),(pt(j,hw+cw+25)[0],ey[j]-.05,pt(j,hw+cw+25)[2]),(pt(j,hw+cw)[0],ey[j]-.05,pt(j,hw+cw)[2])],up=1) if False else None
    # start/finish line
    p=lambda off,k=0:(c[k][0]+nor[k][0]*off,ey[k]+.03,c[k][1]+nor[k][1]*off)
    a,b=p(hw),p(-hw); t2=(c[1][0]-c[0][0],c[1][1]-c[0][1]); l=math.hypot(*t2); t2=(t2[0]/l*3,t2[1]/l*3)
    addq("startline",[a,b,(b[0]+t2[0],b[1],b[2]+t2[1]),(a[0]+t2[0],a[1],a[2]+t2[1])],up=1)
    # ground plane
    xs=[q[0] for q in c];zs=[q[1] for q in c];mg=120
    y=min(ey)-1.5
    addq("ground",[(min(xs)-mg,y,min(zs)-mg),(max(xs)+mg,y,min(zs)-mg),(max(xs)+mg,y,max(zs)+mg),(min(xs)-mg,y,max(zs)+mg)],up=1)
    # scenery
    sub=c[::4]; kind=th[3]; placed=0; tries=0
    while placed<45 and tries<600:
        tries+=1
        x=random.uniform(min(xs)-mg*.8,max(xs)+mg*.8); z=random.uniform(min(zs)-mg*.8,max(zs)+mg*.8)
        if min(math.hypot(x-q[0],z-q[1]) for q in sub)<wall+14: continue
        k=min(range(len(sub)),key=lambda i:math.hypot(x-sub[i][0],z-sub[i][1]))
        yy=y
        s=random.uniform(.7,1.4)
        if kind=="building":
            h=random.uniform(15,70);w=random.uniform(8,16)
            bx=[(x-w,yy,z-w),(x+w,yy,z-w),(x+w,yy,z+w),(x-w,yy,z+w)]
            for q in range(4):
                a2,b2=bx[q],bx[(q+1)%4]
                addq("scenery",[a2,b2,(b2[0],yy+h,b2[2]),(a2[0],yy+h,a2[2])],two=True)
            addq("scenery",[(x-w,yy+h,z-w),(x+w,yy+h,z-w),(x+w,yy+h,z+w),(x-w,yy+h,z+w)],up=1)
        else:
            r=5*s; h={"tree":14,"palm":12,"rock":6,"barn":7}[kind]*s
            base=[(x-r,yy,z-r),(x+r,yy,z-r),(x+r,yy,z+r),(x-r,yy,z+r)]
            ap=(x,yy+h,z)
            for q in range(4):
                a2,b2=base[q],base[(q+1)%4]; bb=len(V)+1; V.extend([a2,b2,ap]); G.setdefault("scenery",[]).append([bb,bb+1,bb+2]);G["scenery"].append([bb+2,bb+1,bb])
        placed+=1
    return V,G,ey

def save(path,name,V,G,th):
    gnd,road,sc=th[0],th[1],th[2]
    mats={"road":road,"ground":gnd,"curb_red":(.85,.1,.1),"curb_white":(.95,.95,.95),"barrier":(.7,.7,.72),"startline":(1,1,1),"scenery":sc}
    with open(path+".mtl","w") as f:
        for k,(r,g,b) in mats.items(): f.write(f"newmtl {k}\nKd {r:.2f} {g:.2f} {b:.2f}\nKa 0 0 0\n\n")
    with open(path+".obj","w") as f:
        f.write(f"mtllib {os.path.basename(path)}.mtl\no {name}\n")
        for v in V: f.write("v %.2f %.2f %.2f\n"%v)
        for mat,F in G.items():
            f.write(f"usemtl {mat}\n")
            for q in F: f.write("f "+" ".join(map(str,q))+"\n")

def svg(path,c,color):
    xs=[p[0] for p in c];zs=[p[1] for p in c];mnx,mxx,mnz,mxz=min(xs),max(xs),min(zs),max(zs)
    s=380/max(mxx-mnx,mxz-mnz)
    d=" ".join(f"{'M' if i==0 else 'L'}{(p[0]-mnx)*s+10:.1f},{(p[1]-mnz)*s+10:.1f}" for i,p in enumerate(c))+"Z"
    open(path,"w").write(f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400" width="400" height="400"><rect width="400" height="400" fill="#111"/><path d="{d}" fill="none" stroke="{color}" stroke-width="5" stroke-linejoin="round"/></svg>')

index=[];n=0;kinds=["flowing","fast","technical","flowing"]
tn=list(THEMES)
used=set()
while n<320:
    th_name=tn[n%len(tn)]; th=THEMES[th_name]
    kind=kinds[(n//len(tn))%4]
    L=random.choice([1500,2200,3000,4000,5200,6500,8000]) if kind!="technical" else random.choice([1200,1800,2500])
    width=random.choice([10,12,14,16])
    c=make_track(kind,width,L)
    if not c: continue
    n+=1
    nm=f"{random.choice(A)} {random.choice(B)}"
    while nm in used: nm=f"{random.choice(A)} {random.choice(B)} {random.randint(2,99)}"
    used.add(nm)
    base=f"map_{n:03d}_{th_name}_{kind}"
    V,G,ey=build(c,th,width,th[4])
    save(os.path.join(OUT,base),base,V,G,th)
    svg(os.path.join(OUT,base+".svg"),c,"#%02x%02x%02x"%tuple(int(255*max(.35,v)) for v in th[2]))
    length=sum(math.dist(c[i],c[(i+1)%len(c)]) for i in range(len(c)))
    meta=dict(id=n,name=nm,theme=th_name,style=kind,time=th[5],length_m=round(length),width_m=width,
              elevation_range_m=round(max(ey)-min(ey)),laps_suggested=max(2,int(20000/length)),
              start_index=0,centerline=[[round(p[0],1),round(e,1),round(p[1],1)] for p,e in zip(c,ey)])
    json.dump(meta,open(os.path.join(OUT,base+".json"),"w"))
    index.append({k:v for k,v in meta.items() if k!="centerline"}|{"file":base+".obj"})
json.dump(index,open(os.path.join(OUT,"index.json"),"w"),indent=1)
open(os.path.join(OUT,"README.txt"),"w").write("""RACE MAP PACK - 320 procedural closed-circuit tracks
Per track: .obj+.mtl (3D mesh), .json (centerline x,y,z + metadata, for AI/waypoints/minimap), .svg (2D preview)
Themes: forest, desert, snow, city, coastal, mountain, neon, canyon, farmland, industrial
Styles: flowing, fast, technical. Length 1.2-8 km, width 10-16 m, elevation changes included.
Axes: Y up, units = meters. Start/finish at centerline[0], direction = increasing index.
Materials: road, curb_red, curb_white, barrier, ground, startline, scenery.
Procedurally generated (NOT real-world circuits). Free to use.
Collision: use 'road' mesh for drivable surface, 'barrier' for walls.
""")
z=zipfile.ZipFile("/home/claude/maps/race_maps_pack_320.zip","w",zipfile.ZIP_DEFLATED)
for f in sorted(os.listdir(OUT)): z.write(os.path.join(OUT,f),"race_maps_pack/"+f)
z.close(); print(n)
