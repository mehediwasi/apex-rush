# AI HANDOFF: read first

You are continuing a racing game called APEX RUSH. Owner builds everything with AI assistants and cannot read code
well, so: make small, complete, tested changes; return full files (not fragments); never break the protocol below.

## Stack
- Client: Godot 4.3 GDScript, all UI built in code (scripts/ui/*), scenes are one-node stubs. Targets Android + Windows.
- Server: Python 3.12, Flask (REST, port 8000), stdlib asyncio WebSocket server (port 8765), SQLite (WAL). Tests: `python -m unittest discover -s server/tests`.
- Server is **authoritative** for money, cars, guilds, race start/finish/rewards. The client never decides rewards.
- Shared stat model: `server/app/catalog.py::effective_stats` (client receives `stats` dicts; do not recompute on client).

## Conventions
- GDScript: tabs, static typing where easy, `Net.api(method, path, body)` returns `{ok,status,data}`; WebSocket via `Net.send` / `Net.ws_message`.
- Server errors: `GameError(msg, status)` -> `{"error": msg}`. All money changes go through `economy.add_coins` inside `db.tx()`.
- Validate every input on the server (ints via `int_field`). Rate limit sensitive endpoints.
- Times: wall-clock ms for WS (`ws.now_ms()` is patchable in tests). UTC.

## REST API (all `/api`, Bearer token except auth)
auth/register, auth/login, me, me/avatar, daily, cars?cls&body&sort&desc, market/buy, garage, garage/select|upgrade|customize|sell,
garage/<id>/upgrade-costs, market/list, market/listings, market/listings/<id>/buy|cancel, tracks, leaderboard/level|wins|guilds|track,
transactions, guilds (POST create, GET search), guilds/mine, guilds/<id>/join|leave|kick/<uid>|role/<uid>|donate|settings|messages,
guilds/<id>/requests/<uid>/accept|reject, guilds/leave.

## WebSocket protocol (JSON text frames `{"t": type, ...}`)
client->server: auth{token}, ping{ts}, lobby.list, lobby.create{track_id,laps,max_players,name,password}, lobby.join{id,password}, matchmaking.quick,
lobby.leave, lobby.ready{ready}, lobby.settings{track_id,laps}, lobby.car, lobby.kick{uid}, lobby.start,
race.state{p:[x,y,z], r:[qx,qy,qz,qw], v}, race.cp{i}, race.takedown{target}, chat{scope: global|lobby|guild, msg}.
server->client: auth.ok{uid,server_time}, auth.fail, pong{server_time}, presence{online}, lobby.list, lobby.state, lobby.left,
race.start{track_id,laps,start_at,dir,grid,checkpoints,players}, race.snap{ts,p:{uid:[pos,quat,speed,cp_count]}}, race.cp.ok|reject,
race.finished{uid,time_ms}, race.takedown, race.results{rows}, chat, kicked, error{msg}.
Anti-cheat: speed/teleport check on race.state, ordered checkpoints + minimum segment time, takedown distance/speed/cooldown.

## Files you will edit most
server/app/api.py (REST), ws.py (realtime), catalog.py (cars/parts), economy.py (prices/rewards)
client/scripts/race/{race,car_controller,track_builder,hud}.gd, client/scripts/ui/*_panel.gd, client/autoload/{net,game,settings}.gd

## Art pipeline (how to get real graphics)
- Cars: put `res://assets/cars/<body>.glb` (sedan, hatchback, suv, sports, coupe, pickup, van, truck): front = +Z, origin on the ground, body WITHOUT wheels
  (wheels are separate nodes so they spin/steer). `CarController.make_body` currently loads `.obj`; extend it to prefer `.glb`/per-car-id models (`cars.model_asset` column idea).
  Name materials `body`, `glass`, `trim`, `headlight`, `taillight` so paint/neon/lights still work.
- Tracks: `TrackBuilder` makes road geometry from centerline JSON; add textures (asphalt PBR), guardrail models, trees (GLB) via MultiMesh.
- Sky: replace ProceduralSky with HDRI `PanoramaSkyMaterial`. Audio: replace `EngineAudio` with sampled RPM loops (AudioStreamRandomizer / pitch scale).

## Roadmap (suggested order)
1. Run in Godot, fix first-open errors, test 2 clients on one server (PC + phone).
2. Real car GLBs + per-car model mapping, skid marks, brake lights, damage deformation.
3. AI bots to fill lobbies (server-side bot players following centerline), ranked matchmaking by PI class.
4. Friends list + invites, guild wars / weekly events, season pass, achievements, missions.
5. Tuning UI (gear ratios, tire pressure), car sets by class restrictions, photo mode, replays.
6. PostgreSQL migration (replace sqlite3 calls in db.py; keep SQL), Redis for presence at scale, TLS, admin panel (ban/grant), analytics.
7. Monetization only with clear rules: gems purchases need server-side receipt validation (Google Play Billing).
8. Hardening: server-side physics simulation or stricter replay validation, device attestation.

## Known gaps / TODO markers
- Client not editor-tested yet (see README). Tilt steering axis may need sign flip per device.
- Remote cars are interpolated ghosts (no client prediction needed) but collisions are one-sided: local physics vs kinematic body.
- Only SQLite; guild chat history REST + WS both exist; no profanity filter; no email/password reset.
