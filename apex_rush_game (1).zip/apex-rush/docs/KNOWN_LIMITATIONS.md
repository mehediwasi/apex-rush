# KNOWN LIMITATIONS
- Client never run in Godot; expect first-open script errors.
- No real 3D car models (8 placeholder meshes), no real textures, audio, voice, tutorial.
- No open world, weather, day/night, traffic, damage model, manual gearbox, cockpit camera.
- No friends/invites/reconnect/ranked modes; guild events missing.
- SQLite only; no migrations framework yet; no Postgres/Redis.
- iOS/macOS need Apple hardware/tools. Android/Windows builds untested.
- "AAA graphics" needs licensed/created art assets; code cannot supply them.
