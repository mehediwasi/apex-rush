# CHANGELOG
- 0.1.0 initial: server (REST+WS+SQLite), Godot client, 320 tracks, export presets, CI workflow.
- 0.1.1 countdown changed to exact 4-3-2-1-GO (server +4000 ms, HUD shows 4..1 then GO); added docs/ with honest matrix, test report, limitations.
