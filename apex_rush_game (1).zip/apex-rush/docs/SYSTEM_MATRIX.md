# SYSTEM MATRIX (honest status, checked against source on 2026-11-25)
Legend: TESTED = automated test passed here | UNTESTED = code exists, never run | PARTIAL | MISSING | PLACEHOLDER

| System | Status | Notes |
|---|---|---|
| Register/login (scrypt, JWT, rate limit) | TESTED | tests/test_api.py |
| Player profile, XP/level, stats | TESTED | no display-name edit, no account recovery |
| Unique immutable player id | PARTIAL | numeric `users.id` (immutable); no public short ID |
| Car catalog (160 DB records) | TESTED | fictional makers; only categories hatchback/sedan/suv/sports/coupe/pickup/van/truck |
| Car 3D models | PLACEHOLDER | only 8 generic low-poly body OBJs (one per body type). 160 cars share 8 meshes. NOT real assets |
| Car dealer, daily deals, sell | TESTED | |
| Player marketplace (5% fee) | TESTED | |
| Garage upgrades (7 parts x5), paint/wheel/neon | TESTED (API) | client UI UNTESTED; spoilers/body kits MISSING |
| Guilds (create/join/request/roles/kick/donate/chat/XP) | TESTED (API) | co-leader, guild events/competitions, invitations MISSING |
| Lobby create/join/ready/start/kick/chat | TESTED (2 clients, 1 race) | friends, invites, ranked/team/drift modes MISSING |
| Race sync, checkpoints, anti-cheat, rewards, takedown | TESTED (2 clients) | multi-client >2, reconnect MISSING |
| Countdown 4-3-2-1-GO | PARTIAL | server start_at = +4000 ms (changed this session); client HUD UNTESTED; no audio |
| Vehicle physics (Godot VehicleBody3D) | UNTESTED | no clutch/manual/ABS/TC/damage |
| Cameras | PARTIAL | chase, hood, far-chase only (UNTESTED); no cockpit/bumper/cinematic |
| Graphics presets | UNTESTED | 4 presets, not the 6 requested; no device auto-detect |
| Audio | PLACEHOLDER | procedural engine tone only; no SFX, no voice |
| Tutorial | MISSING | |
| Open world | MISSING | only 320 generated closed circuits (JSON centerlines); no streaming, traffic, weather, day/night |
| UI (login, menu, garage, market, lobby, guild, profile, settings, HUD) | UNTESTED | client never opened in Godot |
| Android/Windows export presets + CI workflow | UNTESTED | |
| iOS / macOS | MISSING | needs a Mac + Xcode + Apple Developer account |
| PostgreSQL / Redis | MISSING | SQLite only |
