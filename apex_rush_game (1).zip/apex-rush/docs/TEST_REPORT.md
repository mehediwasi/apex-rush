# TEST REPORT (real results, Linux, Python 3.12, no Godot available)
| Test | Result |
|---|---|
| tests.test_api: register/login/validation | PASS |
| buy/upgrade/sell | PASS |
| coin shortage + level gate | PASS |
| negative/float/injection inputs rejected | PASS |
| daily reward + cooldown | PASS |
| customize cost + validation | PASS |
| player market list/buy/tax/double-sell | PASS |
| guild lifecycle + permissions | PASS |
| guild request mode | PASS |
| tests.test_ws: 2 clients, lobby, ready gate, start, cheat rejection (skip checkpoint, teleport), full lap, results, DNF timeout, rewards persisted, best time | PASS |
| Server boot via run.py + HTTP/WS health | PASS |
| GDScript static check (tabs, brackets, res:// paths) | PASS (not a real parse) |
| Godot import / scene load / UI / physics / camera / audio | BLOCKED (no Godot) |
| Android APK / Windows build | BLOCKED (no Godot, SDK) |
| iOS / macOS | BLOCKED (no Mac) |
