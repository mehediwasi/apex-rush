"""Starts REST API (port 8000) + realtime WebSocket server (port 8765)."""
import threading
from app import config, ws
from app.api import create_app

if __name__ == "__main__":
    app = create_app()
    threading.Thread(target=ws.serve_forever, daemon=True).start()
    print(f"REST  http://{config.HTTP_HOST}:{config.HTTP_PORT}/api   WS ws://{config.WS_HOST}:{config.WS_PORT}")
    try:
        from waitress import serve
        serve(app, host=config.HTTP_HOST, port=config.HTTP_PORT, threads=8)
    except ImportError:
        print("waitress not installed -> using Flask dev server (fine for testing)")
        app.run(host=config.HTTP_HOST, port=config.HTTP_PORT, threaded=True)
