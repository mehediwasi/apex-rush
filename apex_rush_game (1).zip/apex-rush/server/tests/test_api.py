import os, sys, tempfile, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from app.api import create_app
from app import db, config


class Base(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.app = create_app(os.path.join(self.tmp, "t.db"))
        self.c = self.app.test_client()

    def reg(self, name, pw="secret123"):
        r = self.c.post("/api/auth/register", json={"username": name, "password": pw})
        self.assertEqual(r.status_code, 200, r.json)
        return {"Authorization": "Bearer " + r.json["token"]}, r.json["user"]

    def give(self, name, coins):
        con = db.connect(self.app.config["DB_PATH"])
        con.execute("UPDATE users SET coins=coins+? WHERE username=?", (coins, name))
        con.close()


class TestAuthEconomy(Base):
    def test_register_login_and_validation(self):
        h, u = self.reg("alice")
        self.assertEqual(u["coins"], config.START_COINS)
        self.assertEqual(self.c.post("/api/auth/register", json={"username": "alice", "password": "secret123"}).status_code, 409)
        self.assertEqual(self.c.post("/api/auth/register", json={"username": "a", "password": "secret123"}).status_code, 400)
        self.assertEqual(self.c.post("/api/auth/login", json={"username": "alice", "password": "bad"}).status_code, 401)
        self.assertEqual(self.c.post("/api/auth/login", json={"username": "ALICE", "password": "secret123"}).status_code, 200)
        self.assertEqual(self.c.get("/api/me").status_code, 401)
        g = self.c.get("/api/garage", headers=h).json["garage"]
        self.assertEqual(len(g), 1)

    def test_buy_upgrade_sell(self):
        h, u = self.reg("bob")
        cars = self.c.get("/api/cars?cls=D&sort=price", headers=h).json["cars"]
        target = next(c for c in cars if c["body"] in ("sedan", "hatchback") and not c["owned"])
        before = self.c.get("/api/me", headers=h).json["coins"]
        price = target["deal_price"] or target["price"]
        r = self.c.post("/api/market/buy", json={"car_id": target["id"]}, headers=h)
        self.assertEqual(r.status_code, 200, r.json)
        self.assertEqual(r.json["user"]["coins"], before - price)
        gid = r.json["garage_id"]
        up = self.c.post("/api/garage/upgrade", json={"garage_id": gid, "part": "engine"}, headers=h)
        self.assertEqual(up.status_code, 200, up.json)
        self.assertEqual(up.json["car"]["upgrades"]["engine"], 1)
        s = self.c.post("/api/garage/sell", json={"garage_id": gid}, headers=h)
        self.assertEqual(s.status_code, 200)
        self.assertGreater(s.json["value"], int(target["price"] * 0.55))
        # can't sell last car
        only = self.c.get("/api/garage", headers=h).json["garage"][0]["id"]
        self.assertEqual(self.c.post("/api/garage/sell", json={"garage_id": only}, headers=h).status_code, 400)

    def test_insufficient_coins_and_level_gate(self):
        h, _ = self.reg("carl")
        x = self.c.get("/api/cars?cls=X", headers=h).json["cars"][0]
        self.assertEqual(self.c.post("/api/market/buy", json={"car_id": x["id"]}, headers=h).status_code, 403)
        self.give("carl", 10_000_000)
        con = db.connect(self.app.config["DB_PATH"]); con.execute("UPDATE users SET level=20 WHERE username='carl'"); con.close()
        self.assertEqual(self.c.post("/api/market/buy", json={"car_id": x["id"]}, headers=h).status_code, 200)

    def test_no_negative_or_float_exploits(self):
        h, _ = self.reg("dan")
        self.assertEqual(self.c.post("/api/guilds/1/donate", json={"amount": -5000}, headers=h).status_code, 400)
        self.assertEqual(self.c.post("/api/garage/upgrade", json={"garage_id": "1; DROP", "part": "engine"}, headers=h).status_code, 400)
        self.assertEqual(self.c.post("/api/market/buy", json={"car_id": "nope"}, headers=h).status_code, 404)

    def test_daily(self):
        h, _ = self.reg("erin")
        r = self.c.post("/api/daily", headers=h)
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.json["streak"], 1)
        self.assertEqual(self.c.post("/api/daily", headers=h).status_code, 429)

    def test_customize_cost(self):
        h, u = self.reg("fay")
        gid = self.c.get("/api/garage", headers=h).json["garage"][0]["id"]
        r = self.c.post("/api/garage/customize", json={"garage_id": gid, "color": "#00ff00", "wheel_style": 3}, headers=h)
        self.assertEqual(r.status_code, 200, r.json)
        self.assertEqual(r.json["cost"], 2000)
        self.assertEqual(self.c.post("/api/garage/customize", json={"garage_id": gid, "color": "red"}, headers=h).status_code, 400)


class TestPlayerMarket(Base):
    def test_list_and_buy_with_tax(self):
        ha, _ = self.reg("seller")
        hb, _ = self.reg("buyer")
        self.give("seller", 200000)
        cars = self.c.get("/api/cars?body=sedan&sort=price", headers=ha).json["cars"]
        tgt = next(c for c in cars if not c["owned"] and c["cls"] in ("D", "C"))
        gid = self.c.post("/api/market/buy", json={"car_id": tgt["id"]}, headers=ha).json["garage_id"]
        self.assertEqual(self.c.post("/api/market/list", json={"garage_id": gid, "price": 10000}, headers=ha).status_code, 200)
        l = self.c.get("/api/market/listings", headers=hb).json["listings"]
        self.assertEqual(len(l), 1)
        sb = self.c.get("/api/me", headers=ha).json["coins"]
        self.assertEqual(self.c.post(f"/api/market/listings/{l[0]['listing_id']}/buy", headers=ha).status_code, 400)   # own car
        r = self.c.post(f"/api/market/listings/{l[0]['listing_id']}/buy", headers=hb)
        self.assertEqual(r.status_code, 200, r.json)
        self.assertEqual(self.c.get("/api/me", headers=ha).json["coins"], sb + 9500)
        self.assertEqual(self.c.post(f"/api/market/listings/{l[0]['listing_id']}/buy", headers=hb).status_code, 404)  # sold
        self.assertEqual(len(self.c.get("/api/garage", headers=hb).json["garage"]), 2)


class TestGuilds(Base):
    def test_lifecycle(self):
        ha, _ = self.reg("lead")
        hb, _ = self.reg("memb")
        r = self.c.post("/api/guilds", json={"name": "Speed Kings", "tag": "spk"}, headers=ha)
        self.assertEqual(r.status_code, 200, r.json)
        gid = r.json["guild"]["id"]
        self.assertEqual(r.json["guild"]["tag"], "SPK")
        self.assertEqual(self.c.get("/api/me", headers=ha).json["coins"], config.START_COINS - config.GUILD_CREATE_COST)
        self.assertEqual(self.c.post("/api/guilds", json={"name": "speed kings", "tag": "ZZ"}, headers=hb).status_code, 409)
        self.assertEqual(self.c.post(f"/api/guilds/{gid}/join", headers=hb).json["status"], "joined")
        self.assertEqual(self.c.get("/api/guilds/mine", headers=hb).json["guild"]["my_role"], "member")
        self.assertEqual(self.c.post(f"/api/guilds/{gid}/messages", json={"text": "hello"}, headers=hb).status_code, 200)
        msgs = self.c.get(f"/api/guilds/{gid}/messages", headers=ha).json["messages"]
        self.assertEqual(msgs[-1]["text"], "hello")
        self.assertEqual(self.c.post(f"/api/guilds/{gid}/donate", json={"amount": 5000}, headers=hb).status_code, 200)
        self.assertEqual(self.c.get("/api/guilds/mine", headers=ha).json["guild"]["bank_coins"], 5000)
        # member cannot kick/promote
        uid_l = self.c.get("/api/me", headers=ha).json["id"]
        uid_m = self.c.get("/api/me", headers=hb).json["id"]
        self.assertEqual(self.c.post(f"/api/guilds/{gid}/kick/{uid_l}", headers=hb).status_code, 403)
        self.assertEqual(self.c.post(f"/api/guilds/{gid}/role/{uid_m}", json={"role": "officer"}, headers=hb).status_code, 403)
        self.assertEqual(self.c.post(f"/api/guilds/{gid}/role/{uid_m}", json={"role": "officer"}, headers=ha).status_code, 200)
        # leader leaves -> officer becomes leader
        self.assertEqual(self.c.post("/api/guilds/leave", headers=ha).status_code, 200)
        self.assertEqual(self.c.get("/api/guilds/mine", headers=hb).json["guild"]["my_role"], "leader")

    def test_request_mode(self):
        ha, _ = self.reg("own")
        hb, ub = self.reg("wannabe")
        gid = self.c.post("/api/guilds", json={"name": "Closed Club", "tag": "CC", "join_mode": "request"}, headers=ha).json["guild"]["id"]
        self.assertEqual(self.c.post(f"/api/guilds/{gid}/join", headers=hb).json["status"], "requested")
        reqs = self.c.get("/api/guilds/mine", headers=ha).json["guild"]["requests"]
        self.assertEqual(len(reqs), 1)
        self.assertEqual(self.c.post(f"/api/guilds/{gid}/requests/{ub['id']}/accept", headers=hb).status_code, 403)
        self.assertEqual(self.c.post(f"/api/guilds/{gid}/requests/{ub['id']}/accept", headers=ha).status_code, 200)
        self.assertEqual(self.c.get("/api/guilds/mine", headers=hb).json["guild"]["name"], "Closed Club")


if __name__ == "__main__":
    unittest.main()
