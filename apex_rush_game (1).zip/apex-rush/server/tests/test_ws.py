import asyncio, base64, json, os, struct, sys, tempfile, unittest, math
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from app import ws, db
from app.api import create_app


class Client:
    def __init__(self, r, w):
        self.r, self.w, self.inbox = r, w, []

    @classmethod
    async def connect(cls, port):
        r, w = await asyncio.open_connection("127.0.0.1", port)
        key = base64.b64encode(os.urandom(16)).decode()
        w.write(f"GET / HTTP/1.1\r\nHost: x\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Key: {key}\r\nSec-WebSocket-Version: 13\r\n\r\n".encode())
        head = await r.readuntil(b"\r\n\r\n")
        assert b"101" in head
        return cls(r, w)


    def send(self, obj):
        data = json.dumps(obj).encode()
        mask = os.urandom(4)
        n = len(data)
        h = bytes([0x81])
        h += bytes([0x80 | n]) if n < 126 else bytes([0x80 | 126]) + struct.pack(">H", n)
        self.w.write(h + mask + bytes(b ^ mask[i % 4] for i, b in enumerate(data)))

    async def pump(self, timeout=0.15):
        """Read frames for `timeout` seconds total (snapshots arrive continuously during a race)."""
        end = asyncio.get_running_loop().time() + timeout
        try:
            while True:
                left = end - asyncio.get_running_loop().time()
                if left <= 0:
                    return
                hdr = await asyncio.wait_for(self.r.readexactly(2), left)
                n = hdr[1] & 0x7F
                if n == 126:
                    n = struct.unpack(">H", await self.r.readexactly(2))[0]
                elif n == 127:
                    n = struct.unpack(">Q", await self.r.readexactly(8))[0]
                data = await self.r.readexactly(n)
                if hdr[0] & 0x0F == 1:
                    self.inbox.append(json.loads(data))
        except (asyncio.TimeoutError, asyncio.IncompleteReadError):
            pass

    def get(self, t):
        return [m for m in self.inbox if m["t"] == t]


class TestRace(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.tmp = tempfile.mkdtemp()
        path = os.path.join(self.tmp, "t.db")
        app = create_app(path)
        cl = app.test_client()
        self.tok = {}
        for n in ("ann", "ben"):
            self.tok[n] = cl.post("/api/auth/register", json={"username": n, "password": "secret123"}).json["token"]
        self.path = path
        self.clients = []
        self.clock = [1_700_000_000_000.0]
        self._now, self._grace = ws.now_ms, ws.FINISH_GRACE_MS
        ws.now_ms = lambda: self.clock[0]
        ws.FINISH_GRACE_MS = 300
        self.hub = ws.Hub(path)
        self.srv = await ws.run_server(self.hub, "127.0.0.1", 0)
        self.port = self.srv.sockets[0].getsockname()[1]

    async def asyncTearDown(self):
        ws.now_ms, ws.FINISH_GRACE_MS = self._now, self._grace
        for c in list(self.hub.conns.values()):
            c.close()
        for cl in self.clients:
            cl.w.close()
        self.srv.close()
        try:
            await asyncio.wait_for(self.srv.wait_closed(), 2)
        except asyncio.TimeoutError:
            pass

    async def login(self, name):
        c = await Client.connect(self.port)
        self.clients.append(c)
        c.send({"t": "auth", "token": self.tok[name]})
        await c.pump()
        assert c.get("auth.ok"), c.inbox
        return c

    async def test_full_race_flow_and_anticheat(self):
        a, b = await self.login("ann"), await self.login("ben")
        bad = await Client.connect(self.port)
        self.clients.append(bad)
        bad.send({"t": "auth", "token": "garbage"})
        await bad.pump()
        self.assertTrue(bad.get("auth.fail"))

        a.send({"t": "chat", "scope": "global", "msg": "hi all"})
        await b.pump()
        self.assertEqual(b.get("chat")[0]["msg"], "hi all")

        with open(os.path.join(os.path.dirname(__file__), "..", "data", "tracks", "index.json")) as f:
            idx = json.load(f)
        short = min(idx, key=lambda t: t["length_m"])["file"][:-4]
        a.send({"t": "lobby.create", "track_id": short, "laps": 1, "max_players": 4})
        await a.pump()
        lid = a.get("lobby.state")[-1]["id"]
        b.send({"t": "lobby.join", "id": lid})
        a.send({"t": "lobby.start"})                 # B not ready -> must refuse
        await a.pump(); await b.pump()
        self.assertTrue(any("ready" in m.get("msg", "") for m in a.get("error")))
        b.send({"t": "lobby.ready", "ready": True})
        await b.pump()
        a.send({"t": "lobby.start"})
        await a.pump(); await b.pump()
        st = a.get("race.start")[0]
        cps = st["checkpoints"]
        n = len(cps)
        self.assertGreater(n, 5)
        self.assertEqual(len(st["grid"]), 2)

        self.clock[0] = st["start_at"] + 1000
        # cheat 1: skipping checkpoints
        a.send({"t": "race.cp", "i": 5})
        # cheat 2: teleport
        a.send({"t": "race.state", "p": [cps[3][0], cps[3][1], cps[3][2]], "v": 30})
        await a.pump()
        self.assertTrue(a.get("race.cp.reject"))
        self.assertEqual(self.hub.lobbies[lid].players[self.hub.conns and list(self.hub.conns)[0]].cp_count, 0)

        # legit lap: drive through checkpoints at 40 m/s
        prev = st["grid"][str(list(self.hub.lobbies[lid].players)[0])]
        order = list(range(1, n)) + [0]
        pos_prev = None
        for i in order:
            cp = cps[i]
            ref = cps[i - 1] if i else cps[n - 1]
            seg = math.dist((ref[0], ref[2]), (cp[0], cp[2]))
            self.clock[0] += max(1500, seg / 40 * 1000)
            a.send({"t": "race.state", "p": cp, "v": 40, "r": [0, 0, 0, 1]})
            a.send({"t": "race.cp", "i": i})
            await a.pump(0.02)
        await a.pump(0.7); await b.pump(0.2)
        self.assertTrue(a.get("race.finished"), a.inbox[-5:])
        res = a.get("race.results")
        self.assertTrue(res, "no results (timeout path)")
        rows = {r["name"]: r for r in res[0]["rows"]}
        self.assertEqual(rows["ann"]["pos"], 1)
        self.assertFalse(rows["ann"]["dnf"])
        self.assertTrue(rows["ben"]["dnf"])
        self.assertGreater(rows["ann"]["coins"], rows["ben"]["coins"])

        con = db.connect(self.path)
        u = con.execute("SELECT coins,races,wins FROM users WHERE username='ann'").fetchone()
        self.assertEqual(u["races"], 1); self.assertEqual(u["wins"], 1)
        self.assertGreater(u["coins"], 45000 - 0 - 1)
        self.assertEqual(con.execute("SELECT COUNT(*) FROM best_times").fetchone()[0], 1)
        # lobby back to waiting
        self.assertEqual(self.hub.lobbies[lid].state, "waiting")


if __name__ == "__main__":
    unittest.main()
