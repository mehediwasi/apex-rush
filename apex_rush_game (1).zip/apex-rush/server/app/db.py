import sqlite3, time
from contextlib import contextmanager
from . import config

SCHEMA = """
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL UNIQUE COLLATE NOCASE,
  pass_hash TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  coins INTEGER NOT NULL DEFAULT 0 CHECK(coins >= 0),
  gems INTEGER NOT NULL DEFAULT 0 CHECK(gems >= 0),
  xp INTEGER NOT NULL DEFAULT 0,
  level INTEGER NOT NULL DEFAULT 1,
  avatar INTEGER NOT NULL DEFAULT 0,
  selected_garage_id INTEGER,
  last_daily INTEGER NOT NULL DEFAULT 0,
  streak INTEGER NOT NULL DEFAULT 0,
  banned INTEGER NOT NULL DEFAULT 0,
  races INTEGER NOT NULL DEFAULT 0,
  wins INTEGER NOT NULL DEFAULT 0,
  podiums INTEGER NOT NULL DEFAULT 0,
  takedowns INTEGER NOT NULL DEFAULT 0,
  distance_m REAL NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS cars(
  id TEXT PRIMARY KEY, make TEXT, model TEXT, year INTEGER, cls TEXT, body TEXT, drive TEXT,
  power_hp INTEGER, mass_kg INTEGER, top_kmh INTEGER, accel_s REAL, handling INTEGER, braking INTEGER,
  pi INTEGER, price INTEGER, rarity TEXT
);
CREATE TABLE IF NOT EXISTS garage(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  car_id TEXT NOT NULL REFERENCES cars(id),
  color TEXT NOT NULL DEFAULT '#d01818',
  wheel_style INTEGER NOT NULL DEFAULT 0,
  decal INTEGER NOT NULL DEFAULT 0,
  neon TEXT NOT NULL DEFAULT '',
  upgrades TEXT NOT NULL DEFAULT '{}',
  invested INTEGER NOT NULL DEFAULT 0,
  listed INTEGER NOT NULL DEFAULT 0,
  odometer_km REAL NOT NULL DEFAULT 0,
  acquired_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_garage_user ON garage(user_id);
CREATE TABLE IF NOT EXISTS transactions(
  id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, kind TEXT NOT NULL,
  amount INTEGER NOT NULL, balance_after INTEGER NOT NULL, meta TEXT, created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_tx_user ON transactions(user_id, id DESC);
CREATE TABLE IF NOT EXISTS listings(
  id INTEGER PRIMARY KEY AUTOINCREMENT, seller_id INTEGER NOT NULL, garage_id INTEGER NOT NULL UNIQUE,
  price INTEGER NOT NULL CHECK(price > 0), status TEXT NOT NULL DEFAULT 'active', created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS guilds(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE COLLATE NOCASE, tag TEXT NOT NULL UNIQUE COLLATE NOCASE,
  description TEXT NOT NULL DEFAULT '', emblem INTEGER NOT NULL DEFAULT 0,
  leader_id INTEGER NOT NULL, bank_coins INTEGER NOT NULL DEFAULT 0 CHECK(bank_coins >= 0),
  xp INTEGER NOT NULL DEFAULT 0, level INTEGER NOT NULL DEFAULT 1,
  join_mode TEXT NOT NULL DEFAULT 'open', min_level INTEGER NOT NULL DEFAULT 1,
  max_members INTEGER NOT NULL DEFAULT 50, created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS guild_members(
  user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  guild_id INTEGER NOT NULL REFERENCES guilds(id) ON DELETE CASCADE,
  role TEXT NOT NULL DEFAULT 'member', joined_at INTEGER NOT NULL, contributed INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_gm_guild ON guild_members(guild_id);
CREATE TABLE IF NOT EXISTS guild_requests(
  guild_id INTEGER NOT NULL, user_id INTEGER NOT NULL, created_at INTEGER NOT NULL, PRIMARY KEY(guild_id, user_id)
);
CREATE TABLE IF NOT EXISTS guild_messages(
  id INTEGER PRIMARY KEY AUTOINCREMENT, guild_id INTEGER NOT NULL, user_id INTEGER NOT NULL,
  text TEXT NOT NULL, created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_gmsg ON guild_messages(guild_id, id DESC);
CREATE TABLE IF NOT EXISTS races(
  id INTEGER PRIMARY KEY AUTOINCREMENT, track_id TEXT NOT NULL, laps INTEGER NOT NULL,
  players INTEGER NOT NULL, created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS race_results(
  race_id INTEGER NOT NULL, user_id INTEGER NOT NULL, position INTEGER NOT NULL, time_ms INTEGER,
  coins INTEGER NOT NULL, xp INTEGER NOT NULL, car_id TEXT, takedowns INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY(race_id, user_id)
);
CREATE TABLE IF NOT EXISTS best_times(
  track_id TEXT NOT NULL, user_id INTEGER NOT NULL, time_ms INTEGER NOT NULL, car_id TEXT,
  PRIMARY KEY(track_id, user_id)
);
"""


def now() -> int:
    return int(time.time())


def connect(path=None) -> sqlite3.Connection:
    c = sqlite3.connect(path or config.DB_PATH, timeout=15, isolation_level=None)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA journal_mode=WAL")
    c.execute("PRAGMA foreign_keys=ON")
    c.execute("PRAGMA busy_timeout=15000")
    return c


@contextmanager
def tx(conn):
    conn.execute("BEGIN IMMEDIATE")
    try:
        yield conn
    except BaseException:
        conn.execute("ROLLBACK")
        raise
    else:
        conn.execute("COMMIT")


def init_db(path=None):
    from . import catalog
    c = connect(path)
    c.executescript(SCHEMA)
    catalog.seed(c)
    c.close()
