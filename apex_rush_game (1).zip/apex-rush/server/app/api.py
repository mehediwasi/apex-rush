import functools, json, re, time, collections
from flask import Blueprint, g, jsonify, request, current_app
from . import db, config, security, catalog, economy
from .economy import GameError

bp = Blueprint("api", __name__, url_prefix="/api")
_rate = collections.defaultdict(list)


def rate_limit(key, n, per):
    now = time.time()
    q = [t for t in _rate[key] if now - t < per]
    if len(q) >= n:
        _rate[key] = q
        raise GameError("Too many requests, slow down", 429)
    q.append(now)
    _rate[key] = q


def conn():
    if "db" not in g:
        g.db = db.connect(current_app.config.get("DB_PATH"))
    return g.db


@bp.teardown_app_request
def _close(exc):
    c = g.pop("db", None)
    if c:
        c.close()


@bp.errorhandler(GameError)
def _ge(e):
    return jsonify(error=e.msg), e.status


def auth(fn):
    @functools.wraps(fn)
    def w(*a, **kw):
        h = request.headers.get("Authorization", "")
        uid = security.decode_token(h[7:]) if h.startswith("Bearer ") else None
        if not uid:
            raise GameError("Unauthorized", 401)
        u = conn().execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
        if not u or u["banned"]:
            raise GameError("Unauthorized", 401)
        g.uid, g.user = uid, u
        return fn(*a, **kw)
    return w


def body():
    d = request.get_json(silent=True)
    if not isinstance(d, dict):
        raise GameError("JSON body required")
    return d


def int_field(d, k, lo=1, hi=10 ** 12):
    v = d.get(k)
    if isinstance(v, bool) or not isinstance(v, int) or not (lo <= v <= hi):
        raise GameError(f"Invalid {k}")
    return v


# ---------------- serializers ----------------
def guild_of(c, uid):
    return c.execute("""SELECT g.id, g.name, g.tag, gm.role FROM guild_members gm JOIN guilds g ON g.id=gm.guild_id
                        WHERE gm.user_id=?""", (uid,)).fetchone()


def user_json(c, u):
    gd = guild_of(c, u["id"])
    return dict(id=u["id"], username=u["username"], coins=u["coins"], gems=u["gems"], xp=u["xp"], level=u["level"],
                avatar=u["avatar"], selected_garage_id=u["selected_garage_id"], races=u["races"], wins=u["wins"],
                podiums=u["podiums"], takedowns=u["takedowns"], distance_km=round(u["distance_m"] / 1000, 1),
                next_level_xp=(u["level"]) ** 2 * 120, streak=u["streak"],
                daily_ready=(db.now() - u["last_daily"]) >= 20 * 3600,
                guild=dict(gd) if gd else None)


def garage_json(c, r):
    car = c.execute("SELECT * FROM cars WHERE id=?", (r["car_id"],)).fetchone()
    up = json.loads(r["upgrades"])
    return dict(id=r["id"], car=catalog.row_to_car(car), color=r["color"], wheel_style=r["wheel_style"],
                decal=r["decal"], neon=r["neon"], upgrades=up, listed=bool(r["listed"]),
                odometer_km=round(r["odometer_km"], 1), stats=catalog.effective_stats(car, up),
                sell_value=economy.sell_value(c, r))


# ---------------- auth ----------------
USER_RE = re.compile(r"^[A-Za-z0-9_]{3,16}$")


@bp.post("/auth/register")
def register():
    rate_limit("reg:" + request.remote_addr, 10, 600)
    d = body()
    name, pw = str(d.get("username", "")), str(d.get("password", ""))
    if not USER_RE.match(name):
        raise GameError("Username: 3-16 letters, digits or _")
    if not (6 <= len(pw) <= 100):
        raise GameError("Password must be 6-100 characters")
    c = conn()
    try:
        with db.tx(c):
            cur = c.execute("INSERT INTO users(username,pass_hash,created_at,coins,gems) VALUES(?,?,?,?,?)",
                            (name, security.hash_password(pw), db.now(), 0, config.START_GEMS))
            uid = cur.lastrowid
            economy.add_coins(c, uid, config.START_COINS, "welcome")
            economy.give_car(c, uid, economy.starter_car_id(c))
    except Exception as e:
        if "UNIQUE" in str(e):
            raise GameError("Username already taken", 409)
        raise
    return jsonify(token=security.make_token(uid), user=user_json(c, c.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()))


@bp.post("/auth/login")
def login():
    rate_limit("login:" + request.remote_addr, 20, 300)
    d = body()
    u = conn().execute("SELECT * FROM users WHERE username=?", (str(d.get("username", "")),)).fetchone()
    if not u or not security.verify_password(str(d.get("password", "")), u["pass_hash"]) or u["banned"]:
        raise GameError("Wrong username or password", 401)
    return jsonify(token=security.make_token(u["id"]), user=user_json(conn(), u))


@bp.get("/me")
@auth
def me():
    return jsonify(user_json(conn(), g.user))


@bp.post("/me/avatar")
@auth
def set_avatar():
    a = int_field(body(), "avatar", 0, 63)
    conn().execute("UPDATE users SET avatar=? WHERE id=?", (a, g.uid))
    return jsonify(ok=True)


@bp.post("/daily")
@auth
def daily():
    c = conn()
    with db.tx(c):
        u = c.execute("SELECT * FROM users WHERE id=?", (g.uid,)).fetchone()
        elapsed = db.now() - u["last_daily"]
        if elapsed < 20 * 3600:
            raise GameError("Daily reward not ready yet", 429)
        streak = u["streak"] + 1 if elapsed < 48 * 3600 else 1
        coins = 2000 + 500 * min(streak, 14)
        gems = 5 if streak % 7 == 0 else 0
        economy.add_coins(c, g.uid, coins, "daily", {"streak": streak})
        c.execute("UPDATE users SET last_daily=?, streak=?, gems=gems+? WHERE id=?", (db.now(), streak, gems, g.uid))
    return jsonify(coins=coins, gems=gems, streak=streak, user=user_json(c, c.execute("SELECT * FROM users WHERE id=?", (g.uid,)).fetchone()))


# ---------------- catalog / market ----------------
@bp.get("/cars")
@auth
def cars():
    c = conn()
    q, args = "SELECT * FROM cars WHERE 1=1", []
    for k in ("cls", "body", "make", "drive"):
        v = request.args.get(k)
        if v:
            q += f" AND {k}=?"
            args.append(v)
    sort = request.args.get("sort", "pi")
    if sort not in ("pi", "price", "top_kmh", "power_hp", "year", "accel_s"):
        sort = "pi"
    q += f" ORDER BY {sort} {'DESC' if request.args.get('desc') == '1' else 'ASC'}"
    day = db.now() // 86400
    deals = economy.daily_deal_ids(c, day)
    owned = {r[0] for r in c.execute("SELECT car_id FROM garage WHERE user_id=?", (g.uid,))}
    out = []
    for r in c.execute(q, args):
        d = catalog.row_to_car(r)
        d["deal_price"] = economy.deal_price(d["price"]) if d["id"] in deals else None
        d["owned"] = d["id"] in owned
        out.append(d)
    return jsonify(cars=out, deals=sorted(deals))


@bp.post("/market/buy")
@auth
def buy():
    car_id = str(body().get("car_id", ""))
    c = conn()
    with db.tx(c):
        car = c.execute("SELECT * FROM cars WHERE id=?", (car_id,)).fetchone()
        if not car:
            raise GameError("Unknown car", 404)
        u = c.execute("SELECT level FROM users WHERE id=?", (g.uid,)).fetchone()
        need = {"D": 1, "C": 1, "B": 3, "A": 6, "S": 10, "X": 15}[car["cls"]]
        if u["level"] < need:
            raise GameError(f"Requires player level {need}", 403)
        price = car["price"]
        if car_id in economy.daily_deal_ids(c, db.now() // 86400):
            price = economy.deal_price(price)
        if c.execute("SELECT COUNT(*) FROM garage WHERE user_id=?", (g.uid,)).fetchone()[0] >= 100:
            raise GameError("Garage full (100)")
        economy.add_coins(c, g.uid, -price, "buy_car", {"car": car_id})
        gid = economy.give_car(c, g.uid, car_id)
    return jsonify(garage_id=gid, user=user_json(c, c.execute("SELECT * FROM users WHERE id=?", (g.uid,)).fetchone()))


@bp.get("/garage")
@auth
def garage():
    c = conn()
    rows = c.execute("SELECT * FROM garage WHERE user_id=? ORDER BY id", (g.uid,)).fetchall()
    return jsonify(garage=[garage_json(c, r) for r in rows], parts={k: dict(name=v[0], desc=v[1]) for k, v in catalog.PARTS.items()})


def owned_row(c, gid, allow_listed=False):
    r = c.execute("SELECT * FROM garage WHERE id=? AND user_id=?", (gid, g.uid)).fetchone()
    if not r:
        raise GameError("Car not found", 404)
    if r["listed"] and not allow_listed:
        raise GameError("Car is listed on the market")
    return r


@bp.post("/garage/select")
@auth
def select():
    gid = int_field(body(), "garage_id")
    c = conn()
    owned_row(c, gid)
    c.execute("UPDATE users SET selected_garage_id=? WHERE id=?", (gid, g.uid))
    return jsonify(ok=True)


@bp.post("/garage/upgrade")
@auth
def upgrade():
    d = body()
    gid, part = int_field(d, "garage_id"), str(d.get("part", ""))
    if part not in catalog.PARTS:
        raise GameError("Unknown part")
    c = conn()
    with db.tx(c):
        r = owned_row(c, gid)
        up = json.loads(r["upgrades"])
        lvl = int(up.get(part, 0))
        if lvl >= config.MAX_UPGRADE_LEVEL:
            raise GameError("Already max level")
        price = c.execute("SELECT price FROM cars WHERE id=?", (r["car_id"],)).fetchone()[0]
        cost = catalog.upgrade_cost(price, part, lvl)
        economy.add_coins(c, g.uid, -cost, "upgrade", {"garage": gid, "part": part, "to": lvl + 1})
        up[part] = lvl + 1
        c.execute("UPDATE garage SET upgrades=?, invested=invested+? WHERE id=?", (json.dumps(up), cost, gid))
    r = c.execute("SELECT * FROM garage WHERE id=?", (gid,)).fetchone()
    return jsonify(car=garage_json(c, r), cost=cost)


@bp.get("/garage/<int:gid>/upgrade-costs")
@auth
def upgrade_costs(gid):
    c = conn()
    r = owned_row(c, gid, True)
    up = json.loads(r["upgrades"])
    price = c.execute("SELECT price FROM cars WHERE id=?", (r["car_id"],)).fetchone()[0]
    return jsonify(costs={p: (catalog.upgrade_cost(price, p, int(up.get(p, 0))) if int(up.get(p, 0)) < config.MAX_UPGRADE_LEVEL else None) for p in catalog.PARTS})


HEX = re.compile(r"^#[0-9a-fA-F]{6}$")


@bp.post("/garage/customize")
@auth
def customize():
    d = body()
    gid = int_field(d, "garage_id")
    c = conn()
    with db.tx(c):
        r = owned_row(c, gid)
        color, wheel, decal, neon = r["color"], r["wheel_style"], r["decal"], r["neon"]
        cost = 0
        if "color" in d:
            if not HEX.match(str(d["color"])):
                raise GameError("Invalid color")
            if d["color"] != color:
                color, cost = d["color"], cost + 500
        if "wheel_style" in d:
            w = int_field(d, "wheel_style", 0, 11)
            if w != wheel:
                wheel, cost = w, cost + 1500
        if "decal" in d:
            dc = int_field(d, "decal", 0, 23)
            if dc != decal:
                decal, cost = dc, cost + 1000
        if "neon" in d:
            n = str(d["neon"])
            if n and not HEX.match(n):
                raise GameError("Invalid neon color")
            if n != neon:
                neon, cost = n, cost + 2500
        if cost:
            economy.add_coins(c, g.uid, -cost, "customize", {"garage": gid})
        c.execute("UPDATE garage SET color=?, wheel_style=?, decal=?, neon=? WHERE id=?", (color, wheel, decal, neon, gid))
    return jsonify(car=garage_json(c, c.execute("SELECT * FROM garage WHERE id=?", (gid,)).fetchone()), cost=cost)


@bp.post("/garage/sell")
@auth
def sell():
    gid = int_field(body(), "garage_id")
    c = conn()
    with db.tx(c):
        r = owned_row(c, gid)
        if c.execute("SELECT COUNT(*) FROM garage WHERE user_id=?", (g.uid,)).fetchone()[0] <= 1:
            raise GameError("You must keep at least one car")
        value = economy.sell_value(c, r)
        economy.add_coins(c, g.uid, value, "sell_car", {"garage": gid, "car": r["car_id"]})
        c.execute("DELETE FROM garage WHERE id=?", (gid,))
        sel = c.execute("SELECT selected_garage_id FROM users WHERE id=?", (g.uid,)).fetchone()[0]
        if sel == gid:
            nxt = c.execute("SELECT id FROM garage WHERE user_id=? ORDER BY id LIMIT 1", (g.uid,)).fetchone()[0]
            c.execute("UPDATE users SET selected_garage_id=? WHERE id=?", (nxt, g.uid))
    return jsonify(value=value, user=user_json(c, c.execute("SELECT * FROM users WHERE id=?", (g.uid,)).fetchone()))


# ---------------- player market ----------------
@bp.post("/market/list")
@auth
def list_car():
    d = body()
    gid, price = int_field(d, "garage_id"), int_field(d, "price", 500, 50_000_000)
    c = conn()
    with db.tx(c):
        r = owned_row(c, gid)
        if c.execute("SELECT COUNT(*) FROM garage WHERE user_id=? AND listed=0", (g.uid,)).fetchone()[0] <= 1:
            raise GameError("You must keep at least one unlisted car")
        if c.execute("SELECT selected_garage_id FROM users WHERE id=?", (g.uid,)).fetchone()[0] == gid:
            nxt = c.execute("SELECT id FROM garage WHERE user_id=? AND listed=0 AND id<>? LIMIT 1", (g.uid, gid)).fetchone()[0]
            c.execute("UPDATE users SET selected_garage_id=? WHERE id=?", (nxt, g.uid))
        c.execute("UPDATE garage SET listed=1 WHERE id=?", (gid,))
        c.execute("INSERT INTO listings(seller_id,garage_id,price,created_at) VALUES(?,?,?,?)", (g.uid, gid, price, db.now()))
    return jsonify(ok=True)


@bp.get("/market/listings")
@auth
def listings():
    c = conn()
    rows = c.execute("""SELECT l.id lid, l.price, l.seller_id, u.username seller, l.garage_id
                        FROM listings l JOIN users u ON u.id=l.seller_id WHERE l.status='active' ORDER BY l.id DESC LIMIT 200""").fetchall()
    out = []
    for r in rows:
        gr = c.execute("SELECT * FROM garage WHERE id=?", (r["garage_id"],)).fetchone()
        out.append(dict(listing_id=r["lid"], price=r["price"], seller=r["seller"], mine=r["seller_id"] == g.uid, car=garage_json(c, gr)))
    return jsonify(listings=out, tax=config.MARKET_TAX)


@bp.post("/market/listings/<int:lid>/buy")
@auth
def buy_listing(lid):
    c = conn()
    with db.tx(c):
        l = c.execute("SELECT * FROM listings WHERE id=? AND status='active'", (lid,)).fetchone()
        if not l:
            raise GameError("Listing not available", 404)
        if l["seller_id"] == g.uid:
            raise GameError("Cannot buy your own car")
        economy.add_coins(c, g.uid, -l["price"], "market_buy", {"listing": lid})
        economy.add_coins(c, l["seller_id"], int(l["price"] * (1 - config.MARKET_TAX)), "market_sale", {"listing": lid})
        c.execute("UPDATE garage SET user_id=?, listed=0 WHERE id=?", (g.uid, l["garage_id"]))
        c.execute("UPDATE listings SET status='sold' WHERE id=?", (lid,))
    return jsonify(ok=True, user=user_json(c, c.execute("SELECT * FROM users WHERE id=?", (g.uid,)).fetchone()))


@bp.post("/market/listings/<int:lid>/cancel")
@auth
def cancel_listing(lid):
    c = conn()
    with db.tx(c):
        l = c.execute("SELECT * FROM listings WHERE id=? AND seller_id=? AND status='active'", (lid, g.uid)).fetchone()
        if not l:
            raise GameError("Listing not found", 404)
        c.execute("UPDATE listings SET status='cancelled' WHERE id=?", (lid,))
        c.execute("UPDATE garage SET listed=0 WHERE id=?", (l["garage_id"],))
    return jsonify(ok=True)


# ---------------- tracks / leaderboards ----------------
_tracks_cache = None


def tracks_index():
    global _tracks_cache
    if _tracks_cache is None:
        idx = json.loads((config.TRACKS_DIR / "index.json").read_text())
        _tracks_cache = [dict(id=t["file"][:-4], name=t["name"], theme=t["theme"], style=t["style"], time=t["time"],
                              length_m=t["length_m"], width_m=t["width_m"], elevation_m=t["elevation_range_m"],
                              laps=t["laps_suggested"]) for t in idx]
    return _tracks_cache


@bp.get("/tracks")
@auth
def tracks():
    return jsonify(tracks=tracks_index())


@bp.get("/leaderboard/<kind>")
@auth
def leaderboard(kind):
    c = conn()
    if kind == "level":
        rows = c.execute("SELECT username, level, xp, wins FROM users WHERE banned=0 ORDER BY xp DESC LIMIT 50")
        return jsonify(rows=[dict(r) for r in rows])
    if kind == "wins":
        rows = c.execute("SELECT username, wins, races FROM users WHERE banned=0 ORDER BY wins DESC LIMIT 50")
        return jsonify(rows=[dict(r) for r in rows])
    if kind == "guilds":
        rows = c.execute("SELECT name, tag, level, xp, (SELECT COUNT(*) FROM guild_members WHERE guild_id=guilds.id) members FROM guilds ORDER BY xp DESC LIMIT 50")
        return jsonify(rows=[dict(r) for r in rows])
    if kind == "track":
        t = request.args.get("track_id", "")
        rows = c.execute("""SELECT u.username, b.time_ms, b.car_id FROM best_times b JOIN users u ON u.id=b.user_id
                            WHERE b.track_id=? ORDER BY b.time_ms LIMIT 50""", (t,))
        return jsonify(rows=[dict(r) for r in rows])
    raise GameError("Unknown leaderboard", 404)


@bp.get("/transactions")
@auth
def transactions():
    rows = conn().execute("SELECT kind, amount, balance_after, created_at FROM transactions WHERE user_id=? ORDER BY id DESC LIMIT 50", (g.uid,))
    return jsonify(rows=[dict(r) for r in rows])


# ---------------- guilds ----------------
ROLE_RANK = {"member": 0, "officer": 1, "leader": 2}


def guild_level(xp):
    return 1 + int((max(0, xp) / 500) ** 0.5)


def guild_json(c, gr, full=False):
    members = c.execute("SELECT COUNT(*) FROM guild_members WHERE guild_id=?", (gr["id"],)).fetchone()[0]
    d = dict(id=gr["id"], name=gr["name"], tag=gr["tag"], description=gr["description"], emblem=gr["emblem"],
             level=gr["level"], xp=gr["xp"], members=members, max_members=gr["max_members"], join_mode=gr["join_mode"],
             min_level=gr["min_level"], bank_coins=gr["bank_coins"])
    if full:
        rows = c.execute("""SELECT u.id, u.username, u.level, u.avatar, gm.role, gm.contributed FROM guild_members gm
                            JOIN users u ON u.id=gm.user_id WHERE gm.guild_id=? ORDER BY CASE gm.role WHEN 'leader' THEN 0 WHEN 'officer' THEN 1 ELSE 2 END, gm.contributed DESC""", (gr["id"],))
        d["member_list"] = [dict(r) for r in rows]
    return d


def my_membership(c):
    return c.execute("SELECT * FROM guild_members WHERE user_id=?", (g.uid,)).fetchone()


def need_role(c, gid, minrole):
    m = my_membership(c)
    if not m or m["guild_id"] != gid or ROLE_RANK[m["role"]] < ROLE_RANK[minrole]:
        raise GameError("Not allowed", 403)
    return m


@bp.post("/guilds")
@auth
def guild_create():
    d = body()
    name, tag = str(d.get("name", "")).strip(), str(d.get("tag", "")).strip().upper()
    if not re.match(r"^[A-Za-z0-9 ]{3,20}$", name) or not re.match(r"^[A-Z0-9]{2,4}$", tag):
        raise GameError("Name 3-20 chars, tag 2-4 letters/digits")
    c = conn()
    try:
        with db.tx(c):
            if my_membership(c):
                raise GameError("Leave your current guild first")
            economy.add_coins(c, g.uid, -config.GUILD_CREATE_COST, "guild_create")
            cur = c.execute("INSERT INTO guilds(name,tag,description,emblem,leader_id,created_at,join_mode) VALUES(?,?,?,?,?,?,?)",
                            (name, tag, str(d.get("description", ""))[:200], int(d.get("emblem", 0)) % 32, g.uid, db.now(),
                             "request" if d.get("join_mode") == "request" else "open"))
            c.execute("INSERT INTO guild_members(user_id,guild_id,role,joined_at) VALUES(?,?, 'leader',?)", (g.uid, cur.lastrowid, db.now()))
    except GameError:
        raise
    except Exception as e:
        if "UNIQUE" in str(e):
            raise GameError("Guild name or tag already exists", 409)
        raise
    return jsonify(guild=guild_json(c, c.execute("SELECT * FROM guilds WHERE id=?", (cur.lastrowid,)).fetchone(), True))


@bp.get("/guilds")
@auth
def guild_search():
    q = "%" + request.args.get("q", "").strip() + "%"
    rows = conn().execute("SELECT * FROM guilds WHERE name LIKE ? OR tag LIKE ? ORDER BY xp DESC LIMIT 40", (q, q)).fetchall()
    return jsonify(guilds=[guild_json(conn(), r) for r in rows])


@bp.get("/guilds/mine")
@auth
def guild_mine():
    c = conn()
    m = my_membership(c)
    if not m:
        return jsonify(guild=None)
    gr = c.execute("SELECT * FROM guilds WHERE id=?", (m["guild_id"],)).fetchone()
    d = guild_json(c, gr, True)
    d["my_role"] = m["role"]
    if ROLE_RANK[m["role"]] >= 1:
        d["requests"] = [dict(r) for r in c.execute("""SELECT u.id, u.username, u.level FROM guild_requests r JOIN users u ON u.id=r.user_id WHERE r.guild_id=?""", (gr["id"],))]
    return jsonify(guild=d)


@bp.post("/guilds/<int:gid>/join")
@auth
def guild_join(gid):
    c = conn()
    with db.tx(c):
        if my_membership(c):
            raise GameError("Leave your current guild first")
        gr = c.execute("SELECT * FROM guilds WHERE id=?", (gid,)).fetchone()
        if not gr:
            raise GameError("Guild not found", 404)
        if g.user["level"] < gr["min_level"]:
            raise GameError(f"Requires level {gr['min_level']}")
        if c.execute("SELECT COUNT(*) FROM guild_members WHERE guild_id=?", (gid,)).fetchone()[0] >= gr["max_members"]:
            raise GameError("Guild is full")
        if gr["join_mode"] == "request":
            c.execute("INSERT OR IGNORE INTO guild_requests(guild_id,user_id,created_at) VALUES(?,?,?)", (gid, g.uid, db.now()))
            return jsonify(status="requested")
        c.execute("INSERT INTO guild_members(user_id,guild_id,joined_at) VALUES(?,?,?)", (g.uid, gid, db.now()))
    return jsonify(status="joined")


@bp.post("/guilds/<int:gid>/requests/<int:uid>/<action>")
@auth
def guild_request(gid, uid, action):
    c = conn()
    with db.tx(c):
        need_role(c, gid, "officer")
        if not c.execute("SELECT 1 FROM guild_requests WHERE guild_id=? AND user_id=?", (gid, uid)).fetchone():
            raise GameError("No such request", 404)
        c.execute("DELETE FROM guild_requests WHERE guild_id=? AND user_id=?", (gid, uid))
        if action == "accept":
            if c.execute("SELECT 1 FROM guild_members WHERE user_id=?", (uid,)).fetchone():
                raise GameError("Player already in a guild")
            c.execute("INSERT INTO guild_members(user_id,guild_id,joined_at) VALUES(?,?,?)", (uid, gid, db.now()))
        elif action != "reject":
            raise GameError("Bad action")
    return jsonify(ok=True)


@bp.post("/guilds/leave")
@auth
def guild_leave():
    c = conn()
    with db.tx(c):
        m = my_membership(c)
        if not m:
            raise GameError("Not in a guild")
        gid = m["guild_id"]
        if m["role"] == "leader":
            nxt = c.execute("SELECT user_id FROM guild_members WHERE guild_id=? AND user_id<>? ORDER BY CASE role WHEN 'officer' THEN 0 ELSE 1 END, contributed DESC LIMIT 1", (gid, g.uid)).fetchone()
            if nxt:
                c.execute("UPDATE guild_members SET role='leader' WHERE user_id=?", (nxt[0],))
                c.execute("UPDATE guilds SET leader_id=? WHERE id=?", (nxt[0], gid))
            else:
                c.execute("DELETE FROM guilds WHERE id=?", (gid,))
        c.execute("DELETE FROM guild_members WHERE user_id=?", (g.uid,))
    return jsonify(ok=True)


@bp.post("/guilds/<int:gid>/kick/<int:uid>")
@auth
def guild_kick(gid, uid):
    c = conn()
    with db.tx(c):
        me = need_role(c, gid, "officer")
        t = c.execute("SELECT * FROM guild_members WHERE user_id=? AND guild_id=?", (uid, gid)).fetchone()
        if not t or ROLE_RANK[t["role"]] >= ROLE_RANK[me["role"]]:
            raise GameError("Cannot kick this member", 403)
        c.execute("DELETE FROM guild_members WHERE user_id=?", (uid,))
    return jsonify(ok=True)


@bp.post("/guilds/<int:gid>/role/<int:uid>")
@auth
def guild_role(gid, uid):
    role = str(body().get("role", ""))
    if role not in ("member", "officer"):
        raise GameError("Bad role")
    c = conn()
    with db.tx(c):
        need_role(c, gid, "leader")
        if not c.execute("SELECT 1 FROM guild_members WHERE user_id=? AND guild_id=?", (uid, gid)).fetchone() or uid == g.uid:
            raise GameError("Invalid member")
        c.execute("UPDATE guild_members SET role=? WHERE user_id=?", (role, uid))
    return jsonify(ok=True)


@bp.post("/guilds/<int:gid>/donate")
@auth
def guild_donate(gid):
    amt = int_field(body(), "amount", 100, 10_000_000)
    c = conn()
    with db.tx(c):
        need_role(c, gid, "member")
        economy.add_coins(c, g.uid, -amt, "guild_donate", {"guild": gid})
        c.execute("UPDATE guilds SET bank_coins=bank_coins+?, xp=xp+? WHERE id=?", (amt, amt // 10, gid))
        c.execute("UPDATE guild_members SET contributed=contributed+? WHERE user_id=?", (amt, g.uid))
        x = c.execute("SELECT xp FROM guilds WHERE id=?", (gid,)).fetchone()[0]
        c.execute("UPDATE guilds SET level=? WHERE id=?", (guild_level(x), gid))
    return jsonify(ok=True)


@bp.post("/guilds/<int:gid>/settings")
@auth
def guild_settings(gid):
    d = body()
    c = conn()
    with db.tx(c):
        need_role(c, gid, "leader")
        if "description" in d:
            c.execute("UPDATE guilds SET description=? WHERE id=?", (str(d["description"])[:200], gid))
        if d.get("join_mode") in ("open", "request"):
            c.execute("UPDATE guilds SET join_mode=? WHERE id=?", (d["join_mode"], gid))
        if "min_level" in d:
            c.execute("UPDATE guilds SET min_level=? WHERE id=?", (int_field(d, "min_level", 1, 100), gid))
        if "emblem" in d:
            c.execute("UPDATE guilds SET emblem=? WHERE id=?", (int_field(d, "emblem", 0, 31), gid))
    return jsonify(ok=True)


@bp.get("/guilds/<int:gid>/messages")
@auth
def guild_messages(gid):
    c = conn()
    need_role(c, gid, "member")
    rows = c.execute("""SELECT m.id, u.username, m.text, m.created_at FROM guild_messages m JOIN users u ON u.id=m.user_id
                        WHERE m.guild_id=? ORDER BY m.id DESC LIMIT 60""", (gid,)).fetchall()
    return jsonify(messages=[dict(r) for r in reversed(rows)])


@bp.post("/guilds/<int:gid>/messages")
@auth
def guild_post(gid):
    rate_limit(f"gm:{g.uid}", 8, 10)
    text = str(body().get("text", "")).strip()[:200]
    if not text:
        raise GameError("Empty message")
    c = conn()
    need_role(c, gid, "member")
    c.execute("INSERT INTO guild_messages(guild_id,user_id,text,created_at) VALUES(?,?,?,?)", (gid, g.uid, text, db.now()))
    return jsonify(ok=True)


def create_app(db_path=None):
    from flask import Flask
    app = Flask(__name__)
    app.config["DB_PATH"] = db_path or config.DB_PATH
    _rate.clear()
    db.init_db(app.config["DB_PATH"])
    app.register_blueprint(bp)

    @app.get("/health")
    def health():
        return jsonify(ok=True)

    @app.errorhandler(404)
    def nf(e):
        return jsonify(error="Not found"), 404

    @app.errorhandler(405)
    def na(e):
        return jsonify(error="Method not allowed"), 405
    return app
