"""Car catalog (seeded, fictional makers), upgrade parts and the shared stat model.

Real brand names are trademarked: the seed uses fictional makers. To add real cars,
append rows to the `cars` table (or edit generate_cars) - nothing else needs to change.
"""
import json, math, random

# body type -> base physical data (also mirrored in client/data/car_types.json)
BODY = {
    "sedan":     dict(mass=1450, aero=0.93, hp=(110, 700),  hand=58, brake=62, L=4.6, W=1.8,  wr=0.33, drives=["FWD", "RWD", "AWD"]),
    "hatchback": dict(mass=1200, aero=0.90, hp=(70, 450),   hand=62, brake=60, L=3.9, W=1.7,  wr=0.31, drives=["FWD", "FWD", "AWD"]),
    "suv":       dict(mass=2000, aero=0.80, hp=(130, 750),  hand=48, brake=55, L=4.5, W=1.9,  wr=0.38, drives=["AWD", "AWD", "RWD"]),
    "sports":    dict(mass=1350, aero=1.00, hp=(180, 1200), hand=72, brake=72, L=4.4, W=1.95, wr=0.34, drives=["RWD", "RWD", "AWD"]),
    "coupe":     dict(mass=1400, aero=0.97, hp=(150, 900),  hand=66, brake=66, L=4.5, W=1.85, wr=0.34, drives=["RWD", "AWD", "FWD"]),
    "pickup":    dict(mass=2300, aero=0.75, hp=(150, 650),  hand=40, brake=50, L=5.2, W=1.95, wr=0.40, drives=["RWD", "AWD", "AWD"]),
    "van":       dict(mass=2100, aero=0.70, hp=(90, 350),   hand=36, brake=48, L=4.8, W=1.9,  wr=0.34, drives=["FWD", "RWD"]),
    "truck":     dict(mass=9000, aero=0.55, hp=(250, 800),  hand=25, brake=45, L=7.0, W=2.4,  wr=0.50, drives=["RWD"]),
}
MAKERS = ["Aurion", "Kestrel", "Valkyr", "Ronin", "Tessera", "Hallam", "Vortexa", "Nordik", "Zephyr", "Brava",
          "Kaiser Dyn", "Solano", "Meridian", "Ignis", "Orbis", "Taurus Works"]
MODELS = ["Vanta", "Corsa", "Ignis", "Falcon", "Stratos", "Rapide", "Nova", "Tempest", "Phoenix", "Mirage", "Raptor",
          "Cobalt", "Apex", "Zenith", "Specter", "Viper", "Comet", "Onyx", "Strike", "Titan", "Fury", "Jaguara", "Lynx",
          "Orion", "Quasar", "Havoc", "Spirit", "Blaze", "Avalon", "Cyclone", "Dominus", "Echo", "Genesis", "Helix",
          "Inferno", "Javelin", "Krypton", "Legend", "Meteor", "Nebula", "Omega", "Pulse", "Rogue", "Sabre", "Talon",
          "Umbra", "Vertex", "Warden", "Xenon", "Zephyra", "Bolt", "Crest", "Drift", "Ember", "Flux", "Glide", "Hunter",
          "Icon", "Joust", "Knight", "Lotus-R", "Mach", "Nitro", "Opal", "Prime", "Quest", "Rally", "Surge", "Trek"]
CLASS_SHARE = [("D", .20), ("C", .22), ("B", .22), ("A", .18), ("S", .12), ("X", .06)]
RARITY = {"D": "common", "C": "common", "B": "rare", "A": "epic", "S": "legendary", "X": "legendary"}

PARTS = {  # part: (display, per-level effect description, base cost factor)
    "engine":     ("Engine",       "+4% power / level",         1.0),
    "turbo":      ("Turbo",        "+3% power, +2% top / level", 0.8),
    "tires":      ("Tires",        "+4 grip / level",           0.6),
    "brakes":     ("Brakes",       "+5 braking / level",        0.5),
    "suspension": ("Suspension",   "+3 handling / level",       0.6),
    "weight":     ("Weight Red.",  "-2.5% mass / level",        0.7),
    "nitro":      ("Nitro",        "+12% nitro tank / level",   0.5),
}


def calc(body: str, hp: float, mass: float, hand: float, brake: float):
    kw = hp * 0.7457
    top = min(420.0, 44.0 * kw ** (1 / 3) * BODY[body]["aero"])
    acc = 1.45 * (mass / kw) ** 0.72
    return top, acc


def pi_of(top, acc, hand, brake) -> int:
    s_top = min(1.0, (top - 120) / 260)
    s_acc = min(1.0, max(0.0, (12 - acc) / 10))
    score = 0.30 * s_top + 0.32 * s_acc + 0.23 * (hand / 100) + 0.15 * (brake / 100)
    return int(100 + 800 * max(0.0, min(1.0, score)))


def generate_cars():
    rnd = random.Random(1337)
    raw, used = [], set()
    for body, b in BODY.items():
        n = 20
        for i in range(n):
            t = min(1.0, max(0.0, (i + rnd.uniform(0.1, 0.9)) / n))
            hp = b["hp"][0] + (b["hp"][1] - b["hp"][0]) * t ** 1.35
            hp *= rnd.uniform(0.95, 1.05)
            mass = b["mass"] * (1 - 0.22 * t) * rnd.uniform(0.95, 1.05)
            hand = max(15, min(98, b["hand"] + 22 * t + rnd.uniform(-4, 4)))
            brake = max(15, min(98, b["brake"] + 20 * t + rnd.uniform(-4, 4)))
            top, acc = calc(body, hp, mass, hand, brake)
            while True:
                nm = f"{rnd.choice(MAKERS)} {rnd.choice(MODELS)}"
                if nm not in used:
                    used.add(nm)
                    break
            make, model = nm.split(" ", 1) if nm.split(" ")[0] != "Kaiser" and nm.split(" ")[0] != "Taurus" else (nm.rsplit(" ", 1)[0], nm.rsplit(" ", 1)[1])
            raw.append(dict(make=make, model=model, year=rnd.randint(1996, 2026), body=body,
                            drive=rnd.choice(b["drives"]), power_hp=int(hp), mass_kg=int(mass),
                            top_kmh=int(top), accel_s=round(acc, 2), handling=int(hand), braking=int(brake),
                            pi=pi_of(top, acc, hand, brake)))
    raw.sort(key=lambda c: c["pi"])
    total, idx = len(raw), 0
    for cls, share in CLASS_SHARE:
        cnt = round(total * share) if cls != "X" else total - idx
        for c in raw[idx: idx + cnt]:
            c["cls"] = cls
        idx += cnt
    pmin, pmax = raw[0]["pi"], raw[-1]["pi"]
    for n, c in enumerate(raw, 1):
        c["id"] = f"car{n:03d}"
        c["rarity"] = RARITY[c["cls"]]
        x = (c["pi"] - pmin) / max(1, pmax - pmin)
        c["price"] = int(round(6000 * math.exp(x * 4.9) / 500) * 500)
    return raw


def seed(conn):
    if conn.execute("SELECT COUNT(*) FROM cars").fetchone()[0]:
        return
    cols = ["id", "make", "model", "year", "cls", "body", "drive", "power_hp", "mass_kg", "top_kmh", "accel_s",
            "handling", "braking", "pi", "price", "rarity"]
    conn.executemany(f"INSERT INTO cars({','.join(cols)}) VALUES({','.join('?' * len(cols))})",
                     [tuple(c[k] for k in cols) for c in generate_cars()])


def upgrade_cost(car_price: int, part: str, level: int) -> int:
    """Cost to go from `level` to `level+1`."""
    return int(round(car_price * 0.035 * PARTS[part][2] * (level + 1) ** 1.6 / 50) * 50) + 500


def effective_stats(car, upgrades: dict) -> dict:
    """Single source of truth used by the API, the race server (anti-cheat) and the client."""
    u = {k: int(upgrades.get(k, 0)) for k in PARTS}
    hp = car["power_hp"] * (1 + 0.04 * u["engine"] + 0.03 * u["turbo"])
    mass = car["mass_kg"] * (1 - 0.025 * u["weight"])
    hand = min(100, car["handling"] + 3 * u["suspension"])
    grip = min(100, car["handling"] * 0.6 + 40 + 4 * u["tires"])
    brake = min(100, car["braking"] + 5 * u["brakes"])
    top, acc = calc(car["body"], hp, mass, hand, brake)
    top *= 1 + 0.02 * u["turbo"]
    top = min(430.0, top)
    return dict(power_hp=round(hp), mass_kg=round(mass), top_kmh=round(top), accel_s=round(acc, 2),
                handling=round(hand), grip=round(grip), braking=round(brake),
                nitro_tank=round(100 * (1 + 0.12 * u["nitro"])), drive=car["drive"], body=car["body"],
                pi=pi_of(top, acc, hand, brake))


def row_to_car(r) -> dict:
    return {k: r[k] for k in r.keys()}
