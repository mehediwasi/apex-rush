import json, math
from . import db, config, catalog


class GameError(Exception):
    def __init__(self, msg, status=400):
        super().__init__(msg)
        self.msg, self.status = msg, status


def level_for_xp(xp: int) -> int:
    return 1 + int(math.sqrt(max(0, xp) / 120))


def add_coins(conn, uid: int, delta: int, kind: str, meta=None) -> int:
    """Atomic balance change. Must run inside db.tx(). Returns new balance."""
    cur = conn.execute("UPDATE users SET coins = coins + ? WHERE id = ? AND coins + ? >= 0", (delta, uid, delta))
    if cur.rowcount == 0:
        raise GameError("Not enough coins", 402)
    bal = conn.execute("SELECT coins FROM users WHERE id=?", (uid,)).fetchone()[0]
    conn.execute("INSERT INTO transactions(user_id,kind,amount,balance_after,meta,created_at) VALUES(?,?,?,?,?,?)",
                 (uid, kind, delta, bal, json.dumps(meta or {}), db.now()))
    return bal


def add_xp(conn, uid: int, xp: int):
    conn.execute("UPDATE users SET xp = xp + ? WHERE id=?", (xp, uid))
    x = conn.execute("SELECT xp FROM users WHERE id=?", (uid,)).fetchone()[0]
    conn.execute("UPDATE users SET level=? WHERE id=?", (level_for_xp(x), uid))


def starter_car_id(conn) -> str:
    r = conn.execute("SELECT id FROM cars WHERE body IN ('hatchback','sedan') ORDER BY price LIMIT 1").fetchone()
    return r[0]


def give_car(conn, uid: int, car_id: str, paid: int = 0) -> int:
    cur = conn.execute("INSERT INTO garage(user_id,car_id,acquired_at) VALUES(?,?,?)", (uid, car_id, db.now()))
    gid = cur.lastrowid
    u = conn.execute("SELECT selected_garage_id FROM users WHERE id=?", (uid,)).fetchone()
    if not u[0]:
        conn.execute("UPDATE users SET selected_garage_id=? WHERE id=?", (gid, uid))
    return gid


def daily_deal_ids(conn, day: int, n=6):
    ids = [r[0] for r in conn.execute("SELECT id FROM cars ORDER BY id")]
    import random
    rnd = random.Random(day)
    return set(rnd.sample(ids, n))


def deal_price(price: int) -> int:
    return int(price * 0.8 / 100) * 100


def sell_value(conn, garage_row) -> int:
    car = conn.execute("SELECT price FROM cars WHERE id=?", (garage_row["car_id"],)).fetchone()
    return int(car["price"] * 0.55 + garage_row["invested"] * 0.40)


# ---- race rewards ----
POS_MULT = [1.0, 0.7, 0.5, 0.38, 0.3, 0.25, 0.2, 0.15]


def race_reward(track_len_m: float, laps: int, position: int, players: int, finished: bool, takedowns: int):
    base = (track_len_m / 1000.0) * laps * 650
    mult = POS_MULT[min(position, len(POS_MULT)) - 1]
    scale = min(1.0, 0.35 + 0.15 * players)          # solo races pay 50% (anti-farm)
    coins = base * mult * scale * (1.0 if finished else 0.2)
    coins += min(takedowns, 10) * 40
    coins = int(min(coins, 60_000))
    xp = int(coins * 0.1 + (25 if finished else 5) + (30 if position == 1 and players > 1 else 0))
    return coins, xp
