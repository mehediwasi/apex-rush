import hashlib, hmac, os, time
import jwt
from . import config


def hash_password(pw: str) -> str:
    salt = os.urandom(16)
    h = hashlib.scrypt(pw.encode(), salt=salt, n=2 ** 14, r=8, p=1, dklen=32)
    return f"scrypt${salt.hex()}${h.hex()}"


def verify_password(pw: str, stored: str) -> bool:
    try:
        _, salt, h = stored.split("$")
        calc = hashlib.scrypt(pw.encode(), salt=bytes.fromhex(salt), n=2 ** 14, r=8, p=1, dklen=32)
        return hmac.compare_digest(calc.hex(), h)
    except Exception:
        return False


def make_token(uid: int) -> str:
    now = int(time.time())
    return jwt.encode({"uid": uid, "iat": now, "exp": now + config.TOKEN_DAYS * 86400},
                      config.secret_key(), algorithm="HS256")


def decode_token(tok: str):
    """Returns uid or None."""
    try:
        return int(jwt.decode(tok, config.secret_key(), algorithms=["HS256"])["uid"])
    except Exception:
        return None
