import os, pathlib, secrets

BASE = pathlib.Path(__file__).resolve().parent.parent
DATA_DIR = pathlib.Path(os.environ.get("DATA_DIR", BASE / "data"))
DATA_DIR.mkdir(parents=True, exist_ok=True)
DB_PATH = os.environ.get("DB_PATH", str(DATA_DIR / "game.db"))
TRACKS_DIR = BASE / "data" / "tracks"

HTTP_HOST = os.environ.get("HTTP_HOST", "0.0.0.0")
HTTP_PORT = int(os.environ.get("HTTP_PORT", "8000"))
WS_HOST = os.environ.get("WS_HOST", "0.0.0.0")
WS_PORT = int(os.environ.get("WS_PORT", "8765"))

TOKEN_DAYS = 30
START_COINS = 45_000
START_GEMS = 50
GUILD_CREATE_COST = 25_000
MARKET_TAX = 0.05          # player-to-player market fee
MAX_UPGRADE_LEVEL = 5


def secret_key() -> str:
    env = os.environ.get("SECRET_KEY")
    if env:
        return env
    f = DATA_DIR / "secret.key"
    if not f.exists():
        f.write_text(secrets.token_hex(32))
    return f.read_text().strip()
