"""Realtime server: stdlib-only WebSocket (RFC 6455) + lobby/race/chat logic.

Protocol: JSON text frames {"t": "<type>", ...}. See AI_HANDOFF.md for the full list.
Server is authoritative for: race start time, checkpoint validation, finish order, rewards, takedowns.
"""
import asyncio, base64, hashlib, json, math, random, struct, time
from . import db, config, security, catalog, economy

GUID = b"258EAFA5-E914-47DA-95CA-C5AB0DC85B11"
COUNTDOWN_MS = 4000
FINISH_GRACE_MS = 45000
SNAP_HZ = 15
CP_SPACING_M = 110.0


def now_ms() -> float:
    return time.time() * 1000.0


class WSClosed(Exception):
    pass


class WSConn:
    def __init__(self, reader, writer):
        self.r, self.w = reader, writer
        self.closed = False
        self.uid = None
        self.name = None
        self.tokens = 30.0
        self.last_refill = time.monotonic()

    @staticmethod
    def frame(op: int, payload: bytes) -> bytes:
        n = len(payload)
        h = bytes([0x80 | op])
        if n < 126:
            h += bytes([n])
        elif n < 65536:
            h += bytes([126]) + struct.pack(">H", n)
        else:
            h += bytes([127]) + struct.pack(">Q", n)
        return h + payload

    def send(self, obj):
        if self.closed:
            return
        try:
            if self.w.transport.get_write_buffer_size() > 1_000_000:   # slow consumer
                self.close()
                return
            self.w.write(self.frame(0x1, json.dumps(obj, separators=(",", ":")).encode()))
        except Exception:
            self.closed = True

    def close(self, code=1000):
        if not self.closed:
            self.closed = True
            try:
                self.w.write(self.frame(0x8, struct.pack(">H", code)))
                self.w.close()
            except Exception:
                pass

    async def recv(self) -> str:
        buf, text_op = b"", None
        while True:
            hdr = await self.r.readexactly(2)
            fin, op = hdr[0] & 0x80, hdr[0] & 0x0F
            masked, n = hdr[1] & 0x80, hdr[1] & 0x7F
            if n == 126:
                n = struct.unpack(">H", await self.r.readexactly(2))[0]
            elif n == 127:
                n = struct.unpack(">Q", await self.r.readexactly(8))[0]
            if n > 65536 or not masked:
                raise WSClosed()
            mask = await self.r.readexactly(4)
            data = bytearray(await self.r.readexactly(n))
            for i in range(n):
                data[i] ^= mask[i & 3]
            data = bytes(data)
            if op == 0x8:
                raise WSClosed()
            if op == 0x9:
                self.w.write(self.frame(0xA, data))
                continue
            if op == 0xA:
                continue
            if op in (0x1, 0x2):
                text_op = op
                buf = data
            elif op == 0x0:
                buf += data
            if len(buf) > 65536:
                raise WSClosed()
            if fin:
                return buf.decode("utf-8", "replace")


async def handshake(reader, writer) -> bool:
    try:
        head = await asyncio.wait_for(reader.readuntil(b"\r\n\r\n"), 10)
    except Exception:
        return False
    lines = head.decode("latin1").split("\r\n")
    h = {}
    for ln in lines[1:]:
        if ":" in ln:
            k, v = ln.split(":", 1)
            h[k.strip().lower()] = v.strip()
    if lines[0].startswith("GET /health"):
        writer.write(b"HTTP/1.1 200 OK\r\nContent-Length: 2\r\nConnection: close\r\n\r\nok")
        await writer.drain()
        return False
    if h.get("upgrade", "").lower() != "websocket" or "sec-websocket-key" not in h:
        writer.write(b"HTTP/1.1 400 Bad Request\r\nContent-Length: 0\r\n\r\n")
        return False
    acc = base64.b64encode(hashlib.sha1(h["sec-websocket-key"].encode() + GUID).digest()).decode()
    writer.write(("HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n"
                  f"Sec-WebSocket-Accept: {acc}\r\n\r\n").encode())
    await writer.drain()
    return True


# ---------------------------------------------------------------- game objects
class P:
    def __init__(self, conn, user, car):
        self.conn, self.uid, self.name = conn, user["id"], user["username"]
        self.level = user["level"]
        self.car = car                      # dict: garage_id, car_id, color, stats...
        self.ready = False
        self.reset_race()

    def reset_race(self):
        self.pos = None
        self.yaw_q = [0, 0, 0, 1]
        self.speed = 0.0
        self.last_state_t = None
        self.strikes = 0
        self.cp_count = 0
        self.last_cp_t = None
        self.finish_ms = None
        self.dnf = False
        self.takedowns = 0
        self.last_td = {}
        self.dist = 0.0


class Lobby:
    def __init__(self, lid, host, name, track_id, laps, max_players, password):
        self.id, self.host, self.name = lid, host, name
        self.track_id, self.laps, self.max, self.password = track_id, laps, max_players, password
        self.players = {}
        self.state = "waiting"
        self.start_at = 0.0
        self.track = None
        self.cps = []
        self.grid = {}
        self.snap_task = None
        self.timeout_task = None
        self.first_finish = None
        self.left = []


class Hub:
    def __init__(self, db_path=None):
        self.db = db.connect(db_path)
        self.conns = {}          # uid -> WSConn
        self.lobbies = {}
        self.next_lid = 1
        self.tracks_cache = {}

    # --------------- infra
    def track(self, tid):
        if tid not in self.tracks_cache:
            p = config.TRACKS_DIR / f"{tid}.json"
            if not tid.startswith("map_") or "/" in tid or ".." in tid or not p.exists():
                return None
            self.tracks_cache[tid] = json.loads(p.read_text())
        return self.tracks_cache[tid]

    def user(self, uid):
        return self.db.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()

    def load_car(self, user):
        r = self.db.execute("SELECT * FROM garage WHERE id=? AND user_id=? AND listed=0", (user["selected_garage_id"], user["id"])).fetchone()
        if not r:
            r = self.db.execute("SELECT * FROM garage WHERE user_id=? AND listed=0 ORDER BY id LIMIT 1", (user["id"],)).fetchone()
        car = self.db.execute("SELECT * FROM cars WHERE id=?", (r["car_id"],)).fetchone()
        st = catalog.effective_stats(car, json.loads(r["upgrades"]))
        return dict(garage_id=r["id"], car_id=car["id"], make=car["make"], model=car["model"], cls=car["cls"], body=car["body"],
                    color=r["color"], wheel_style=r["wheel_style"], decal=r["decal"], neon=r["neon"],
                    upgrades=json.loads(r["upgrades"]), stats=st, pi=st["pi"])

    def guild_tag(self, uid):
        r = self.db.execute("SELECT g.tag FROM guild_members m JOIN guilds g ON g.id=m.guild_id WHERE m.user_id=?", (uid,)).fetchone()
        return r[0] if r else ""

    def lobby_of(self, uid):
        for l in self.lobbies.values():
            if uid in l.players:
                return l

    def bcast(self, lobby, obj, skip=None):
        for p in list(lobby.players.values()):
            if p.uid != skip:
                p.conn.send(obj)

    # --------------- connection loop
    async def serve(self, reader, writer):
        if not await handshake(reader, writer):
            try:
                writer.close()
            except Exception:
                pass
            return
        c = WSConn(reader, writer)
        try:
            while True:
                raw = await asyncio.wait_for(c.recv(), 120)
                now = time.monotonic()
                c.tokens = min(60.0, c.tokens + (now - c.last_refill) * 40)
                c.last_refill = now
                try:
                    msg = json.loads(raw)
                    t = msg["t"]
                except Exception:
                    continue
                cost = 0.5 if t == "race.state" else 2.0
                if c.tokens < cost:
                    continue                      # drop (flood protection)
                c.tokens -= cost
                if c.uid is None and t not in ("auth", "ping"):
                    c.send({"t": "error", "msg": "auth first"})
                    continue
                h = getattr(self, "on_" + t.replace(".", "_"), None)
                if h:
                    try:
                        await h(c, msg)
                    except Exception as e:              # never let one bad message kill the loop
                        c.send({"t": "error", "msg": f"bad request: {type(e).__name__}"})
        except (WSClosed, asyncio.IncompleteReadError, asyncio.TimeoutError, ConnectionError):
            pass
        finally:
            self.disconnect(c)
            c.close()

    def disconnect(self, c):
        if c.uid and self.conns.get(c.uid) is c:
            del self.conns[c.uid]
            l = self.lobby_of(c.uid)
            if l:
                self.leave(l, c.uid)
            self.presence()

    def presence(self):
        for c in self.conns.values():
            c.send({"t": "presence", "online": len(self.conns)})

    # --------------- handlers
    async def on_ping(self, c, m):
        c.send({"t": "pong", "ts": m.get("ts"), "server_time": now_ms()})

    async def on_auth(self, c, m):
        uid = security.decode_token(str(m.get("token", "")))
        u = self.user(uid) if uid else None
        if not u or u["banned"]:
            c.send({"t": "auth.fail"})
            c.close(4001)
            return
        old = self.conns.get(uid)
        if old and old is not c:
            old.send({"t": "kicked", "reason": "Logged in elsewhere"})
            self.disconnect(old)
            old.close(4002)
        c.uid, c.name = uid, u["username"]
        self.conns[uid] = c
        c.send({"t": "auth.ok", "uid": uid, "username": u["username"], "server_time": now_ms(), "online": len(self.conns)})
        self.presence()

    async def on_lobby_list(self, c, m):
        c.send({"t": "lobby.list", "lobbies": [self.lobby_brief(l) for l in self.lobbies.values() if not l.password][:50]})

    def lobby_brief(self, l):
        return dict(id=l.id, name=l.name, track_id=l.track_id, laps=l.laps, players=len(l.players), max=l.max,
                    state=l.state, host=l.players[l.host].name if l.host in l.players else "", locked=bool(l.password))

    def lobby_state(self, l):
        t = self.track(l.track_id)
        return {"t": "lobby.state", "id": l.id, "name": l.name, "host": l.host, "track_id": l.track_id,
                "track_name": t["name"] if t else "?", "length_m": t["length_m"] if t else 0, "laps": l.laps,
                "max": l.max, "state": l.state,
                "players": [dict(uid=p.uid, name=p.name, level=p.level, ready=p.ready or p.uid == l.host, tag=self.guild_tag(p.uid),
                                 car=dict(make=p.car["make"], model=p.car["model"], cls=p.car["cls"], pi=p.car["pi"], color=p.car["color"]))
                            for p in l.players.values()]}

    def push_state(self, l):
        self.bcast(l, self.lobby_state(l))

    async def on_lobby_create(self, c, m):
        if self.lobby_of(c.uid):
            return c.send({"t": "error", "msg": "Already in a lobby"})
        tid = str(m.get("track_id", ""))
        if not self.track(tid):
            return c.send({"t": "error", "msg": "Unknown track"})
        laps = max(1, min(10, int(m.get("laps", 2))))
        mx = max(1, min(12, int(m.get("max_players", 8))))
        l = Lobby(self.next_lid, c.uid, str(m.get("name") or f"{c.name}'s race")[:24], tid, laps, mx, str(m.get("password", ""))[:16])
        self.next_lid += 1
        self.lobbies[l.id] = l
        self.join(l, c)

    def join(self, l, c):
        u = self.user(c.uid)
        l.players[c.uid] = P(c, u, self.load_car(u))
        self.push_state(l)

    async def on_lobby_join(self, c, m):
        if self.lobby_of(c.uid):
            return c.send({"t": "error", "msg": "Already in a lobby"})
        l = self.lobbies.get(int(m.get("id", 0)))
        if not l or l.state != "waiting" or len(l.players) >= l.max:
            return c.send({"t": "error", "msg": "Lobby unavailable"})
        if l.password and str(m.get("password", "")) != l.password:
            return c.send({"t": "error", "msg": "Wrong password"})
        self.join(l, c)

    async def on_matchmaking_quick(self, c, m):
        if self.lobby_of(c.uid):
            return
        for l in self.lobbies.values():
            if l.state == "waiting" and not l.password and len(l.players) < l.max:
                return self.join(l, c)
        tid = random.choice(self.pick_tracks())
        l = Lobby(self.next_lid, c.uid, "Quick Race", tid, 2, 8, "")
        self.next_lid += 1
        self.lobbies[l.id] = l
        self.join(l, c)

    def pick_tracks(self):
        idx = json.loads((config.TRACKS_DIR / "index.json").read_text())
        return [t["file"][:-4] for t in idx if t["length_m"] <= 4000]

    async def on_lobby_leave(self, c, m):
        l = self.lobby_of(c.uid)
        if l:
            self.leave(l, c.uid)
        c.send({"t": "lobby.left"})

    def leave(self, l, uid):
        p = l.players.pop(uid, None)
        if not l.players:
            self.close_lobby(l)
            return
        if l.host == uid:
            l.host = next(iter(l.players))
        if l.state == "racing" and p:
            p.dnf = True
            l.left.append(p)
            self.maybe_finish(l)
        self.push_state(l)

    def close_lobby(self, l):
        for t in (l.snap_task, l.timeout_task):
            if t:
                t.cancel()
        self.lobbies.pop(l.id, None)

    async def on_lobby_ready(self, c, m):
        l = self.lobby_of(c.uid)
        if l and l.state == "waiting":
            l.players[c.uid].ready = bool(m.get("ready"))
            self.push_state(l)

    async def on_lobby_settings(self, c, m):
        l = self.lobby_of(c.uid)
        if not l or l.host != c.uid or l.state != "waiting":
            return
        if "track_id" in m and self.track(str(m["track_id"])):
            l.track_id = str(m["track_id"])
        if "laps" in m:
            l.laps = max(1, min(10, int(m["laps"])))
        for p in l.players.values():
            p.ready = False
        self.push_state(l)

    async def on_lobby_car(self, c, m):
        l = self.lobby_of(c.uid)
        if l and l.state == "waiting":
            u = self.user(c.uid)
            l.players[c.uid].car = self.load_car(u)
            l.players[c.uid].ready = False
            self.push_state(l)

    async def on_lobby_kick(self, c, m):
        l = self.lobby_of(c.uid)
        t = int(m.get("uid", 0))
        if l and l.host == c.uid and t in l.players and t != c.uid and l.state == "waiting":
            kc = l.players[t].conn
            self.leave(l, t)
            kc.send({"t": "lobby.left", "reason": "kicked"})

    # --------------- race lifecycle
    def make_checkpoints(self, tr):
        cl = tr["centerline"]
        cps, acc, last = [0], 0.0, cl[0]
        for i in range(1, len(cl)):
            acc += math.dist((cl[i][0], cl[i][2]), (last[0], last[2]))
            last = cl[i]
            if acc >= CP_SPACING_M:
                cps.append(i)
                acc = 0.0
        # ensure the last checkpoint isn't too close to the start line
        if len(cps) > 2 and math.dist((cl[cps[-1]][0], cl[cps[-1]][2]), (cl[0][0], cl[0][2])) < CP_SPACING_M * 0.5:
            cps.pop()
        return [cl[i] for i in cps]

    async def on_lobby_start(self, c, m):
        l = self.lobby_of(c.uid)
        if not l or l.host != c.uid or l.state != "waiting":
            return
        if any(not (p.ready or p.uid == l.host) for p in l.players.values()):
            return c.send({"t": "error", "msg": "Not everyone is ready"})
        tr = self.track(l.track_id)
        l.track, l.cps = tr, self.make_checkpoints(tr)
        cl = tr["centerline"]
        tx, tz = cl[1][0] - cl[0][0], cl[1][2] - cl[0][2]
        ln = math.hypot(tx, tz) or 1
        tx, tz = tx / ln, tz / ln
        nx, nz = -tz, tx
        order = sorted(l.players.values(), key=lambda p: -p.car["pi"])[::-1]   # fastest start at the back
        l.grid = {}
        for i, p in enumerate(order):
            back = 8 + 8 * (i // 2)
            side = 3.2 if i % 2 == 0 else -3.2
            l.grid[p.uid] = [round(cl[0][0] - tx * back + nx * side, 2), round(cl[0][1] + 1.0, 2), round(cl[0][2] - tz * back + nz * side, 2)]
            p.reset_race()
            p.pos = l.grid[p.uid]
        l.left = []
        l.first_finish = None
        l.state = "racing"
        l.start_at = now_ms() + COUNTDOWN_MS
        self.bcast(l, {"t": "race.start", "track_id": l.track_id, "laps": l.laps, "start_at": l.start_at,
                       "dir": [tx, tz], "grid": l.grid, "checkpoints": [[round(v, 1) for v in cp] for cp in l.cps],
                       "players": [dict(uid=p.uid, name=p.name, tag=self.guild_tag(p.uid), car=p.car) for p in l.players.values()]})
        self.push_state(l)
        l.snap_task = asyncio.ensure_future(self.snap_loop(l))

    async def snap_loop(self, l):
        try:
            while l.state == "racing":
                await asyncio.sleep(1.0 / SNAP_HZ)
                snap = {p.uid: [p.pos, p.yaw_q, round(p.speed, 1), p.cp_count] for p in l.players.values() if p.pos}
                if snap:
                    self.bcast(l, {"t": "race.snap", "ts": now_ms(), "p": snap})
        except asyncio.CancelledError:
            pass

    def vmax(self, p):
        return p.car["stats"]["top_kmh"] / 3.6 * 1.25 * 1.15

    async def on_race_state(self, c, m):
        l = self.lobby_of(c.uid)
        if not l or l.state != "racing":
            return
        p = l.players[c.uid]
        pos = m.get("p")
        if not (isinstance(pos, list) and len(pos) == 3 and all(isinstance(v, (int, float)) and math.isfinite(v) for v in pos)):
            return
        t = now_ms()
        if t < l.start_at:
            return                                   # frozen on the grid until GO
        ref = p.last_state_t if p.last_state_t is not None else l.start_at
        dt = max(0.02, (t - ref) / 1000.0)
        d = math.dist(pos, p.pos)
        if d > self.vmax(p) * dt + 6.0:             # teleport / speedhack
            p.strikes += 1
            if p.strikes >= 25:
                c.send({"t": "error", "msg": "Disqualified (anti-cheat)"})
                self.finish_player(l, p, dnf=True)
            return
        p.dist += d
        p.last_state_t = t
        p.pos = [round(v, 2) for v in pos]
        q = m.get("r")
        if isinstance(q, list) and len(q) == 4:
            p.yaw_q = [round(float(v), 3) for v in q]
        p.speed = min(float(m.get("v", 0)), self.vmax(p) + 5)

    async def on_race_cp(self, c, m):
        l = self.lobby_of(c.uid)
        if not l or l.state != "racing" or now_ms() < l.start_at:
            return
        p = l.players[c.uid]
        if p.finish_ms is not None or p.dnf:
            return
        n = len(l.cps)
        expect = (p.cp_count + 1) % n
        idx = int(m.get("i", -1))
        cp = l.cps[idx] if 0 <= idx < n else None
        ok = cp is not None and idx == expect and p.pos is not None and math.dist((p.pos[0], p.pos[2]), (cp[0], cp[2])) < 70
        if ok:
            prev = l.cps[p.cp_count % n]
            seg = math.dist((prev[0], prev[2]), (cp[0], cp[2]))
            ref_t = p.last_cp_t if p.last_cp_t is not None else l.start_at
            if p.cp_count == 0:
                seg += 8
            min_t = seg / (self.vmax(p)) * 1000 * 0.6
            ok = (now_ms() - ref_t) >= min_t
        if not ok:
            p.strikes += 1
            return c.send({"t": "race.cp.reject", "i": idx})
        p.cp_count += 1
        p.last_cp_t = now_ms()
        c.send({"t": "race.cp.ok", "i": idx, "count": p.cp_count})
        if p.cp_count >= l.laps * n:
            self.finish_player(l, p)

    def finish_player(self, l, p, dnf=False):
        if p.finish_ms is not None:
            return
        if dnf:
            p.dnf = True
            p.finish_ms = None
        else:
            p.finish_ms = int(now_ms() - l.start_at)
        if not dnf:
            self.bcast(l, {"t": "race.finished", "uid": p.uid, "name": p.name, "time_ms": p.finish_ms})
            if l.first_finish is None:
                l.first_finish = now_ms()
                l.timeout_task = asyncio.ensure_future(self.finish_timeout(l))
        self.maybe_finish(l)

    async def finish_timeout(self, l):
        try:
            await asyncio.sleep(FINISH_GRACE_MS / 1000)
            for p in l.players.values():
                if p.finish_ms is None:
                    p.dnf = True
            self.end_race(l)
        except asyncio.CancelledError:
            pass

    def maybe_finish(self, l):
        if l.state == "racing" and all(p.finish_ms is not None or p.dnf for p in l.players.values()):
            self.end_race(l)

    async def on_race_takedown(self, c, m):
        l = self.lobby_of(c.uid)
        if not l or l.state != "racing" or now_ms() < l.start_at:
            return
        a, v = l.players.get(c.uid), l.players.get(int(m.get("target", 0)))
        if not v or v is a or a.pos is None or v.pos is None:
            return
        if math.dist(a.pos, v.pos) > 14 or a.speed < 11:           # must be close and fast (~40 km/h)
            return
        t = now_ms()
        if t - a.last_td.get(v.uid, 0) < 5000:
            return
        a.last_td[v.uid] = t
        a.takedowns += 1
        self.bcast(l, {"t": "race.takedown", "attacker": a.uid, "victim": v.uid, "count": a.takedowns, "attacker_name": a.name, "victim_name": v.name})

    def end_race(self, l):
        if l.state != "racing":
            return
        l.state = "results"
        for t in (l.snap_task, l.timeout_task):
            if t:
                t.cancel()
        everyone = list(l.players.values()) + [p for p in l.left if p.uid not in l.players]
        fin = sorted([p for p in everyone if p.finish_ms is not None and not p.dnf], key=lambda p: p.finish_ms)
        dnf = sorted([p for p in everyone if p.finish_ms is None or p.dnf], key=lambda p: -p.cp_count)
        ranked = fin + dnf
        tr = l.track
        n_players = len(ranked)
        rows = []
        conn = self.db
        with db.tx(conn):
            rid = conn.execute("INSERT INTO races(track_id,laps,players,created_at) VALUES(?,?,?,?)", (l.track_id, l.laps, n_players, db.now())).lastrowid
            for pos, p in enumerate(ranked, 1):
                finished = p.finish_ms is not None and not p.dnf
                coins, xp = economy.race_reward(tr["length_m"], l.laps, pos, n_players, finished, p.takedowns)
                if p.strikes >= 10:
                    coins, xp = 0, 0
                if coins:
                    economy.add_coins(conn, p.uid, coins, "race", {"race": rid, "pos": pos})
                economy.add_xp(conn, p.uid, xp)
                conn.execute("UPDATE users SET races=races+1, wins=wins+?, podiums=podiums+?, takedowns=takedowns+?, distance_m=distance_m+? WHERE id=?",
                             (1 if pos == 1 and finished and n_players > 1 else 0, 1 if pos <= 3 and finished and n_players > 1 else 0, p.takedowns, p.dist, p.uid))
                conn.execute("UPDATE garage SET odometer_km=odometer_km+? WHERE id=?", (p.dist / 1000, p.car["garage_id"]))
                conn.execute("INSERT INTO race_results VALUES(?,?,?,?,?,?,?,?)", (rid, p.uid, pos, p.finish_ms, coins, xp, p.car["car_id"], p.takedowns))
                if finished and p.strikes < 10:
                    conn.execute("""INSERT INTO best_times(track_id,user_id,time_ms,car_id) VALUES(?,?,?,?)
                                    ON CONFLICT(track_id,user_id) DO UPDATE SET time_ms=excluded.time_ms, car_id=excluded.car_id
                                    WHERE excluded.time_ms < best_times.time_ms""", (l.track_id, p.uid, p.finish_ms, p.car["car_id"]))
                gm = conn.execute("SELECT guild_id FROM guild_members WHERE user_id=?", (p.uid,)).fetchone()
                if gm and xp:
                    conn.execute("UPDATE guild_members SET contributed=contributed+? WHERE user_id=?", (xp, p.uid))
                    conn.execute("UPDATE guilds SET xp=xp+? WHERE id=?", (xp, gm[0]))
                rows.append(dict(uid=p.uid, name=p.name, pos=pos, time_ms=p.finish_ms if finished else None, dnf=not finished,
                                 coins=coins, xp=xp, takedowns=p.takedowns, car=f"{p.car['make']} {p.car['model']}"))
        self.bcast(l, {"t": "race.results", "race_id": rid, "rows": rows})
        l.state = "waiting"
        l.left = []
        for p in l.players.values():
            p.ready = False
            p.reset_race()
        self.push_state(l)

    # --------------- chat
    async def on_chat(self, c, m):
        text = str(m.get("msg", "")).strip()[:200]
        if not text:
            return
        scope = m.get("scope", "global")
        out = {"t": "chat", "scope": scope, "from": c.name, "uid": c.uid, "msg": text, "ts": now_ms()}
        if scope == "lobby":
            l = self.lobby_of(c.uid)
            if l:
                self.bcast(l, out)
        elif scope == "guild":
            gm = self.db.execute("SELECT guild_id FROM guild_members WHERE user_id=?", (c.uid,)).fetchone()
            if not gm:
                return
            self.db.execute("INSERT INTO guild_messages(guild_id,user_id,text,created_at) VALUES(?,?,?,?)", (gm[0], c.uid, text, db.now()))
            for (uid,) in self.db.execute("SELECT user_id FROM guild_members WHERE guild_id=?", (gm[0],)).fetchall():
                if uid in self.conns:
                    self.conns[uid].send(out)
        else:
            out["scope"] = "global"
            for cc in self.conns.values():
                cc.send(out)


async def run_server(hub, host, port):
    return await asyncio.start_server(hub.serve, host, port, limit=2 ** 16)


def serve_forever(host=None, port=None, db_path=None):
    async def main():
        hub = Hub(db_path)
        srv = await run_server(hub, host or config.WS_HOST, port or config.WS_PORT)
        async with srv:
            await srv.serve_forever()
    asyncio.run(main())
