# APEX RUSH: online racing game (Android + Windows)

Godot 4.3 client + Python server (REST + WebSocket + SQLite). Built to be extended by any AI/developer.

```
apex-rush/
  client/    Godot 4.3 project (GDScript)  -> exports to Windows .exe and Android .apk
  server/    Python server: accounts, garage, car market, guilds, lobbies, races, rewards
  tools/     generators for the placeholder car models and 320 tracks
  AI_HANDOFF.md   <- give this file to the next AI before asking for changes
  docker-compose.yml
```

## 1. Run the server (PC / VPS)
```
cd server
pip install -r requirements.txt
python run.py          # REST :8000   WebSocket :8765   DB: server/data/game.db (created automatically)
python -m unittest discover -s tests -v     # 10 tests (REST economy/market/guilds + realtime race & anti-cheat)
```
Production: `SECRET_KEY=<long random> python run.py` behind HTTPS (nginx/Caddy) and open ports 8000 + 8765,
or `docker compose up -d`. Put the WebSocket behind TLS too (wss://) before releasing to the public.

## 2. Run the client
1. Install **Godot 4.3+ (standard version, not .NET)**.
2. Open `client/project.godot`. First import takes a minute (it imports 8 car models).
3. Press **F5**. On the login screen set *Server URL* (`http://127.0.0.1:8000` for local test), create an account, play.
   - Start with 45,000 coins and a starter car. Free Drive works offline per car.
4. Windows build: *Project > Export > Add > Windows Desktop > Export*.
5. Android build: install Android Studio SDK + JDK 17, Godot *Editor Settings > Export > Android* (paths), create a
   debug keystore, *Project > Export > Add > Android > Export*. Controls are on-screen buttons (and optional tilt).
   For a phone to reach your PC server use the PC LAN IP (or a public server URL). Android needs https for
   non-LAN production traffic.

## 3. What is implemented (real, not mock)
| System | Where |
|---|---|
| Accounts, login (scrypt + JWT), rate limit | server/app/security.py, api.py |
| SQLite database, 14 tables, transactions | server/app/db.py |
| 160-car catalog (fictional makers), classes D-X, PI rating, prices | server/app/catalog.py |
| Coins economy (atomic ledger), daily reward streaks, level/XP | economy.py, api.py |
| Car dealer, daily deals (-20%), player-to-player market (5% fee) | api.py `/market/*` |
| Garage, 7 upgrade parts x 5 levels, paint/wheels/neon, sell | api.py `/garage/*` |
| Guilds: create, search, join/request, roles, kick, bank donate, XP/levels, chat, leaderboard | api.py, ws.py |
| FF-style lobby: browse, create (password), quick match, ready, host start/kick, chat | ws.py, lobby_panel.gd |
| Multiplayer race: server start time, checkpoints, anti-cheat, finish order, rewards, takedowns | ws.py |
| Vehicle physics: power curve, drag=top speed, traction limit, drift, nitro, downforce, off-road grip, gearbox | car_controller.gd |
| Runtime 3D tracks from 320 centerline files (road, curbs, walls, scenery, elevation) | track_builder.gd |
| Graphics presets Low/Med/High/Ultra (SSAO, SSR, SSIL, volumetric fog, glow, 4-split shadows, MSAA) | race.gd |
| HUD, minimap, touch controls, tilt, procedural engine sound | scripts/race/ |

## 4. Honest limits (read this)
- **Client code was not run in the Godot editor** (no Godot in my environment). Server + realtime logic is tested
  (10 passing tests). Expect a few small GDScript errors on first open: copy the red error text from Godot's
  Output panel and give it to an AI together with AI_HANDOFF.md, they are usually 1-line fixes.
- **Graphics are only as "ultra" as the art.** The renderer settings are ultra-capable, but the 8 car bodies are
  low-poly placeholders and the scenery is simple shapes. For Forza-level looks you need real GLB car models,
  textures, HDRI skies and sounds (see AI_HANDOFF.md > Art pipeline).
- A game like Forza Horizon 5 / GT7 is built by hundreds of people over years. This is a solid, working
  foundation of the *systems* (accounts, economy, guilds, lobbies, networking), not the finished AAA product.
- Car makers/models are fictional (real brands are trademarked). Add real names only if you have licenses.
- SQLite is fine for thousands of players on one server; switch to PostgreSQL for bigger scale (see handoff).

## 5. Phone build WITHOUT installing anything (GitHub Actions)
1. Make a free GitHub account, create a repo, upload the unzipped project (keep `.github/workflows/build.yml`).
2. Repo > Actions > build-game > Run workflow. Wait ~10 min.
3. Download artifact `apex-rush-android` -> `apex-rush.apk` -> install on phone (allow "unknown apps").
4. In the game's login screen set Server URL to your public server (see below). `127.0.0.1` will NOT work on a phone.
Server for phones: run `server/` on a VPS/cloud (docker compose up -d) and use `http://YOUR_IP:8000`; same Wi-Fi test: PC IP e.g. `http://192.168.0.10:8000`.
Android blocks plain http on newer versions only for some apps; if login fails over http use https (Caddy/nginx) or test on LAN.
iPhone/iOS and macOS need a Mac + Xcode + Apple Developer account: cannot be built from this environment.
